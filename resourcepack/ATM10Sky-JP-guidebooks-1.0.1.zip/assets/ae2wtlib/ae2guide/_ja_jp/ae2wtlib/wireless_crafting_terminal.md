---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: 無線クラフトターミナル
  icon: ae2:wireless_crafting_terminal
  position: 100
categories:
- ae2wtlib
item_ids:
  - ae2:wireless_crafting_terminal
---

# 無線クラフトターミナル

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

無線クラフトターミナルは<ItemLink id="ae2:crafting_terminal" />の[無線版](wireless_terminals.md)です。
AE2WTLibはMEネットワークからの自動[補充](restock.md)を追加し、ブロック抽出でMEネットワークからアイテムを取得できるようにします。   
<ItemLink id="ae2wtlib:magnet_card" />を使用すると、マグネットとしても機能します。

他の[無線ターミナル](wireless_terminals.md)と組み合わせて<ItemLink id="ae2wtlib:wireless_universal_terminal" />にすることもできます。

AE2WTLibは Minecraftの`ブロック抽出`機能を拡張し、インベントリにアイテムが存在しない場合はネットワークから取得します。
（現在のスロットが満杯の場合は、アイテムを格納しようとします）

## UI

[ターミナル](ae2:items-blocks-machines/terminals.md) を参照してください。

## アップグレード

無線クラフトターミナルは、次の[アップグレード](ae2:items-blocks-machines/upgrade_cards.md)に対応しています。

*   <ItemLink id="ae2:energy_card" />：バッテリー容量を増加させます
*   <ItemLink id="ae2wtlib:quantum_bridge_card" />：次元を越えても無制限の範囲で使用でき、ME ネットワークから自動的に充電します
*   <ItemLink id="ae2wtlib:magnet_card" />：マグネット機能を追加します

## レシピ

<RecipeFor id="ae2:wireless_crafting_terminal" />
