---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: マグネットカード
  icon: ae2wtlib:magnet_card
  position: 220
categories:
- ae2wtlib
item_ids:
- ae2wtlib:magnet_card
---

# マグネットカード

<ItemImage id="ae2wtlib:magnet_card" scale="3" />

マグネットカードは<ItemLink id="ae2:wireless_crafting_terminal" />用の[アップグレードカード](ae2:items-blocks-machines/upgrade_cards.md)です。
<ItemLink id="ae2:wireless_crafting_terminal" />にマグネット機能を追加し、GUI 上で有効・無効の切り替えやフィルター設定を行えます。
また、キー割り当てによってオン／オフを切り替えることもできます。

マグネットカードは次の2つの機能を持っています。

1. より広い範囲のアイテムを回収します（範囲は設定可能で、デフォルトは16です）
2. 回収したアイテムをインベントリではなくMEシステムへ直接格納します

これらはそれぞれ個別に有効・無効を切り替えられ、回収フィルターと挿入フィルターを別々に設定できます。
各フィルターはブラックリスト方式またはホワイトリスト方式に設定できます。

## レシピ

<RecipeFor id="ae2wtlib:magnet_card" />
