---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: 無線ユニバーサルターミナル
  icon: ae2wtlib:wireless_universal_terminal
  position: 20
categories:
- ae2wtlib
item_ids:
  - ae2wtlib:wireless_universal_terminal
---

# 無線ユニバーサルターミナル

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

無線ユニバーサルターミナルは、複数の[無線ターミナル](wireless_terminals.md)を1つのアイテムにまとめたものです。

すべての[AE2WTLib 無線ターミナル](wireless_terminals.md)を1つのターミナルに統合できます。

AE2の<ItemLink id="ae2:wireless_terminal" />は、無線ユニバーサルターミナルに**組み合わせることはできません**。


## UI

無線ユニバーサルターミナルはターミナルUIにボタンを追加します。
このボタンを左クリックすると次の[無線ターミナル](wireless_terminals.md)に切り替わり、右クリックすると前の[無線ターミナル](wireless_terminals.md)に切り替わります。


## アップグレード

無線ユニバーサルターミナルは、インストールされている[無線ターミナル](wireless_terminals.md)と同じアップグレードに対応しています。
インストールされている各ターミナルごとに、アップグレードスロットが2つ追加されます。

## エネルギー容量

ターミナルを追加すると、それぞれのエネルギー容量が統合されます。
そのため、2つのターミナルを内蔵した無線ユニバーサルターミナルは、[無線ターミナル](wireless_terminals.md)の2倍のエネルギー容量を持ちます。