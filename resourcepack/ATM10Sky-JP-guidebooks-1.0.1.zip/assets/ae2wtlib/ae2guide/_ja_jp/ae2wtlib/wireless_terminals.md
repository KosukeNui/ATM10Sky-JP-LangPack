---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: AE2WTLib無線ターミナル
  icon: ae2wtlib:wireless_universal_terminal
  position: 10
categories:
- ae2wtlib
item_ids:
  - ae2wtlib:wireless_pattern_encoding_terminal
  - ae2wtlib:wireless_pattern_access_terminal
---

# 無線ターミナル

<ItemGrid>
  <ItemIcon id="ae2wtlib:wireless_universal_terminal" />
  <ItemIcon id="ae2:wireless_crafting_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_encoding_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_access_terminal" />
</ItemGrid>

<ItemLink id="ae2:energy_card" />に加えて、すべてのAE2WTLib無線ターミナルは<ItemLink id="ae2wtlib:quantum_bridge_card" />でアップグレードでき、<ItemLink id="ae2wtlib:wireless_universal_terminal" />に統合できます。

AE2の<ItemLink id="ae2:wireless_terminal" />と同様に、キーバインドを使ってアクセスでき、（Curios APIを実装したMODが導入されている場合は）Curiosスロットに装備できます。

無線ターミナルは、通常の<ItemLink id="ae2:wireless_terminal" />と同じように、<ItemLink id="ae2:wireless_access_point" />を使用してリンクすることもできます。

## 無線ユニバーサルターミナル

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

<ItemLink id="ae2wtlib:wireless_universal_terminal" />は、複数の無線ターミナルを1つのアイテムにまとめたものです。

## 無線クラフトターミナル

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

<ItemLink id="ae2:wireless_crafting_terminal" />はクラフトターミナルの無線版です。
バニラのAE2と比べて、いくつかの[追加機能](wireless_crafting_terminal.md)を備えています。

## 無線パターンエンコードターミナル

<ItemImage id="ae2wtlib:wireless_pattern_encoding_terminal" scale="3" />

<ItemLink id="ae2:pattern_encoding_terminal" />の無線版です。

<RecipeFor id="ae2wtlib:wireless_pattern_encoding_terminal" />

## 無線パターンアクセスターミナル

<ItemImage id="ae2wtlib:wireless_pattern_access_terminal" scale="3" />

<ItemLink id="ae2:pattern_access_terminal" />の無線版です。

<RecipeFor id="ae2wtlib:wireless_pattern_access_terminal" />

## 他アドオンのターミナル

他のアドオンによって追加される多くの無線ターミナルも、<ItemLink id="ae2wtlib:wireless_universal_terminal" />で使用できます。

## ユニバーサルターミナルで使用できないターミナル

<ItemLink id="ae2:wireless_terminal" />は<ItemLink id="ae2wtlib:wireless_universal_terminal" />では使用できません。
これは <ItemLink id="ae2:wireless_crafting_terminal" />と比べて利点がないためです。
また、<ItemLink id="ae2wtlib:quantum_bridge_card" />も使用できません。
