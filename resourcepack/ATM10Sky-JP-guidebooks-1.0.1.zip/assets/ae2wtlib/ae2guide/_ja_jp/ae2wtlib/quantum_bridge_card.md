---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: 量子ブリッジカード
  icon: ae2wtlib:quantum_bridge_card
  position: 210
categories:
- ae2wtlib
item_ids:
- ae2wtlib:quantum_bridge_card
---

# 量子ブリッジカード

<ItemImage id="ae2wtlib:quantum_bridge_card" scale="3" />

量子ブリッジカードは、[AE2WTLib 無線ターミナル](wireless_terminals.md)用の[アップグレードカード](ae2:items-blocks-machines/upgrade_cards.md)です。
このカードを使用すると、[無線ターミナル](wireless_terminals.md)を[量子ブリッジ](ae2:items-blocks-machines/quantum_bridge.md)にリンクできます。

無線ターミナルに量子ブリッジカードと<ItemLink id="ae2:quantum_entangled_singularity" />を入れ、
もう一方のシンギュラリティを、ネットワークに接続された[量子ブリッジ](ae2:items-blocks-machines/quantum_bridge.md)に入れてください。

これで無線ターミナルは量子リンクされ、次元を越えてどこからでもネットワークにアクセスできるようになります
（ネットワークを含むチャンクがロードされている必要があります。例：<ItemLink id="ae2:spatial_anchor" />を使用している場合）。
また、ネットワークからエネルギーを自動的に充電するようになります。
（ネットワークに十分な[エネルギー容量](ae2:items-blocks-machines/energy_cells.md)があることを確認してください）

## レシピ

<RecipeFor id="ae2wtlib:quantum_bridge_card" />
