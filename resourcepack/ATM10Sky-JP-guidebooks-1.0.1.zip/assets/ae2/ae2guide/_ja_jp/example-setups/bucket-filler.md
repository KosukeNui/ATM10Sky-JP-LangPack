---
navigation:
  parent: example-setups/example-setups-index.md
  title: バケツを満たす装置
  icon: minecraft:water_bucket
---

# バケツを満たす装置

[バケツを空にする装置](bucket-emptier.md)も参照してください。

これは<ItemLink id="pattern_provider" />を使うので、[自動クラフト](../ae2-mechanics/autocrafting.md)のセットアップに組み込むためのものです。

不便なことに、流体そのものではなく、バケツ入りの流体が必要になることがあります。機械がこれをやってくれる場合もありますが
(Thermal ExpansionのFluid Transposerなど)、いつも都合よくやってくれるMODがあるとは限りません。幸い、
バニラのMinecraftには少しだけ不便な方法、<ItemLink id="minecraft:dispenser" />があります。

**ただし、[パターンエンコーディングターミナル](../items-blocks-machines/terminals.md#pattern-encoding-terminal)の流体の代替を使えば、
クラフトのレシピでバケツの代わりに流体そのものを使えるので、たいていはこれをする必要はありません。**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/bucket_filler.snbt" />

<BoxAnnotation color="#dddddd" min="2 1 0" max="3 2 1">
        (1) パターンプロバイダー: クラフトのロックを「レッドストーン信号あり」に設定。関連する処理パターンを入れる。

        <Row>
        ![Fill Pattern](../assets/diagrams/water_fill_pattern_small.png)
        ![Fill Pattern](../assets/diagrams/lava_fill_pattern_small.png)
        </Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1.1 0.1" max="3.2 1.9 0.9">
        (2) インターフェース: デフォルト設定。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.1 1.1 0.8" max="3.9 1.9 1">
        (3) ストレージバス1: デフォルト設定。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="4.05 1.05 0.8" max="4.95 1.95 1">
        (4) 形成プレーン: 反転カードを使い、バケツをブラックリストにするフィルター。
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.2 2 1.2" max="3.8 2.2 1.8">
        (5) インポートバス: 反転カードを使い、バケツをブラックリストにするフィルター。
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2.1 2 0.1" max="2.9 2.2 0.9">
        (6) ストレージバス2: デフォルト設定。
  </BoxAnnotation>

<DiamondAnnotation pos="0 1.5 0.5" color="#00ff00">
        メインネットワークへ
    </DiamondAnnotation>

  <IsometricCamera yaw="225" pitch="45" />
</GameScene>

## 構成

* <ItemLink id="pattern_provider" />(1) は、クラフトのロックを「レッドストーン信号あり」に設定し、関連する<ItemLink id="processing_pattern" />を入れています。
  
    ![Charger Pattern](../assets/diagrams/water_fill_pattern.png)
    ![Charger Pattern](../assets/diagrams/lava_fill_pattern.png)

* <ItemLink id="interface" />(2) はデフォルト設定です。
* 1つ目の<ItemLink id="storage_bus" />(3) はデフォルト設定です。
* <ItemLink id="formation_plane" />(4) は、反転カードを使ってバケツをブラックリストにするフィルターをかけています。
  <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
* <ItemLink id="import_bus" />(5) は、反転カードを使ってバケツをブラックリストにするフィルターをかけています。
  <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
* 2つ目の<ItemLink id="storage_bus" />(6) はデフォルト設定です。

## 仕組み

1. <ItemLink id="pattern_provider" />が材料を<ItemLink id="interface" />に押し込みます。
   (実際には最適化のため、ストレージバスと形成プレーンがプロバイダーの面の延長であるかのように、それらを通して直接押し込みます。アイテムが実際にインターフェースに入ることはありません。)
2. [パイプサブネット](pipe-subnet.md#providing-to-multiple-places)と<ItemLink id="formation_plane" />で説明しているしくみによって、
   バケツは<ItemLink id="minecraft:dispenser" />に入り、流体は形成プレーンによって設置されます。
3. <ItemLink id="minecraft:comparator" />がディスペンサーの中のバケツを検知し、ディスペンサーに動力を与えると同時に、
   <ItemLink id="pattern_provider" />をロックします。
4. ディスペンサーがバケツで流体をすくい、中には満たされたバケツが残ります。
5. <ItemLink id="import_bus" />が満たされたバケツをディスペンサーから取り出し、<ItemLink id="storage_bus" />を通して
   パターンプロバイダーに格納し、メインネットワークへ戻します。
6. コンパレーターがディスペンサーが空になったことを検知し、プロバイダーのロックを解除します。
