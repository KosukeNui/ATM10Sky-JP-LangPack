---
navigation:
  parent: example-setups/example-setups-index.md
  title: かまど自動化
  icon: minecraft:furnace
---

# かまど自動化

これは<ItemLink id="pattern_provider" />を使用するため、[自動クラフト](../ae2-mechanics/autocrafting.md)セットアップに統合されることを意図していることに注意してください。  
かまどを単独で自動化したいだけの場合は、ホッパーやチェストなどを使用してください。

<ItemLink id="minecraft:furnace" />の自動化は、  
[チャージャー](../example-setups/charger-automation.md)のようなより単純な機械の自動化よりも少し複雑です。  
かまどには2つの別々の側面からの入力と、3つ目の側面からの抽出が必要です。  
精錬するアイテムは上面に押し込み、燃料は側面に押し込み、結果は下面から引き出す必要があります。

これは、上部の<ItemLink id="pattern_provider" />、側面の<ItemLink id="export_bus" />で燃料を絶えず送り込み、  
下部の<ItemLink id="import_bus" />で結果をネットワークにインポートすることで実行できます。  
ただし、これには3つの [チャンネル](../ae2-mechanics/channels.md)が使用されます。

たった1つのチャンネルで実現する方法:

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) パターンプロバイダー:  
        関連する処理パターンを使用して、ケルタスクォーツレンチを使用して方向指定。

        ![Iron Pattern](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) インターフェース:  
        デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) ストレージバス #1:  
        石炭にフィルタリングされます。
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) ストレージバス #2:  
        反転カードを使用して、石炭をブラックリストにフィルタリングします。
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

  <DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        メインネットワークへ
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 構成

* <ItemLink id="pattern_provider" /> (1) は、関連する<ItemLink id="processing_pattern" />とともにデフォルト構成になっています。  
  <ItemLink id="certus_quartz_wrench" />を使用することで、方向性を持たせることができます。

  ![Iron Pattern](../assets/diagrams/furnace_pattern.png)

* <ItemLink id="interface" /> (2) はデフォルト設定です。
* 最初の <ItemLink id="storage_bus" /> (3) は石炭または使用したい燃料にフィルタリングされます。
* 2 番目の <ItemLink id="storage_bus" /> (4) は<ItemLink id="inverter_card" />を使用して、使用している燃料をブラックリストにするようにフィルタリングされます。

## 仕組み

1. <ItemLink id="pattern_provider" />は、原料を<ItemLink id="interface" />に搬出します。  
   (実際には、最適化のためプロバイダーの面の拡張であるかのように、ストレージバスを介して直接搬出します。  
   アイテムが実際にインターフェイスに入ることはありません。)
2. インターフェイスは何も保存しないように設定されているため、原料を[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)に搬出しようとします。
3. 緑のサブネット上の唯一のストレージは、<ItemLink id="storage_bus" />です。石炭にフィルターされたバスは、  
   側面を介して炉の燃料スロットに石炭を配置します。  
   石炭以外としてフィルターされたバスは、上面を介して上部のスロットに製錬するアイテムを配置します。
4. かまどがかまどとしての機能を果たす
5. ホッパーが結果をかまどの底から引き出し、プロバイダーの戻りスロットに配置して、メインネットワークに戻します。
