---
navigation:
  parent: example-setups/example-setups-index.md
  title: 水中投入自動化
  icon: fluix_crystal
---

# 水中投入自動化

これは<ItemLink id="pattern_provider" />を使用するため、  
[自動クラフト](../ae2-mechanics/autocrafting.md)セットアップに統合されることを意図していることに注意してください。

一部のレシピでは、アイテムを水に投げ込む必要があります  
(ただし、同様のセットアップを使用して、アイテムを他の場所に投げ込むこともできます)。

これは、<ItemLink id="formation_plane" />、<ItemLink id="annihilation_plane" />、およびいくつかのサポートインフラストラクチャ  
(基本的には、2つの変更された[パイプサブネット](pipe-subnet.md))を使用して自動化できます。

このセットアップは、[チャージャー自動化](charger-automation.md)と組み合わせて使用して、  
<ItemLink id="charged_certus_quartz_crystal" />を提供することを目的としています。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        (1) パターンプロバイダー:  
        関連する処理パターンを含むデフォルト設定。

        ![Fluix Pattern](../assets/diagrams/fluix_pattern_small.png) ![Flawed Budding Pattern](../assets/diagrams/flawed_budding_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 1" max="2 1 2">
        (2) インターフェース:  
        デフォルト設定。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 .7 1" max="2 1 2">
        (3) 形成プレーン:  
        入力をアイテムとしてドロップするように設定します。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 2 1" max="2 2.3 2">
        (4) 消滅プレーン:  
        設定するGUIはありません。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (5) ストレージバス:  
        パターンの出力にフィルタリング
        <Row><ItemImage id="fluix_crystal" scale="2" /><BlockImage id="flawless_budding_quartz" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="3.9 0.5 1.5" color="#00ff00">
        メインネット、自動化チャージャーへ
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
    </DiamondAnnotation>

  <IsometricCamera yaw="180" pitch="0" />
</GameScene>

## 構成とパターン

* <ItemLink id="pattern_provider" />(1) はデフォルトの設定になっており、関連する<ItemLink id="processing_pattern" />は
  * <ItemLink id="fluix_crystal" />の場合、JEI/REIのデフォルトレシピは正常に動作します。

    ![Fluix Pattern](../assets/diagrams/fluix_pattern.png)

  * <ItemLink id="flawed_budding_quartz" />の場合、おそらく<ItemLink id="quartz_block" />から直接作成するのが最善です。
    これにより、1つのレシピの入力が別のレシピの出力になり、ストレージバスがフィルターできなくなるという問題が回避されます。

    ![Flawed Budding Pattern](../assets/diagrams/flawed_budding_pattern.png)

* <ItemLink id="interface" /> (2)はデフォルト設定です。
* <ItemLink id="formation_plane" /> (3)は入力をアイテムとしてドロップするように設定されています。
* <ItemLink id="annihilation_plane" /> (4)にはGUIがなく、設定できません。
* <ItemLink id="storage_bus" /> (5)はパターンの出力にフィルターされます。

## 仕組み

1. <ItemLink id="pattern_provider" />は、緑のサブネット上の<ItemLink id="interface" />に材料をプッシュします
2. インターフェイス(デフォルトでは何も保存しないように構成されています)は、  
   その内容を[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)にプッシュしようとします
3. 緑のサブネット上の唯一のストレージは<ItemLink id="formation_plane" />で、これは受け取ったアイテムを水中に落とします
4. オレンジ色のサブネット上の<ItemLink id="annihilation_plane" />は、ドロップされたばかりのアイテムを拾おうとしますができません。
   パターンプロバイダー(オレンジ色のサブネット上の唯一のストレージ)の上にある<ItemLink id="storage_bus" />は、  
   可能なクラフトの結果のみを受け入れるようにフィルター処理されているからです
5. アイテムは、ワールド内で変換を実行します
6. ストレージバスにアイテムを保存できるようになったため、消滅プレーンは前方にあるアイテムを拾うことができるようになりました。
7. ストレージバスは結果のアイテムをパターンプロバイダーに保存し、ネットワークに返します。
