---
navigation:
  parent: example-setups/example-setups-index.md
  title: アメジストファーム
  icon: minecraft:amethyst_shard
---

# アメジストファーム

<ItemLink id="growth_accelerator" />はアメジストに対して機能しますが、<ItemLink id="annihilation_plane" />を使用して[ケルタスの芽](../items-blocks-machines/budding_certus.md)をフィルタリングする通常の方法でも機能します。  
アメジストの芽には効果がありません。  
<ItemLink id="certus_quartz_dust" />をドロップする未成熟のケルタスの芽とは異なり、未成熟のアメジストの芽は何もドロップしません。  
そのため、ネットワークには常に「何も」保存できないため、消滅プレーンは常にそれらを破壊します。

これを回避する方法は、殲滅機にシルクタッチを付与することです。  
次に、成熟していないアメジストの芽は何か(物理的な芽ブロックのさまざまな段階)をドロップするため、フィルタリングすることができます。

<ItemLink id="minecraft:amethyst_shard" /> を取得するため、<ItemLink id="minecraft:amethyst_cluster" />は<ItemLink id="formation_plane" />によって再度配置され、  
シルクタッチなしで<ItemLink id="annihilation_plane" />によって再度破壊される必要があります。

クラスターの方向性により、形成プレーンの真反対側に固体のブロック面が存在する必要があることに注意してください。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/amethyst_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 1 1" max="3 2 2">
        (1) 消滅プレーン#1: 設定するGUIはありませんが、シルクタッチでエンチャントされています。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1 1" max="2.3 2 2">
        (2) 形成プレーン:  アメジストの塊にフィルタリングされます。
        <ItemImage id="minecraft:amethyst_cluster" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 0.7 1" max="2 1 2">
        (3) 消滅プレーン#2: GUIの設定はありませんが、幸運のエンチャントができます。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="1.3 1 2">
        (4) ストレージバス#1: アメジストの破片がフィルタリングされています。
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 .7" max="1 1 1">
        (5) ストレージバス#2: アメジストの破片にフィルタリングされています。  メインストレージよりも高い優先度が設定されています。
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        メインネットワークへ
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 設定

* 最初の<ItemLink id="annihilation_plane" />(1)にはGUIがなく設定できませんが、シルクタッチでエンチャントする必要があります。
* <ItemLink id="formation_plane" />(2)は<ItemLink id="minecraft:amethyst_cluster" />にフィルタリングされます。
* 2番目の<ItemLink id="annihilation_plane" />(3)にはGUIがなく、設定できませんが、幸運をエンチャントすることができます。
* 最初の<ItemLink id="storage_bus" />(4)は<ItemLink id="minecraft:amethyst_shard" />にフィルタリングされます。
* 2 番目の<ItemLink id="storage_bus" />(5)は<ItemLink id="minecraft:amethyst_shard" />にフィルタリングされ、  
  その[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)はメインストレージよりも高く設定されます。

## 仕組み
1. 最初の<ItemLink id="annihilation_plane" />は、その前にあるものを破壊しようとしますが、  
   サブネット上の唯一のストレージはアメジストの塊にフィルタリングされた<ItemLink id="formation_plane" />であるため、  
   <ItemLink id="minecraft:amethyst_cluster" />しか破壊できません。これは消滅プレーンがシルクタッチのエンチャントをかけられているため機能します。  
   そうでなければ、何もドロップしない未熟な芽を破壊してしまいます。
2. <ItemLink id="formation_plane" />は、塊をその反対側のブロックに配置します。
3. 2番目の<ItemLink id="annihilation_plane" />は塊を破壊し、<ItemLink id="minecraft:amethyst_shard" />を生成します。
4. 最初の <ItemLink id="storage_bus" /> は、シャードをバレルに保存します。  
   2番目の消滅プレーンが遭遇する必要があるのは完全に成長したクラスターだけであるため、  
   技術的にはこれをフィルタリングする必要はありません。
5. 2番目の<ItemLink id="storage_bus" />により、メインネットワークが樽内のすべてのアメジストの破片にアクセスできるようになります。  
   アメジストの破片がメインストレージではなくバレルに優先的に戻されるように、  
   高い[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)に設定されています。
