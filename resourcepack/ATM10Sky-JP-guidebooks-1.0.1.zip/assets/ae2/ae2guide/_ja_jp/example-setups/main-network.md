---
navigation:
  parent: example-setups/example-setups-index.md
  title: 「メインネットワーク」の例
  icon: controller
---

# 「メインネットワーク」の例

他の多くのセットアップは「メインネットワーク」を参照します。また、  
これらすべての[デバイス](../ae2-mechanics/devices.md)がどのようにして1つの機能的なシステムに統合されるのかを尋ねるかもしれません。以下に例を示します:

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/small_base_network.snbt" />

    <BoxAnnotation color="#33dd33" min="5 1 10" max="9 7 14" thickness="0.05">
        パターンプロバイダーと分子組立機の大規模なクラスターにより、
        クラフト、石切り、鍛冶のパターンのための多くのスペースが提供されます。
        チェッカーボードパターンにより、
        プロバイダーはコンパクトさを保ちながら複数の組立機を並行して利用できるようになります。
        8つのグループにより、チャンネルが誤ってルーティングされることがなくなります。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 10 12" max="14 11 14" thickness="0.05">
        実はコントローラーはこんなに大きくなくてもかまいません。よく拠点で見かける巨大なリングや立方体のデザインは、
        主に見た目をかっこよくするためのものです。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 12 13" max="14 13 14" thickness="0.05">
        よいネットワークには必ずエネルギーセルがあります。1ゲームティックあたりにより多くのエネルギーを受け取れるようにし、
        電力の変動をならすためです。
    </BoxAnnotation>
    
    <BoxAnnotation color="#33dd33" min="2 1 10" max="4 4 13" thickness="0.05">
        電源には、原子炉やソーラーパネルや発電機など、ほかのMODのものを使うのがよいでしょう。
        火力発電機もまあまあ使えますが、AE2はモッドパックの中で使い、拠点のメインの発電機を使う前提で
        作られています。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="15 1 9" max="16 3 14" thickness="0.05">
        ファサードを使うと、ものを壁の裏に隠せます。
    </BoxAnnotation>
    <BoxAnnotation color="#33dd33" min="15 3 12" max="16 10 14" thickness="0.05">
        ファサードを使うと、ものを壁の裏に隠せます。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 9 7" max="14 10 9" thickness="0.05">
        一般的なストレージには、それほど多くのドライブやセルはいりません。4kか16kのセルが入ったドライブ
        2〜4台分あれば、ほとんどの場合は足ります。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 9 10" max="14 11 11" thickness="0.05">
        大量保管には、特定のアイテムにフィルターをかけた大きなセルを、優先度を高くした別のドライブに
        入れるのがよいでしょう。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10 9 13" max="11.7 13 14" thickness="0.05">
        インターフェースを使った自動在庫補充。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="6 10 12" max="9 12 15" thickness="0.05">
        チャージャー自動化のセットアップを、複数のチャージャーへ素直に広げたもの。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="2 10 12" max="5 11 15" thickness="0.05">
        1.20から刻印機が出力を自動で排出できるようになったので、プロセッサを自動化するもう1つの方法です。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="3 10 10" max="4 12 11" thickness="0.05">
        1.20から刻印機が出力を自動で排出できるようになったので、プロセッサを自動化するもう1つの方法です。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.2 9.2 8.2" max="7.8 10 8.8" thickness="0.05">
        無線アクセスポイントの範囲は球形なので、中央に置いています。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="14 1 2" max="16 5 7" thickness="0.05">
        ふつうは、大きな作業のための大きなクラフトCPUを1〜2台と、大きなCPUがふさがっているあいだに
        ほかの作業をこなす小さなCPUをいくつか置きます。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="5 3 6" max="6 4 7" thickness="0.05">
        デバイスが8台より多い場合(8か所より多くへ分配する場合など)は、サブネットにも専用のコントローラーが
        必要になることがあります。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.3 1 3.3" max="9.7 4 6" thickness="0.05">
        ケルタスファーム。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10.3 1 2.3" max="12.7 3.7 5" thickness="0.05">
        水中投入自動化。
    </BoxAnnotation>

  <IsometricCamera yaw="135" pitch="15" />
</GameScene>
