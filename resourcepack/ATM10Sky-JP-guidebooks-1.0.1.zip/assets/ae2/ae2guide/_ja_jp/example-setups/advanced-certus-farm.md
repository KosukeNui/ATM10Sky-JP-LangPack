---
navigation:
  parent: example-setups/example-setups-index.md
  title: 発展ケルタスファーム
  icon: certus_quartz_crystal
  position: 120
---

# 発展ケルタスファーム

これは基本的に[半自動ケルタスファーム](semiauto-certus-farm.md)と同じですが、MEシステムに完全に統合されています。

大量の芽生えたブロックを備蓄して時々手動で更新する代わりに、  
このセットアップでは[チャージャー自動化](charger-automation.md)と[水中投入自動化](throw-in-water-automation.md)を使用して自動的に行います。

推定の速度は[ケルタスの成長](../ae2-mechanics/certus-growth.md)を参照してください。

**これは複雑な構造で、他のものの後ろに隠れているものがあります。パンしてあらゆる角度から見ることができます。**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/advanced_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        (1) 消滅プレーン #1:  
        設定するGUIはありませんが、  
        幸運でエンチャントできます。
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1.7" max="3 3 2">
        (2) ストレージバス #1:  
        ケルタスクォーツの水晶にフィルタリングされます。
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    水晶破壊サブネット
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        (3) 消滅プレーン #2:  
        設定するGUIはありませんが、  
        シルクタッチがエンチャントされています。
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1.7" max="3 2 2">
        (4) ストレージバス #2:  
        ケルタスクォーツブロックにフィルタリングされます。
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    ケルタスブロック破壊サブネット
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        (5) 形成プレーン:  
        デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0.7 2" max="3 1 3">
        (6) インポートバス:  
        傷ついた芽生えたケルタスクォーツをフィルタリングしました。
        <BlockImage id="flawed_budding_quartz" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    出芽ブロック配置サブネット
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="1.7 2 2" max="2 3 3">
        (7) ストレージバス #3:  
        ケルタスクォーツの水晶にフィルタリングされます。  
        メインストレージよりも高い優先度が設定されています。
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#aaaadd" min="2 1 2" max="3 2 3">
        (8) インターフェース:  
        傷ついた芽生えたケルタスクォーツ1個を  
        そのまま保持するように設定されており、  
        クラフトカードがあります。
        <Row><BlockImage id="flawed_budding_quartz" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="1.5 0.5 0" color="#00ff00">
        メインネットワーク、自動化チャージャー、自動化水中投入へ
        <Row>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        </Row>
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## 構成

### 水晶破壊:

* 最初の<ItemLink id="annihilation_plane" />(1) にはGUIがなく、設定できませんが、幸運でエンチャントできます。
* 最初の<ItemLink id="storage_bus" />(2) は<ItemLink id="certus_quartz_crystal" />にフィルターされます。

### ケルタスブロック破壊:

* 2番目の<ItemLink id="annihilation_plane" />(3) にはGUIがなく、設定できませんが、シルクタッチでエンチャントする必要があります。
* 2番目の<ItemLink id="storage_bus" />(4) は<ItemLink id="quartz_block" />にフィルターされます。

### 出芽ブロック破壊:

* <ItemLink id="formation_plane" />(5) はデフォルト設定です。
* <ItemLink id="import_bus" />(6) は<ItemLink id="flawed_budding_quartz" />にフィルタリングされています。

### メインネットワーク:

* 3番目の<ItemLink id="storage_bus" />(7) は<ItemLink id="certus_quartz_crystal" />にフィルターされ、  
  [優先度](../ae2-mechanics/import-export-storage.md#storage-priority)がメインストレージよりも高く設定されています。
* <ItemLink id="interface" />(8) は、傷ついた芽生えたケルタスクォーツを1個保持するように設定されており、<ItemLink id="crafting_card" />があります。

## 仕組み

### 水晶破壊:

水晶破壊サブネットは、[シンプルなケルタスファーム](simple-certus-farm.md)のサブネットと非常によく似た動作をします。

1. <ItemLink id="annihilation_plane" />は目の前にあるものを破壊しようとしますが、破壊できるのは<ItemLink id="quartz_cluster" />だけです。
   サブネット上の唯一のストレージは<ItemLink id="storage_bus" />であり、<ItemLink id="certus_quartz_crystal" />にフィルターされているためです。
2. <ItemLink id="storage_bus" />はケルタスクォーツの水晶をバレル内に保管します。

### ケルタスブロック破壊:

ケルタスブロック破壊サブネットは、芽生えたケルタスブロックが<ItemLink id="quartz_block" />に変わったら、それを破壊します。
水晶破壊と同様に機能します。

1. <ItemLink id="annihilation_plane" />は、その前にあるものを破壊しようとしますが、破壊できるのは<ItemLink id="quartz_block" />だけです。
サブネット上の唯一のストレージは<ItemLink id="storage_bus" />であり、<ItemLink id="quartz_block" />にフィルターされているためです。
消滅プレーンにはシルクタッチが必要です。そうすることで、出芽ブロックは破壊されても劣化せず、  
プレーンが早期に破壊することはありません。
2. <ItemLink id="storage_bus" />は、ケルタスクォーツブロックを<ItemLink id="interface" />に保存し、  
[水中投入自動化](throw-in-water-automation.md)がそれを使用して新しい<ItemLink id="flawed_budding_quartz" />を作成できるようにします。

### ケルタスブロック破壊:

出芽ブロック配置サブネットは、破壊サブネットが古いケルタスクォーツブロックを破壊したときに、  
新しい<ItemLink id="flawed_budding_quartz" />を配置するために使用されます。

1. <ItemLink id="import_bus" />は、出芽ブロックを<ItemLink id="interface" />から[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)にインポートします。
2. サブネット上の唯一のストレージは、出芽ブロックを配置する<ItemLink id="formation_plane" />です。

### メインネットワーク:

* <ItemLink id="storage_bus" />は、メインネットワーク(および[チャージャー自動化](charger-automation.md))に、  
  バレル内のすべてのケルタスクォーツの水晶へのアクセスを提供します。  
  これは、 ケルタスクォーツの水晶がメインストレージではなくバレルに優先的に戻されるように、高い[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)に設定されています。
* <ItemLink id="interface" />は、出芽ブロック配置サブネットに<ItemLink id="flawed_budding_quartz" />へのアクセスを提供し、  
  ケルタスブロック破壊サブネットに、古いケルタスクォーツブロックをメインネットワークに戻す方法を提供します。  
  <ItemLink id="crafting_card" />により、インターフェースはメインネットワークの[自動クラフト](../ae2-mechanics/autocrafting.md)から新しい出芽ブロックを要求できるようになります。