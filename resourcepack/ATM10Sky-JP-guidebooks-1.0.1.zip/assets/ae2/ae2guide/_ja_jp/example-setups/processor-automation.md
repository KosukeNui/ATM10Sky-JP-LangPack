---
navigation:
  parent: example-setups/example-setups-index.md
  title: プロセッサ生産の自動化
  icon: logic_processor
---

# プロセッサ生産の自動化

[プロセッサ](../items-blocks-machines/processors.md)を自動化する方法は多数ありますが、これはその1つです。

この一般的なレイアウトは、フィルターできる限り、あらゆるタイプのアイテムで実行できます。  
(ロジスティクスパイプ、コンジット、ダクト、またはMODが何と呼んでいるかに関係なく)

![The Process FLow Diagram](../assets/diagrams/processor_flow_diagram.png)

ここでは、[パイプサブネット](pipe-subnet.md)を使用してAE2だけでこれを行う方法を詳しく説明します。

これは<ItemLink id="pattern_provider" />を使用するため、[自動クラフト](../ae2-mechanics/autocrafting.md)セットアップに統合されることを意図していることに注意してください。
プロセッサをスタンドアロンで自動化したい場合は、パターンプロバイダを別のバレルに置き換え、上部のバレルに材料を直接入れます。

これは以前のAE2バージョンと下位互換性があります。
<ItemLink id="inscriber" />がサイド化されていても、  
パイプサブネットは正しい面に挿入され、正しい面から抽出されるためです。

## パターンのエンコードの注意

エンコードする必要のある[パターン](../items-blocks-machines/patterns.md)は、**JEIに表示されるものとは一致しない**ことがよくあります。JEIで＋ボタンを押したときに出力されるものとも一致しません。
この場合、JEIは印刷された部品用と最終組み立て用の2つの別々のパターンを出力し、印刷された部品のパターンには[プレス](../items-blocks-machines/presses.md)が含まれます。これはこのセットアップが行う処理と違うので、望むものではありません。必要なのは、原材料を入れて完成したプロセッサを出力する1つのパターンです。プレスはすでに刻印機の中にあるので、パターンに入れてはいけません。

---

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/processor_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="5 1 0" max="6 2 1" thickness=".05">
        (1) パターンプロバイダー:  
        関連する処理パターンを含むデフォルト設定。

        <Row>
            ![Logic Pattern](../assets/diagrams/logic_pattern_small.png)
            ![Calculation Pattern](../assets/diagrams/calculation_pattern_small.png)
            ![Engineering Pattern](../assets/diagrams/engineering_pattern_small.png)
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.7 2 0" max="5 3 1" thickness=".05">
        (2) ストレージバス #1:  
        デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="4.3 2 1" thickness=".05">
        (3) エクスポートバス #1:  
        シリコンにフィルターされ、  
        2つの加速カードがあります
        <Row><ItemImage id="silicon" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="4.3 3 1" thickness=".05">
        (4) 輸出バス #2:  
        ゴールドインゴットにフィルタリングされ、  
        加速カードが2枚あります
        <Row><ItemImage id="minecraft:gold_ingot" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="4.3 4 1" thickness=".05">
        (5) 輸出バス #3:  
        ケルタスクォーツにフィルタリングされ、  
        加速カードが2枚あります
        <Row><ItemImage id="certus_quartz_crystal" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 6 0" max="4.3 5 1" thickness=".05">
        (6) 輸出バス #4:  
        ダイヤモンドにフィルタリングされ、  
        加速カードが2枚あります
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 0" max="2 2 1" thickness=".05">
        (7) 輸出バス #5:  
        レッドストーンダストにフィルターされ、  
        加速カードが2枚あります
        <Row><ItemImage id="minecraft:redstone" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="3 2 1" thickness=".05">
        (8) 刻印機 #1:  
        デフォルト設定。  
        シリコンプレスと4つの加速カードを搭載
        <Row><ItemImage id="silicon_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 3 0" max="3 4 1" thickness=".05">
        (9) 刻印機 #2:  
        デフォルト設定。  
        上級回路プレスと4つの加速カードを搭載
        <Row><ItemImage id="logic_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="3 5 1" thickness=".05">
        (10) 刻印機 #3:  
        デフォルト設定。  
        計算プレスと4つの加速カードを搭載
        <Row><ItemImage id="calculation_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="3 6 1" thickness=".05">
        (11) 刻印機 #4:  
        デフォルト構成。  
        エンジニアリングプレスと4つの加速カードを搭載
        <Row><ItemImage id="engineering_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 0" max="1 3 1" thickness=".05">
        (12) 刻印機 #5:  
        デフォルト設定。  
        4つの加速カードを搭載
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 2 0" max="3 1 1" thickness=".05">
        (13) インポートバス #1:  
        デフォルト設定。  
        2つの加速カードを搭載
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 4 0" max="3 3 1" thickness=".05">
        (14) インポートバス #2:  
        デフォルト設定。  
        2つの加速カードを搭載
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 5 0" max="3 4 1" thickness=".05">
        (15) インポートバス #3:  
        デフォルト設定。  
        2つの加速カードを搭載
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 6 0" max="3 5 1" thickness=".05">
        (16) インポートバス #4:  
        デフォルト設定。  
        2つの加速カードを搭載
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 3 0" max="1 3.3 1" thickness=".05">
        (17) ストレージ バス #2:  
        デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1.7 0" max="1 2 1" thickness=".05">
        (18) ストレージ バス #3:  
        デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 0" max="0.7 3 1" thickness=".05">
        (19) インポートバス #5:  
        デフォルト設定。  
        2つの加速カードを搭載
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="5 0.7 0" max="6 1 1" thickness=".05">
        (20) ストレージ バス #4:  
        デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3.3 2.7 0.3" max="3.7 3 0.7" thickness=".05">
        クォーツファイバーは、3つの刻印機すべてに電力を供給します。  
        刻印機はケーブルのように機能し、エネルギーを伝達します。
  </BoxAnnotation>

  <DiamondAnnotation pos="7 1.5 0.5" color="#00ff00">
        メインネットワークへ
  </DiamondAnnotation>

  <IsometricCamera yaw="185" pitch="5" />
</GameScene>

## 構成

* <ItemLink id="pattern_provider" /> (1) は、関連する<ItemLink id="processing_pattern" />とともにデフォルト設定になっています。
  パターンは原材料から完成したプロセッサへ直接つながっており、[プレス](../items-blocks-machines/presses.md)は**含まない**ことに注意してください。

  ![Logic Pattern](../assets/diagrams/logic_pattern.png)
  ![Calculation Pattern](../assets/diagrams/calculation_pattern.png)
  ![Engineering Pattern](../assets/diagrams/engineering_pattern.png)

* <ItemLink id="storage_bus" />(2、17、18、20) はデフォルト設定になっています。
* <ItemLink id="export_bus" />(3-7) は関連する成分にフィルターされています。  
  これらには2つの<ItemLink id="speed_card" />があります。
    <Row>
      <ItemImage id="silicon" scale="2" />
      <ItemImage id="minecraft:gold_ingot" scale="2" />
      <ItemImage id="certus_quartz_crystal" scale="2" />
      <ItemImage id="minecraft:diamond" scale="2" />
      <ItemImage id="minecraft:redstone" scale="2" />
    </Row>
* <ItemLink id="import_bus" />(13-16、19)はデフォルト設定になっています。これらには2つの<ItemLink id="speed_card" />があります。
* <ItemLink id="inscriber" />はデフォルト設定になっています。これらには関連する[金型](../items-blocks-machines/presses.md)と4つの<ItemLink id="speed_card" />があります。
   <Row>
     <ItemImage id="silicon_press" scale="2" />
     <ItemImage id="logic_processor_press" scale="2" />
     <ItemImage id="calculation_processor_press" scale="2" />
     <ItemImage id="engineering_processor_press" scale="2" />
   </Row>

## 仕組み

1. <ItemLink id="pattern_provider" />は、材料を樽に押し込みます。
2. 最初の[パイプサブネット](pipe-subnet.md)(オレンジ)は、シリコン、レッドストーンダスト、および関連するプロセッサの材料  
   (金のインゴット、Certusクォーツクリスタル、またはダイヤモンド)  
   を樽から引き出し、関連する<ItemLink id="inscriber" />に入れます。
3. 最初の4つの<ItemLink id="inscriber" />は、<ItemLink id="printed_silicon" />と、<ItemLink id="printed_logic_processor" />、<ItemLink id="printed_calculation_processor" />、または<ItemLink id="printed_engineering_processor" />を作成します。
4. 2番目と3番目の[パイプサブネット](pipe-subnet.md)(緑)は、最初の4つの<ItemLink id="inscriber" />からプリント回路を取り出し、5番目の最終アセンブリ<ItemLink id="inscriber" />に配置します。
5. 5番目の<ItemLink id="inscriber" />は、[プロセッサ](../items-blocks-machines/processors.md)を組み立てます。
6. 4番目の[パイプサブネット](pipe-subnet.md)(紫)は、プロセッサをパターンプロバイダーに配置し、メインネットワークに戻します。