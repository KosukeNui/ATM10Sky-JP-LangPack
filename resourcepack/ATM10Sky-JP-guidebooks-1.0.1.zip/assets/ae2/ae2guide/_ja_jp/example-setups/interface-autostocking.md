---
navigation:
  parent: example-setups/example-setups-index.md
  title: インターフェースアイテム保持機構
  icon: interface
---

# インターフェースアイテム保持機構

「さまざまなアイテムを一定量在庫しておき、必要に応じてさらに作成するにはどうすればいいですか?」と疑問に思う人もいるかもしれません。

1つの解決策は、<ItemLink id="interface" />と<ItemLink id="crafting_card" />を使用して、  
ネットワークの[自動クラフト](../ae2-mechanics/autocrafting.md)から新しいアイテムを自動的に要求することです。  
この設定は、少量のさまざまなアイテムを管理するのに適しています。

このデモセットアップは、あまり広くならないように短くカットされています。  
通常の[ケーブル](../items-blocks-machines/cables.md)の8つの[チャンネル](../ae2-mechanics/channels.md)すべてを使用するには、  
4つの<ItemLink id="interface" />と4つの<ItemLink id="storage_bus" />を使用するのが最適であると考えられます。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_autostocking.snbt" />

  <BoxAnnotation color="#dddddd" min="0 0 0" max="2 1 1">
    (1) インターフェース:  
    必要なアイテムをそれ自体の中に保持するように設定します。  
    クラフトカードがあります。
    <ItemImage id="crafting_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 0" max="2 1.3 1">
    (2) ストレージバス:  
    「入力/出力モード」が「抽出のみ」に設定されています。
  </BoxAnnotation>

  <DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
    メインネットワークへ
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 構成

* <ItemLink id="interface" /> (1) は、必要なアイテムを上部のスロットにクリックするか、JEIから上部のスロットにドラッグして、  
  スロットの上にあるレンチアイコンをクリックして数量を設定することで、必要なアイテムを内部に保持するように設定されています。  
  <ItemLink id="crafting_card" /> があります。
* <ItemLink id="storage_bus" /> (2) は、「入力/出力モード」が「抽出のみ」に設定されるように設定されています。

## 仕組み

1. <ItemLink id="interface" />が[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)から構成済みアイテムを十分に取得できない場合、  
   (<ItemLink id="crafting_card" />がある場合)、ネットワークの[自動クラフト](../ae2-mechanics/autocrafting.md)にそのアイテムをさらにクラフトするように要求します。
2. <ItemLink id="storage_bus" />により、ネットワークはインターフェイスの内容にアクセスできます。