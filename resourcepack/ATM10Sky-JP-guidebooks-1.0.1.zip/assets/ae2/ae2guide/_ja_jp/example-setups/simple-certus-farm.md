---
navigation:
  parent: example-setups/example-setups-index.md
  title: シンプルなケルタスファーム
  icon: certus_quartz_crystal
  position: 110
---

# シンプルなケルタスファーム

[ケルタスの成長](../ae2-mechanics/certus-growth.md)で述べたように、  
<ItemLink id="certus_quartz_crystal" />の収穫の自動化には<ItemLink id="annihilation_plane" />と<ItemLink id="storage_bus" />が関係します。  
<ItemLink id="growth_accelerator" />は、ケルタスクォーツの芽の成長を大幅に加速するために使用され、  
その後、プレーンは完全に成長した<ItemLink id="quartz_cluster" />を破壊します。  
これらは、未成熟のケルタスの芽が何もドロップせず、代わりに<ItemLink id="certus_quartz_dust" />をドロップするという、  
疑わしいほど幸運な特性を利用してフィルタリングされます。

この機構は<ItemLink id="flawless_budding_quartz" />では完全に自動で動作しますが、  
傷ついた、角の欠けた、壊れかけの芽生えたケルタスクォーツの場合は、出芽ブロックを手動で交換する必要があります。  
または、[半自動ケルタスファーム](semiauto-certus-farm.md)および[高度なケルタスファーム](advanced-certus-farm.md)で説明されているように、自動的に動作します。

推定の速度は[ケルタスの成長](../ae2-mechanics/certus-growth.md)を参照してください。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/simple_certus_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="3.7 1 1" max="4 2 2">
    (1) 消滅プレーン:  
    設定するGUIはありませんが、幸運のエンチャントができます。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="3.3 2 2">
    (2) ストレージバス #1:  
    ケルタスクォーツにフィルタリングされます。
    <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 .7" max="2 2 1">
    (3) ストレージバス #2:  
    ケルタスクォーツにフィルタリングされます。  
    メインストレージよりも高い優先度が設定されています。
    <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
    メインネットワークへ
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 構成

* 最初の<ItemLink id="annihilation_plane" />(1) にはGUIがなく、設定できませんが、幸運でエンチャントできます。
* 最初の<ItemLink id="storage_bus" />(2) は<ItemLink id="certus_quartz_crystal" />にフィルターされます。
* 2番目の<ItemLink id="storage_bus" />(3) は<ItemLink id="certus_quartz_crystal" />にフィルターされ、  
  その[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)はメインストレージよりも高く設定されています。

## 仕組み

1. <ItemLink id="annihilation_plane" />は目の前にあるものを破壊しようとしますが、サブネット上の唯一のストレージは<ItemLink id="storage_bus" />であり、  
   <ItemLink id="certus_quartz_crystal" />にフィルターされているため、破壊できるのは<ItemLink id="quartz_cluster" />だけです。
2. 最初の<ItemLink id="storage_bus" />は、バレル内のケルタスクォーツの水晶を保管します。
3. 2番目の<ItemLink id="storage_bus" />は、バレル内のすべてのケルタスクォーツの水晶へのメインネットワークアクセスを提供します。  
   これは、ケルタスクォーツの水晶がメインストレージではなくバレルに優先的に戻されるように、高い[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)に設定されています。
