---
navigation:
  parent: example-setups/example-setups-index.md
  title: 半自動ケルタスファーム
  icon: certus_quartz_crystal
  position: 115
---

# 半自動ケルタスファーム

残念ながら、[シンプルなケルタスファーム](simple-certus-farm.md)を完全に自動的に動作させるには、<ItemLink id="flawless_budding_quartz" />が必要です。  
これには、[空間IO](../ae2-mechanics/spatial-io.md)または[隕石](../ae2-mechanics/meteorites.md)にファームを構築する必要があります。

ただし、AE2はブロックを配置したり破壊したりできるので、ファームで *芽生えたケルタスクォーツを置き換える* ことも可能かもしれません。  
(定期的に、入力バレルに<ItemLink id="flawed_budding_quartz" />を挿入し、  
使用済みの芽生えたケルタスクォーツバレルから<ItemLink id="quartz_block" />を抽出する必要があります)

これを完全に自動的に行うには、[発展ケルタスファーム](advanced-certus-farm.md)を参照してください。

このファームは、[シンプルなケルタスファーム](simple-certus-farm.md)よりも少し複雑です。  
これは、実際には3つの個別のセットアップが詰め込まれているためです。

推定の速度は[ケルタスの成長](../ae2-mechanics/certus-growth.md)を参照してください。

**これは複雑な構造で、他のものの後ろに隠れているものがあります。パンしてあらゆる角度から見ることができます。**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/semiauto_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
    (1) 消滅プレーン #1:  
    設定するGUIはありませんが、幸運でエンチャントできます。
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1" max="2.3 3 2">
    (2) ストレージバス #1:  
    ケルタスクォーツにフィルタリングされます。
    <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    水晶破壊サブネット
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
    (3) 消滅プレーン #2:  
    設定するGUIはありませんが、シルクタッチがエンチャントされています。
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1" max="2.3 2 2">
    (4) ストレージバス #2:  
    ケルタスクォーツブロックにフィルタリングされます。
    <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    ケルタスブロック破壊サブネット
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
    (5) 形成プレーン:  
    デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0 1" max="2.3 1 2">
    (6) インポートバス:  
    デフォルト設定。
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    出芽ブロック配置サブネット
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="0.7 2 1" max="1 3 2">
    (7) ストレージバス #3:  
    ケルタスクォーツの水晶にフィルタリングされます。  
    メインストレージよりも高い優先度が設定されています。
    <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="1.5 0.5 1.5" color="#00ff00">
    傷ついた芽生えたケルタスクォーツを手動で挿入します。
    <BlockImage id="flawed_budding_quartz" scale="2" />
  </DiamondAnnotation>

  <DiamondAnnotation pos="1.5 1.5 1.5" color="#00ff00">
    ケルタスクォーツブロックを手動で回収します。
    <BlockImage id="quartz_block" scale="2" />
  </DiamondAnnotation>

  <DiamondAnnotation pos="0.5 0.5 0" color="#00ff00">
    メインネットワークへ
  </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## 構成

### 水晶破壊:

* 最初の<ItemLink id="annihilation_plane" />(1) にはGUIがなく、設定できませんが、幸運でエンチャントできます。
* 最初の<ItemLink id="storage_bus" />(2) は<ItemLink id="certus_quartz_crystal" />にフィルターされます。

### ケルタスブロック破壊:

* 2番目の<ItemLink id="annihilation_plane" />(3) にはGUIがなく、設定できませんが、シルクタッチでエンチャントする必要があります。
* 2番目の<ItemLink id="storage_bus" /> (4)は<ItemLink id="quartz_block" />にフィルターされます。

### 芽生えたブロック配置:

* <ItemLink id="formation_plane" />(5) はデフォルト設定です。
* <ItemLink id="import_bus" />(6) はデフォルト設定です。

### メインネットワーク:

* 3番目の<ItemLink id="storage_bus" />(7) は<ItemLink id="certus_quartz_crystal" />にフィルターされ、  
  その[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)はメインストレージよりも高く設定されています。

## 仕組み

### 水晶破壊:

水晶破壊サブネットは、[シンプルなケルタスファーム](simple-certus-farm.md)のサブネットと非常によく似た動作をします。

1. <ItemLink id="annihilation_plane" />は目の前にあるものを破壊しようとしますが、破壊できるのは<ItemLink id="quartz_cluster" />だけです。
   サブネット上の唯一のストレージは<ItemLink id="storage_bus" />であり、<ItemLink id="certus_quartz_crystal" />にフィルターされているためです。
2. <ItemLink id="storage_bus" />はケルタスクォーツの水晶をバレル内に保管します。

### ケルタスブロック破壊:

ケルタスブロック破壊サブネットは、傷ついた芽生えたブロックが<ItemLink id="quartz_block" />に変わったら、それを破壊するために役立ちます。
水晶破壊と同様に機能します。

1. <ItemLink id="annihilation_plane" />は、目の前にあるものを破壊しようとしますが、破壊できるのは<ItemLink id="quartz_block" /> だけです。
   サブネット上の唯一のストレージは<ItemLink id="storage_bus" />であり、<ItemLink id="quartz_block" />にフィルターされているためです。
   プレーンにはシルクタッチが必要です。そうすることで、芽生えたブロックは破壊されても劣化せず、  
   プレーンが早期に破壊することはありません。
2. <ItemLink id="storage_bus" />は、使用済みの芽生えたケルタスバレルにケルタスクォーツブロックを保管します。  
   更新するには、<ItemLink id="charged_certus_quartz_crystal" /> で手動で水に投げ込む必要があります。

### 芽生えたブロック配置:

芽生えたブロック配置サブネットは、ブロック破壊サブネットが古いブロックを破壊したときに、  
新しい<ItemLink id="flawed_budding_quartz" />を配置するために使用されます。

1. <ItemLink id="import_bus" />は、入力バレルから芽生えたブロックをインポートします。
2. サブネット上の唯一のストレージは、出芽ブロックを配置する<ItemLink id="formation_plane" />です。

### メインネットワーク:

* <ItemLink id="storage_bus" />は、メインネットワーク(および[自動化チャージャー](charger-automation.md))に、  
  バレル内のすべてのケルタスクォーツの水晶へのアクセスを提供します。  
  これは、ケルタスクォーツの水晶がメインストレージではなくバレルに優先的に戻されるように、  
  高い[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)に設定されています。