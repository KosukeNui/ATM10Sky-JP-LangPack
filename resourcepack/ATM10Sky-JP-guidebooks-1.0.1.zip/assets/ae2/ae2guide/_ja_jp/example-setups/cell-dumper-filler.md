---
navigation:
  parent: example-setups/example-setups-index.md
  title: セルダンパー/フィラー
  icon: io_port
---

# セルダンパー/フィラー

「チェストやドロワー、バックパックにセルの中身をすばやく移すにはどうすればよいですか?、  
あるいは逆に、セルからセルへ中身を移すにはどうすればよいですか?」と疑問に思う人もいるかもしれません。

答えは、<ItemLink id="io_port" />といくつかのサブネットを使用して、  
アイテムを配置したり、搬入したりできる場所を制限することです。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/cell_dumper_filler.snbt" />

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 1">
        (1) 入出力ポート:  
        GUIの中央にある矢印ボタンを使用して、  
        「ネットワークへのデータ転送」または「ストレージセルへのデータ転送」  
        のいずれかに設定できます。加速カードは3枚あります。
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0.7 0" max="1 1 1">
        (2) ストレージバス:  
        デフォルト設定です。
  </BoxAnnotation>

  <BoxAnnotation color="#33dd33" min="0 1 0" max="1 2 1">
        ここにアイテムを入れたり空にしたりしたいものを置きます。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 0.35 0.35" max="2.3 0.65 0.65">
        クォーツファイバー:  
        エネルギー源が別のネットワークである場合にのみ必要です。
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 0.5" color="#00ff00">
        別のネットワークやエナジーアクセプターなど、何らかのエネルギー源に。
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 構成

* <ItemLink id="io_port" /> (1) GUIの中央にある矢印ボタンを使用して、  
        「ネットワークへのデータ転送」または「ストレージセルへのデータ転送」  
        のいずれかに設定できます。加速カードは3枚あります。
* <ItemLink id="storage_bus" /> (2) デフォルト設定です。

## 仕組み

### ネットワークへ転送の場合

1. <ItemLink id="io_port" />は、挿入された[ストレージセル](../items-blocks-machines/storage_cells.md)の内容を  
   [ネットワークストレージ](../ae2-mechanics/import-export-storage.md)にダンプしようとします。
2. サブネット上の唯一のストレージは<ItemLink id="storage_bus" />で、その前に置いたアイテムや液体などをそこに保存します。
* <ItemLink id="energy_cell" />は、ゲームティックごとに大量のアイテムを転送することによる電力消費でネットワークが枯渇しないように、  
  十分な大きさの [エネルギー](../ae2-mechanics/energy.md)バッファーを提供します。

### ストレージセルへ転送の場合

1. <ItemLink id="io_port" />は、[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)の内容を、  
   挿入された[ストレージセル](../items-blocks-machines/storage_cells.md)にダンプしようとします。
2. サブネット上の唯一のストレージは<ItemLink id="storage_bus" />で、これはその前に置かれたものからアイテムや流体などを取得します。
* <ItemLink id="energy_cell" /> は、ゲームティックごとに大量のアイテムを転送することによる電力消費でネットワークが不足しないように、  
  十分な大きさの[エネルギー](../ae2-mechanics/energy.md)バッファーを提供します。