---
navigation:
  parent: example-setups/example-setups-index.md
  title: パイプサブネット
  icon: storage_bus
---

# パイプサブネット

AE2[デバイス](../ae2-mechanics/devices.md)を使用してアイテムや流体パイプをエミュレートする簡単な方法。  
アイテムや流体パイプを使用するあらゆる用途に役立ちます。  
これには、クラフトの結果を<ItemLink id="pattern_provider" />に返すことも含まれます。

これを達成するには一般的に2つの方法があります:

## インポートバス -> ストレージバス

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />

  <BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
    (1) インポートバス: フィルタリングできます。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
    (2) ストレージバス:  
    フィルターできます。  
    このストレージバス(および宛先にする他のストレージバス)は、  
    ネットワーク上の唯一のストレージである必要があります。
  </BoxAnnotation>

  <DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
    搬出元
  </DiamondAnnotation>

  <DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
    搬出先
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ソースインベントリの<ItemLink id="import_bus" /> (1) はアイテムまたは流体をインポートし、[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)に保存しようとします。
ネットワーク上の唯一のストレージは<ItemLink id="storage_bus" /> (2)であるため(これがサブネットであり、メインネットワークではない理由です)、
アイテムまたは流体は宛先インベントリに配置され、転送されます。エネルギーは<ItemLink id="quartz_fiber" />を通じて提供されます。
インポートバスとストレージバスの両方をフィルターできますが、
フィルターが適用されていない場合は、アクセスできるすべてのものが転送されます。
このセットアップは、複数のインポートバスと複数のストレージバスでも機能します。

## ストレージバス -> エクスポートバス

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/storage_export_pipe.snbt" />

  <BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
    (1) ストレージバス:  
    フィルターできます。  
    このストレージバス(およびソースにする他のストレージバス)は、  
    ネットワーク上の唯一のストレージである必要があります。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
    (2) エクスポートバス: フィルタリングする必要があります。
  </BoxAnnotation>

  <DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
    搬出元
  </DiamondAnnotation>

  <DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
    搬出先
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

宛先インベントリの<ItemLink id="export_bus" />は、フィルター内のアイテムを[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)から取得しようとします。
ネットワーク上の唯一のストレージは<ItemLink id="storage_bus" />であるため(これがサブネットであり、メインネットワークではない理由です)、
アイテムまたは流体はソースインベントリから取得され、転送されます。
エネルギーは<ItemLink id="quartz_fiber" />を通じて提供されます。
エクスポートバスはフィルター処理されて機能する必要があるため、この設定はエクスポートバスをフィルター処理した場合にのみ機能します。
この設定は、複数のストレージバスと複数のエクスポートバスでも機能します。

## 動作しない構成(インポートバス -> エクスポートバス)

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_export_pipe.snbt" />

  <BoxAnnotation color="#dd3333" min="3.7 0 0" max="4 1 1">
    インポートバス:  
    ネットワークにストレージがないため、  
    インポートする場所がありません。
  </BoxAnnotation>

  <BoxAnnotation color="#dd3333" min="1 0 0" max="1.3 1 1">
    (2) エクスポートバス:  
    ネットワークにはストレージがないため、  
    エクスポートするものがありません。
  </BoxAnnotation>

  <DiamondAnnotation pos="4.5 0.5 0.5" color="#ff0000">
    搬出元
  </DiamondAnnotation>

  <DiamondAnnotation pos="0.5 0.5 0.5" color="#ff0000">
    搬出先
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

インポートバスとエクスポートバスのみのセットアップは機能しません。
インポートバスはソースインベントリからアイテムまたは流体をプルし、ネットワークストレージに保管しようとします。
エクスポートバスはネットワークストレージからアイテムまたは流体をプルし、宛先インベントリにアイテムまたは流体を保管しようとします。
ただし、このネットワークには **ストレージがない**ため、
インポートバスはインポートできず、エクスポートバスはエクスポートできず、何も起こりません。

## 1つの面からの入力と出力

入力を受け取り、その出力を1つの面から引き出すことができるマシンがあるとします。(<ItemLink id="charger" />のように)
2つのパイプサブネットメソッドを組み合わせることで、材料を押し込み、結果を引き出すことができます:

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_export_pipe.snbt" />

  <BoxAnnotation color="#dddddd" min="4 1 1" max="5 1.3 2">
    (1) インポートバス: フィルタリングできます。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
    (2) ストレージバス:  
    フィルターできます。
    このストレージバス(およびアイテムをプッシュおよびプルする他のストレージバス)は、
    ネットワーク上の唯一のストレージである必要があります。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
    (3) 搬入出したいもの、この場合は充電器。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 1" max="1 1.3 2">
    (4) エクスポートバス: フィルタリングする必要があります。
  </BoxAnnotation>

  <DiamondAnnotation pos="4.5 0.5 1.5" color="#00ff00">
    搬出元
  </DiamondAnnotation>

  <DiamondAnnotation pos="0.5 0.5 1.5" color="#00ff00">
    搬出先
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## インターフェース

インポートバスとエクスポートバスの他に、[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)にアイテムをプッシュしたり、  
そこからアイテムをプルしたりする[デバイス](../ae2-mechanics/devices.md)があることがわかりました。  
ここで重要なのは<ItemLink id="interface" />です。  
インターフェースがストックに設定されていないアイテムが挿入されると、インターフェイスはそれをネットワークストレージにプッシュします。  
これは、インポートバス -> ストレージバスパイプと同様に利用できます。  
インターフェースを何らかのアイテムをストックするように設定すると、ストレージバス->エクスポートバスパイプと同様に、  
ネットワークストレージからアイテムがプルされます。  
インターフェースは、一部のアイテムをストックし、他のアイテムをストックしないように設定できるため、  
何らかの理由でストレージバスを介してリモートでプッシュおよびプルできます。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/interface_pipes.snbt" />

  <BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
    インターフェース
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
    ストレージバス
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3.7 0 2" max="4 1 3">
    ストレージバス
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 2" max="1 1.3 3">
    インターフェース
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 1対多と多対1（および多対多）

もちろん、<ItemLink id="import_bus" />または<ItemLink id="export_bus" />または<ItemLink id="storage_bus" />のいずれか1つだけを使用する必要はありません。

<GameScene zoom="3" background="transparent">
<ImportStructure src="../assets/assemblies/many_to_many_pipe.snbt" />

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## 複数の場所への提供

これらすべてから、1つの<ItemLink id="pattern_provider" />面から、
マシンの配列や1台のマシンの複数の異なる面など、さまざまな場所に材料を送る方法を導き出すことができます。

<ItemLink id="pattern_provider" />には実際には材料が含まれていないため、
インポート->ストレージパイプやストレージ->エクスポートパイプは必要ありません。
代わりに、プロバイダーは材料を隣接するインベントリにプッシュするため、
アイテムをインポートできる隣接するインベントリが必要です。

これは...<ItemLink id="interface" />のようです!
プロバイダーが方向性またはフラットサブパートモードになっているか、
インターフェイスがフラットサブパートモードになっていることを確認してください。
そうすることで、2つがネットワーク接続を形成しなくなります。

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
    インターフェース（フルブロックではなくフラットである必要があります）
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
    ストレージバス
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
    パターン提供したい場所（複数台、または1台の複数面）
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>