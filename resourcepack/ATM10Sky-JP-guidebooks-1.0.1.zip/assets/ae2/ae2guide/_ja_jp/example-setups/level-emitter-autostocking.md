---
navigation:
  parent: example-setups/example-setups-index.md
  title: レベルエミッターアイテム保持機構
  icon: level_emitter
---

# レベルエミッターアイテム保持機構

「一定量のアイテムを在庫として保持し、必要に応じてさらに作成するにはどうすればいいですか?」と疑問に思う人もいるかもしれません。

1つの解決策は、<ItemLink id="export_bus" />、<ItemLink id="level_emitter" />、<ItemLink id="crafting_card" />を使用して、
ネットワークの[自動クラフト](../ae2-mechanics/autocrafting.md)から新しいアイテムを自動的に要求することです。
この設定は、1つのアイテムを大量に維持するためのものです。

もちろん、レベルエミッターとレッドストーンカードを省けば、ネットワークに休みなくクラフトさせることもできます。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/level_emitter_autostocking.snbt" />

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
    (1) エクスポートバス:  
    目的のアイテムにフィルターされます。  
    レッドストーンカードとクラフトカードがあります。  
    レッドストーンモードは「信号でアクティブ」に設定され、  
    クラフト動作は「在庫アイテムを使用しない」に設定されています。
    <Row><ItemImage id="redstone_card" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0.7 1 0" max="1 2 1">
    (2) レベルエミッター:  
    必要なアイテムと数量で構成され、  
    「レベルが制限を下回ったときに放出する」ように設定されます。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
    (3) インターフェース: デフォルト設定。
  </BoxAnnotation>

  <DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
    メインネットワークへ
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 構成

* <ItemLink id="export_bus" /> (1) は、目的のアイテムにフィルターされています。<ItemLink id="redstone_card" />と<ItemLink id="crafting_card" />があります。
「レッドストーン モード」は「信号でアクティブ」に設定され、「クラフト動作」は「在庫アイテムを使用しない」に設定されています。
* <ItemLink id="level_emitter" /> (2) は、目的のアイテムと数量で構成され、「レベルが制限を下回ったときに放出」に設定されています。
* <ItemLink id="interface" /> (3) は、デフォルト構成になっています。

## 仕組み

1. [ネットワークストレージ](../ae2-mechanics/import-export-storage.md)内の目的のアイテムの量が<ItemLink id="level_emitter" />で指定された数量を下回る場合、レッドストーン信号が発せられます。
2. レッドストーン信号を受信すると(<ItemLink id="crafting_card" />により、ストックされたアイテムを使用しないように設定されているため)、  
   <ItemLink id="export_bus" />はネットワークの[自動クラフト](../ae2-mechanics/autocrafting.md) に目的のアイテムをさらに作成するよう要求し、それをエクスポートします。
3. アイテムがプッシュされると(内部インベントリに何も格納しないように設定されていない場合)、  
   <ItemLink id="interface" />はそのアイテムをネットワークストレージにプッシュします。