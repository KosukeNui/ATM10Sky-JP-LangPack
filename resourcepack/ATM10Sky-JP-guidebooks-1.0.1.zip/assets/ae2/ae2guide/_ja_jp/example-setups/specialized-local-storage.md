---
navigation:
  parent: example-setups/example-setups-index.md
  title: 特別なローカルストレージ
  icon: drive
---

# 特別なローカルストレージ

[インターフェースの特別な動作](../items-blocks-machines/interface.md#special-interactions)の1つを利用すると、
[サブネットワーク](../ae2-mechanics/subnetworks.md)は、メインネットワークのストレージを表示することなく、
ストレージの内容をメインネットワークに提示でき、1つの[チャンネル](../ae2-mechanics/channels.md)のみを占有します。

これは、アイテムがメインストレージにオーバーフローしないように、ファームのローカルストレージに便利です。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/local_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="4 0 0" max="5 2 1">
    (1) アイテムをインポートする何らかの方法  
    （この場合はインターフェース）
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 0 0" max="4 1 1">
    (2) ドライブ:  
    セルがいくつか入っています。  
    セルはファームの出力に応じてフィルタリングされます。  
    セルには等分配カードとオーバーフロー破棄カードを入れることができます。
    <Row><ItemImage id="item_storage_cell_4k" scale="2" /> <ItemImage id="equal_distribution_card" scale="2" /> <ItemImage id="void_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 0" max="4 2 0.3">
    (3) クラフトターミナル:  
    サブネット上のドライブの内容は表示できますが、  
    メインネットワークのストレージの内容は表示できません。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
    (4) インターフェース #2:  
    デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.7 0 0" max="2 1 1">
    (5) ストレージバス:  
    メインストレージよりも高い優先度が設定されており、  
    ファームの出力に応じてフィルター処理できます。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 0.3">
    クラフトターミナル:  
    メインネットワークのストレージと  
    サブネットワークの両方の内容を表示できます。
  </BoxAnnotation>

  <DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
    メインネットワークへ
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 設定

* 最初の<ItemLink id="interface" />(1) は、所有しているファームからアイテムを受け入れ、サブネットにプッシュするだけです。
* <ItemLink id="drive" />(2) にはいくつかの[セル](../items-blocks-machines/storage_cells.md)があります。  
  セルは、ファームの出力に応じて[パーティション分割](../items-blocks-machines/cell_workbench.md)する必要があります。
  セルには、<ItemLink id="equal_distribution_card" />と<ItemLink id="void_card" />を含めることができます。
* 2番目の<ItemLink id="interface" />(4) は、デフォルト設定です。
* <ItemLink id="storage_bus" />の[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)は、  
  メインストレージよりも高く設定されています。ファームの出力に応じてフィルタリングできます。

## 仕組み

* サブネット上の<ItemLink id="interface" />は、メインネットワーク上の<ItemLink id="storage_bus" />に<ItemLink id="drive" />の内容を表示します。  
  つまり、ストレージバスは、ドライブ内のセルからアイテムを直接引き出したり、ドライブ内のセルにアイテムをプッシュしたりできます。
* ストレージバスは高い[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)に設定されているため、  
  アイテムはメインストレージではなくサブネットに優先的に戻されます。
* 重要なのは、サブネット内のセルがいっぱいになっても、アイテムがメインネットワークにオーバーフローしないということです。  
  ファームがバックアップすると壊れるタイプの場合は、代わりに <ItemLink id="void_card" /> を使用して余分なアイテムを削除できます。
* ファームが複数のアイテムを出力する場合、<ItemLink id="equal_distribution_card" />により、  
  1つのアイテムがすべてのセルを埋め尽くして、他のアイテムが保存されないようにすることができます。