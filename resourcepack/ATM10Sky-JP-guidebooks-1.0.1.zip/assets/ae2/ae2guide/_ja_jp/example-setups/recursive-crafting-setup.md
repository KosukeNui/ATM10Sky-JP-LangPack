---
navigation:
  parent: example-setups/example-setups-index.md
  title: 再帰クラフト
  icon: minecraft:netherite_upgrade_smithing_template
---

# 再帰クラフトのセットアップ

[自動クラフト](../ae2-mechanics/autocrafting.md)で述べたとおり、自動クラフトの計画アルゴリズムは、
主な出力が入力の1つでもあるレシピを扱えません。たとえば、<ItemLink id="minecraft:netherite_upgrade_smithing_template" />の複製は扱えません。

解決策の1つは、<ItemLink id="level_emitter" />が[パターン](../items-blocks-machines/patterns.md)のふりをできる機能を使うことです。

これを使って、クラフトを休みなく行う小さなセットアップの電源を入れます。ここでは、
<ItemLink id="minecraft:netherite_upgrade_smithing_template" />を複製するセットアップを見てみましょう。

<RecipeFor id="minecraft:netherite_upgrade_smithing_template" />

***

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/recursive_recipe_setup.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) インターフェース: 追加で必要な材料(ダイヤモンドとネザーラック)を在庫として保つように設定。
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="minecraft:netherrack" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 1 0.3" max="2.7 1.3 0.7">
        (2) レベルエミッター: 「ネザライトの鍛冶型」を設定し、「アイテムをクラフトしたときレッドストーン出力」に設定。
        <Row><ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        (3) インポートバス1: インターフェースが在庫として保つアイテムにフィルター。レッドストーンカードを入れる。レッドストーンモードは
        「信号有りで有効」に設定。
        <Row>
        <ItemImage id="minecraft:diamond" scale="2" />
        <ItemImage id="minecraft:netherrack" scale="2" />
        <ItemImage id="redstone_card" scale="2" />
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        (4) ストレージバス1: もう1つのストレージバスより高い優先度に設定。とても重要です。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 0 1" max="4 1 2">
        (5) 分子組立機: 鍛冶型を複製するパターンを入れる。

        ![Pattern](../assets/diagrams/smithing_template_pattern_small.png)

        最初に作るときに、鍛冶型を1つ手で入れておく。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        (6) インポートバス2: デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="2 1 1.3">
        (7) ストレージバス2: 「ネザライトの鍛冶型」にフィルター。もう1つのストレージバスより低い優先度に設定。
        <ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        メインネットワークへ
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

## 構成

* <ItemLink id="interface" />(1) は、追加で必要な材料(ダイヤモンドとネザーラック)を在庫として保つように設定しています。
* <ItemLink id="level_emitter" />(2) は「ネザライトの鍛冶型」を設定し、「アイテムをクラフトしたときレッドストーン出力」に設定しています。
* 1つ目の<ItemLink id="import_bus" />(3) は、インターフェースが在庫として保つアイテムにフィルターをかけています。レッドストーンカードを入れ、レッドストーンモードを「信号有りで有効」に設定しています。
* 1つ目の<ItemLink id="storage_bus" />(4) は、2つ目のストレージバスより*高い*[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)に設定しています。
* <ItemLink id="molecular_assembler" />(5) には、鍛冶型を複製するパターンと、手で入れておいた鍛冶型1つが入っています。

  ![Pattern](../assets/diagrams/smithing_template_pattern.png)

* 2つ目の<ItemLink id="import_bus" />(6) はデフォルト設定です。
* 2つ目の<ItemLink id="storage_bus" />(7) は「ネザライトの鍛冶型」にフィルターをかけています。1つ目のストレージバスより*低い*[優先度](../ae2-mechanics/import-export-storage.md#storage-priority)です。

## 仕組み

1. <ItemLink id="level_emitter" />は、<ItemLink id="crafting_card" />が入っていて「アイテムをクラフトしたときレッドストーン出力」に設定されているため、
   [パターン](../items-blocks-machines/patterns.md)のふりをします。そのため、「ネザライトの鍛冶型」が
   [自動クラフト](../ae2-mechanics/autocrafting.md)できるものとして[ターミナル](../items-blocks-machines/terminals.md)に表示されます。
2. プレイヤーまたはシステム自身からそのアイテムのクラフトの依頼を受けると、レベルエミッターがオンになります。
3. 1つ目の<ItemLink id="import_bus" />がレベルエミッターによって動き出し、<ItemLink id="interface" />に在庫として保たれている材料を取り出します。
4. ネットワーク上でその材料を格納できる<ItemLink id="storage_bus" />は、組立機に付いているものだけです。
5. <ItemLink id="molecular_assembler" />が材料を受け取り(中にはすでに鍛冶型が1つある)、クラフトを行って鍛冶型を2つ作ります。
6. 2つ目の<ItemLink id="import_bus" />が鍛冶型を1つ取り出します。
7. 1つ目のストレージバスのほうが優先度が高いので、その鍛冶型は組立機に戻ります。
8. 2つ目の<ItemLink id="import_bus" />がもう1つ鍛冶型を取り出します。
9. 組立機はもう鍛冶型を受け取れないので、2つ目の鍛冶型は優先度の低いストレージバスへ行き、インターフェースに入ります。
10. <ItemLink id="interface" />は鍛冶型を在庫として保つ設定になっていないので、それをネットワークへ入れます。
