---
navigation:
  parent: example-setups/example-setups-index.md
  title: チャージャー自動化
  icon: charger
---

# チャージャー自動化

これは<ItemLink id="pattern_provider" />を使用するため、  
[自動クラフト](../ae2-mechanics/autocrafting.md)セットアップに統合されることを意図していることに注意してください。  
<ItemLink id="charger" />を自動化したいだけの場合は、ホッパーやチェストなどを使用してください。

<ItemLink id="charger" />の自動化は非常に簡単です。  
<ItemLink id="pattern_provider" />が成分を充電器に搬出し、次に[パイプサブネット](pipe-subnet.md)
または他のアイテムパイプが結果をプロバイダーに搬入します。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/charger_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
    (1) パターンプロバイダー:  
    デフォルト構成では、関連する処理パターンが含まれます。充電器に電力も供給します。

    ![Charger Pattern](../assets/diagrams/charger_pattern_small.png)
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 0" max="1 1.3 1">
    (2) インポートバス:  
    デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
    (3) ストレージバス:  
    デフォルト設定。
  </BoxAnnotation>

  <DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
    メインネットワークへ
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 構成

* <ItemLink id="pattern_provider" />(1)は、関連する<ItemLink id="processing_pattern" />とともにデフォルト構成になっています。  
  また、パターンプロバイダーは[ケーブル](../items-blocks-machines/cables.md)のように動作するため、<ItemLink id="charger" />に[エネルギー](../ae2-mechanics/energy.md)を提供します。
  
    ![Charger Pattern](../assets/diagrams/charger_pattern.png)

* <ItemLink id="import_bus" /> (2) はデフォルト設定です
* <ItemLink id="storage_bus" /> (3) はデフォルト設定です

## 仕組み

1. <ItemLink id="pattern_provider" />は、素材を<ItemLink id="charger" />に搬出します。
2. 充電器は充電を行います。
3. 緑のサブネット上の<ItemLink id="import_bus" />は、充電器から結果を引き出し、  
   それを[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)に保存しようとします。
4. 緑のサブネット上の唯一のストレージは<ItemLink id="storage_bus" />で、  
   結果のアイテムをパターンプロバイダーに保存し、メインネットワークに返します。
