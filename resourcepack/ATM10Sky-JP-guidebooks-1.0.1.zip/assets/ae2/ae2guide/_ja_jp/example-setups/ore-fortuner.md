---
navigation:
  parent: example-setups/example-setups-index.md
  title: 鉱石幸運採掘の自動化
  icon: minecraft:raw_iron
---

# 鉱石幸運採掘の自動化

<ItemLink id="annihilation_plane" />には、幸運を含むあらゆるつるはしエンチャントをエンチャントできるため、  
明らかな使用例は、少数に幸運を適用し、<ItemLink id="formation_plane" />と<ItemLink id="annihilation_plane" />で鉱石を素早く配置して破壊します。

<ItemLink id="import_bus" />は「すぐに安定稼働」するため、セットアップは低速で開始され、数秒で最高速度に達することに注意してください

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 0 2" max="3 1 3">
    (1) インポートバス:  
    いくつかの加速カードが入っています。
    <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 2" max="2 1 2.3">
    (2) 形成プレーン:  
    デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 0.7" max="2 1 1">
    (3) 消滅プレーン:  
    設定するためのGUIはありませんが、幸運のエンチャントがかけられています。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 0" max="3 1 1">
    (4) ストレージ バス:  
    デフォルト設定。
  </BoxAnnotation>

  <DiamondAnnotation pos="3.5 0.5 2.5" color="#00ff00">
    インプット
  </DiamondAnnotation>

  <DiamondAnnotation pos="3.5 0.5 0.5" color="#00ff00">
    アウトプット
  </DiamondAnnotation>

  <DiamondAnnotation pos="4 0.5 1.5" color="#00ff00">
    メインネットワークへ
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 構成

*   <ItemLink id="import_bus" />(1) には、いくつかの<ItemLink id="speed_card" />が入っています。  
    装置内の形成プレーンが多いほど、インポートバスが一度により多くのアイテムを搬入するため、より多くのアイテムが必要になります。
*   <ItemLink id="formation_plane" />(2) デフォルト設定。
*   <ItemLink id="annihilation_plane" />(3) 設定するためのGUIはありませんが、幸運のエンチャントがかけられています。
*   <ItemLink id="storage_bus" /> (4) デフォルト設定。

## 仕組み

1.  緑色のサブネット上の<ItemLink id="import_bus" />は、最初のバレルから[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)にブロックをインポートします。
2.  緑色のサブネット上の唯一のストレージは、ブロックを配置する<ItemLink id="formation_plane" /> です。
3.  オレンジ色のサブネット上の<ItemLink id="annihilation_plane" />がブロックを破壊し、幸運をもたらします。
4.  オレンジ色のサブネット上の<ItemLink id="storage_bus" />には、2番目のバレルの破壊の結果が保存されます。
