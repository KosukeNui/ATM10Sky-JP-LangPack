---
navigation:
  parent: example-setups/example-setups-index.md
  title: 丸石製造機
  icon: minecraft:cobblestone
---

# 丸石製造機

丸石生成器の自動化は簡単で、標準のバニラ手動丸石生成器に<ItemLink id="annihilation_plane" />を向けるだけです。  
ただし、これを行うと、最終的にはネットワークが玉石混交になってしまい、何らかの規制が必要となります。

消滅プレーンの仕組み(<ItemLink id="import_bus" />のように動作する)により、  
単純に<ItemLink id="level_emitter" />を<ItemLink id="export_bus" />に対向させて<ItemLink id="redstone_card" />を配置することはできません。  
(間にストレージがないとインポートからエクスポートに直接移動できないため)。  
もう少し遠回しにならなければなりません。

<ItemLink id="toggle_bus" />を使用すると、レッドストーン信号を使用してネットワークの一部を接続したり切断したりできますが、  
これを行うたびにネットワークが再起動されます。  
簡単な回避策として、トグルバスを[サブネットワーク](../ae2-mechanics/subnetworks.md)に配置して、サブネットのみを再起動するようにします。

自己完結型の<ItemLink id="annihilation_plane" />および<ItemLink id="storage_bus" />[サブネットワーク](../ae2-mechanics/subnetworks.md)を  
メインネットワーク上の<ItemLink id="interface" />に搬入することができます。  
トグルバスはサブネットを<ItemLink id="quartz_fiber" />に接続したり切断したりして、プレーンへの電力を遮断します。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/regulated_cobble_gen.snbt" />

  <BoxAnnotation color="#dddddd" min="3 2 2" max="7 2.3 3">
    (1) 消滅プレーン:  
    GUIで設定できませんが、  
    消費電力を減らすために効率と破壊力を強化することができます。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 2" max="2.3 3 3">
    (2) ストレージバス:  
    デフォルト構成です。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 2.3 2" max="2.7 2.7 2.3">
    (3) トグルバス:  
    とても重要なことですが、  
    トグルバスはメインネットではなくサブネット上に配置します。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 2.3" max="2.7 3.3 2.7">
    (4) レベルエミッター:  
    丸石と必要な量で構成され、  
    「レベルが制限を下回ったときに放出する」に設定されます。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 3" max="2 3 2">
    (5) インターフェース:  デフォルト設定。
  </BoxAnnotation>

  <DiamondAnnotation pos="0 2.5 1.5" color="#00ff00">
    メインネットワークへ
  </DiamondAnnotation>

  <DiamondAnnotation pos="5 1.5 3.5" color="#00ff00">
    水浸しの階段は水が流れて溶岩が黒曜石に変わるのを防ぎます。
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 構成

* <ItemLink id="annihilation_plane" />(1) GUIで設定できませんが、消費電力を減らすために効率と破壊力を強化することができます。
* <ItemLink id="storage_bus" /> (2) デフォルト構成です。
* <ItemLink id="toggle_bus" /> (3) とても重要なことですが、  トグルバスはメインネットではなくサブネット上に配置します。
* <ItemLink id="level_emitter" /> (4) 丸石と必要な量で構成され、「レベルが制限を下回ったときに放出する」に設定されます。
* <ItemLink id="interface" /> (5) デフォルト設定。

## 仕組み

1. 丸石製造機は丸石を作ります。
2. <ItemLink id="annihilation_plane" />が丸石を壊します。
3. <ItemLink id="storage_bus" />は丸石を<ItemLink id="interface" />に保存し、メインネットワークに送信します。
4. メインネットワーク内の丸石の量が設定量を超えると、<ItemLink id="level_emitter" />は信号の送信を停止し、<ItemLink id="toggle_bus" />をオフにします。
5. これによりサブネットワークへの電力が遮断され、消滅プレーンの動作が停止します。
