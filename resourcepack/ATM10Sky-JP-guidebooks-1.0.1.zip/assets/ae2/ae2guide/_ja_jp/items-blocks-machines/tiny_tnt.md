---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 極小TNT
  icon: tiny_tnt
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:tiny_tnt
---

# 極小TNT

<BlockImage id="tiny_tnt" scale="8" />

小さな爆発用の小さなTNT。  
<ItemLink id="quantum_entangled_singularity" />ペアを作成するのに便利です。

サーバー上でTNTとクリーパーを無効にしたい場合は、設定でブロックダメージを無効にして、  
荒らしの可能性なしに特異点を作成できるようにすることができます。

## レシピ

<RecipeFor id="tiny_tnt" />
