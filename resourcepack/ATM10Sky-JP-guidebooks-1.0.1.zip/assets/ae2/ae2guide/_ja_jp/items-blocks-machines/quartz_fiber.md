---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: クォーツファイバー
  icon: quartz_fiber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quartz_fiber
---

# クォーツファイバー

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/quartz_fiber.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

クォーツファイバーは、[ネットワーク](../ae2-mechanics/me-network-connections.md)間で電力を共有し、それらを分離するために使用されます。  
これにより、エナジーアクセプタと電源ケーブルをあらゆる場所に配置する必要なく、[サブネットワーク](../ae2-mechanics/subnetworks.md)に電力を供給できます。  
また、ケーブルが接続されないようにするためにも使用できますが、異なる色のケーブルを使用するか、  
<ItemLink id="cable_anchor" />を使用する方が安価で効果的です。

これらは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)です。

## レシピ

<RecipeFor id="quartz_fiber" />
