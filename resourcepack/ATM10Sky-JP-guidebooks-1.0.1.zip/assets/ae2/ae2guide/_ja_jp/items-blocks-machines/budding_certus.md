---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 芽生えたケルタスクォーツ
  icon: flawless_budding_quartz
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:flawless_budding_quartz
- ae2:flawed_budding_quartz
- ae2:chipped_budding_quartz
- ae2:damaged_budding_quartz
- ae2:small_quartz_bud
- ae2:medium_quartz_bud
- ae2:large_quartz_bud
- ae2:quartz_cluster
---

# 芽生えたケルタスクォーツ

([ケルタスの成長](../ae2-mechanics/certus-growth.md)も参照)

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ケルタスクォーツの芽は、アメジストと同様に、芽生えたケルタスブロックから生えてきます。  
これらは[隕石](../ae2-mechanics/meteorites.md)にあります。  
芽生えたケルタスブロックには、完璧な、傷ついた、角の欠けた、壊れかけの4段階があります。  
これらは、HWYLA、Jade、The One Probe などのmod(またはf3画面)で最も簡単に識別できます。

壊れかけの、角の欠けた、傷ついた芽生えたケルタスでは、  
芽が次の段階に成長するたびに、芽生えたブロックが1段階劣化し、  
最終的に普通の<ItemLink id="quartz_block" />になる可能性があります。

完璧な芽生えたケルタスクォーツは、芽が成長しても劣化せず、無限のソースとして機能します。

通常のつるはしで壊した場合、芽生えたケルタスブロックは1段階劣化します。  
シルクタッチのエンチャントが付与されたツルハシで破壊された場合、完璧でない場合、劣化しません。  
**つまり、完璧な芽生えたケルタスクォーツブロックはツルハシで拾って移動することはできません**。  
代わりに、[空間ストレージ](../ae2-mechanics/spatial-io.md)を使用して、  
完璧な芽生えたケルタスクォーツブロックをカット&ペーストすることができます。

## レシピ

壊れかけの、角の欠けた、傷ついた芽生えたケルタスは、  
前段階の芽生えたブロック(または<ItemLink id="quartz_block" />)を  
1つ以上の<ItemLink id="charged_certus_quartz_crystal" />とともに水に投げ込むことで作成できます。

完璧な芽生えたケルタスクォーツは作成できず、ワールド内でのみ見つかります。

<Row>
  <RecipeFor id="damaged_budding_quartz" />

  <RecipeFor id="chipped_budding_quartz" />

  <RecipeFor id="flawed_budding_quartz" />
</Row>
