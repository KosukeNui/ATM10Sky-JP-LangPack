---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: インターフェース
  icon: interface
  position: 210
categories:
- devices
item_ids:
- ae2:interface
- ae2:cable_interface
---

# インターフェース

<Row gap="20">
<BlockImage id="interface" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_interface.snbt" />
</GameScene>
</Row>

インターフェースは、スロットにストックしておくように設定した内容に応じて、  
[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)から充填したり、  
そこから排出したりする小さなチェストと液体タンクのように機能します。  
これは1ゲームティックで完了しようとするため、ゲームティックごとに最大9スタックを充填したり排出したりできるため、  
高速アイテムパイプがある場合は、インポートまたはエクスポートの高速な方法になります。

もう1つの便利な特性は、ほとんどの液体タンクは1種類の液体しか保存できないのに対し、  
インターフェースは最大9種類とアイテムを保存できることです。

基本的には、いくつかの追加機能を備えたチェスト/マルチ液体タンクであり、  
ネットワークから切断しておくことで、その追加機能を防ぐことができます。

したがって、少量のさまざまなものを保存したいというニッチなケースで役立ちます。

## インターフェースの内部動作

前述のとおり、インターフェースは基本的に、いくつかの超強力な<ItemLink id="import_bus" />と<ItemLink id="export_bus" />が取り付けられ、  
多数の<ItemLink id="level_emitter" />が付いたチェスト/タンクです。

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_internals.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 0.3 1.3" max="9.7 1 1.7">
        要求された在庫量を制御するためのレベルエミッターの束
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 4 1.3" max="9.7 4.7 1.7">
        要求された在庫量を制御するためのレベルエミッターの束
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 1.3 1.3" max="9.7 2 1.7">
        ゲームティックごとに1スタックを転送できる超強力なインポートバスの束
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/import_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 3 1.3" max="9.7 3.7 1.7">
        ゲームティックごとに1スタックを転送できる超強力なエクスポートバスの束
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/export_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="10 3 2">
        9つの独立した内部スロット
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="15" />
</GameScene>

## 特別な相互作用

インターフェースには、他のAE2[デバイス](../ae2-mechanics/devices.md)との特別な機能もいくつかあります。

未構成のインターフェース上の<ItemLink id="storage_bus" />は、  
インターフェースのネットワークがストレージバスが配置されている1つの大きなチェストであるかのように、  
そのネットワークの[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)全体をストレージバスのネットワークに提示します。
インターフェースのフィルタースロットにアイテムをストックするように設定すると、これが無効になります。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

パターンプロバイダーは、[サブネット](../ae2-mechanics/subnetworks.md)上のインターフェースと特別なやり取りを行います。  
インターフェースが未構成の場合、プロバイダーはインターフェースを完全にスキップし、  
そのサブネットの[ストレージ](../ae2-mechanics/import-export-storage.md)に直接プッシュします。
インターフェースをスキップしてレシピバッチで埋め込まず、  
さらに重要な点として、ストレージに空きができるまで次のバッチを挿入しません。

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        インターフェースフルブロックではなくフラットである必要があります）
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
       ストレージバス
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        パターン提供したい場所（複数台、または1台の複数面）
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## バリエーション

インターフェースには、通常とフラット/[サブパーツ](../ae2-mechanics/cable-subparts.md)の2つの異なるバリエーションがあります。  
これは、インベントリにアクセスできる特定の側面と、ネットワーク接続を提供する側面に影響します。

* 通常のインターフェースでは、あらゆる側面からインベントリにプッシュ、プル、アクセスでき、  
  ほとんどのAE2マシンと同様に、あらゆる側面にネットワーク接続を提供するケーブルのように機能します。

* フラットインターフェースは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)であるため、  
  複数のインターフェースを同じケーブルに配置でき、コンパクトなセットアップが可能になります。
  インベントリにプッシュ、プル、アクセスすることはできますが、表面にネットワーク接続は提供されません。

クラフトグリッドで、インターフェースを通常とフラットの間で入れ替えることができます。

## 設定

インターフェースの上部のスロットは、インターフェース自体にストックするように設定されているものを決定します。  
そこに何かを配置するか、JEI/REIからドラッグすると、レンチが表示され、数量を設定できます。

液体コンテナ(バケツや液体タンクなど)を右クリックして、その液体をバケツやタンク アイテムではなくフィルターとして設定します。

スロットを在庫維持モードにすると、外部の機械がそのスロットにほかのものを入れることもできなくなります。

## アップグレード

インターフェースは、次の[アップグレード](upgrade_cards.md)をサポートしています:

* <ItemLink id="fuzzy_card" />を使用すると、バスはダメージレベルでフィルター処理したり、アイテムNBTを無視したりできます
* <ItemLink id="crafting_card" />を使用すると、インターフェースは[自動クラフト](../ae2-mechanics/autocrafting.md)システムに作成リクエストを送信して、  
  必要なアイテムを取得できます。新しいアイテムを作成するリクエストを行う前に、可能であればストレージからアイテムを取得します。

## 優先度

優先順位は、GUIの右上にあるレンチをクリックして設定できます。  
優先順位の高いインターフェースは、優先順位の低いインターフェースよりも先にアイテムを取得します。

## レシピ

<Recipe id="network/blocks/interfaces_interface" />

<RecipeFor id="cable_interface" />
