---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 空間ストレージセル
  icon: spatial_storage_cell_128
  position: 410
categories:
- tools
item_ids:
- ae2:spatial_storage_cell_2
- ae2:spatial_storage_cell_16
- ae2:spatial_storage_cell_128
- ae2:spatial_cell_component_2
- ae2:spatial_cell_component_16
- ae2:spatial_cell_component_128
---

# 空間ストレージセル

  <Row>
    <ItemImage id="spatial_storage_cell_2" scale="4" />

    <ItemImage id="spatial_storage_cell_16" scale="4" />

    <ItemImage id="spatial_storage_cell_128" scale="4" />
  </Row>

空間ストレージセルは、[空間の物理的なボリュームを保存する](../ae2-mechanics/spatial-io.md)ために使用されます。

これらは<ItemLink id="spatial_io_port" />で使用されます。

[ストレージセル](../items-blocks-machines/storage_cells.md)とは異なり、空間セルは再フォーマットできません。

繰り返しますが、**使用後の空間セルをリセット、再フォーマット、またはサイズ変更することはできません。**   
異なる次元を使用する場合は、新しいセルを作成してください。

## レシピ

  <Row>
    <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_16_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_128_cubed_storage" />
  </Row>

# ハウジング

セルは、空間コンポーネントとハウジングを使用して作成することも、  
空間コンポーネントの周囲にハウジングレシピを使用して作成することもできます。

<Row>
  <Recipe id="network/cells/spatial_storage_cell_2_cubed" />

  <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />
</Row>

ハウジング自体は次のように作られています:

  <RecipeFor id="item_cell_housing" />

# 空間コンポーネント

空間コンポーネントは空間ストレージセルの中核です。  
各層ごとに、保存できるボリュームの寸法が8倍に増えます。

  <Row>
    <RecipeFor id="spatial_cell_component_2" />

    <RecipeFor id="spatial_cell_component_16" />

    <RecipeFor id="spatial_cell_component_128" />
  </Row>