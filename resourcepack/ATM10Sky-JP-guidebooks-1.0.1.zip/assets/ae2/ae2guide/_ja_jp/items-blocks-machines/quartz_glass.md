---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: クォーツガラス
  icon: quartz_glass
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_glass
- ae2:quartz_vibrant_glass
---

# クォーツガラス

<BlockImage id="quartz_glass" scale="8" />

ほとんどが<ItemLink id="certus_quartz_dust" />で作られた透明なガラスです。

多くのAE2マシンやアイテムの作成に使用されます。

光を発する鮮やかな石英ガラスのバリエーションもあります。

## レシピ

<RecipeFor id="quartz_glass" />

<RecipeFor id="quartz_vibrant_glass" />
