---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 量子ネットワークブリッジ
  icon: quantum_ring
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quantum_link
- ae2:quantum_ring
---

# 量子ネットワークブリッジ

![形成された量子ネットワークブリッジ](../assets/diagrams/quantum_bridge_demonstration.png)

量子ネットワークブリッジは、[ネットワーク](../ae2-mechanics/me-network-connections.md)を無限の距離に、さらには次元間で拡張できます。
合計32チャネルを伝送でき(ケーブルが各面にどのように接続されているかに関係なく)、基本的にワイヤレスの[高密度ケーブル](cables.md#dense-cable)のように機能します。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_2.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="6 2 3">
        2つのエンドポイント間の仮想ケーブル
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

注目すべきは、**両側をチャンクロードする必要がある** ため、  
2つの側面が離れている場合は、<ItemLink id="spatial_anchor" />またはその他のチャンクローダーを使用する必要があります。

# クァンタムリング

<BlockImage id="quantum_ring" scale="8" />

これらのブロックを<ItemLink id="quantum_link" />の周囲に8つ配置すると、
量子ネットワークブリッジが作成されます。
<ItemLink id="quantum_link" />に隣接する4つの<ItemLink id="quantum_ring" />ブロックのみがネットワーク接続を受け入れ、
4つのコーナーブロックはケーブルに接続できません。

## レシピ

<RecipeFor id="quantum_ring" />

# クァンタムリンクチャンバー

<BlockImage id="quantum_link" scale="8" />

<ItemLink id="quantum_ring" />で囲まれたこれらのブロックの1つが量子ネットワークブリッジを作成します。  
このブロックはケーブルに接続せず、完全なブリッジが作成された場合にのみネットワークの一部として登録されます。

このブロックのインベントリには1つの<ItemLink id="quantum_entangled_singularity" />のみを保持でき、自動化でアクセスできます。

## レシピ

<RecipeFor id="quantum_link" />
