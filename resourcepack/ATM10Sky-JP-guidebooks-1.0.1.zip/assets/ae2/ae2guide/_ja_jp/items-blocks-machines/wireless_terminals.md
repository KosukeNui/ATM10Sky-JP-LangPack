---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 無線ターミナル
  icon: wireless_crafting_terminal
  position: 410
categories:
- tools
item_ids:
- ae2:wireless_terminal
---

# 無線ターミナル

<ItemImage id="wireless_terminal" scale="4" />


無線ターミナルは、通常の有線[ターミナル](terminals.md)のポータブルバージョンです。  
有線ターミナルとまったく同じUIを備えていますが、<ItemLink id="view_cell" />のスロットの代わりに[アップグレードカード](upgrade_cards.md)のスロットがあります。

ネットワークとペアリングするには、そのネットワークに接続されている<ItemLink id="wireless_access_point" />の右上のスロットにターミナルを挿入します。  
(無線ターミナルの絵とその下に矢印があるスロット)

機能するには、<ItemLink id="wireless_access_point" />の範囲内にある必要があります。

<ItemLink id="charger" />でエネルギーを充電できます。

# 無線ターミナル

<ItemImage id="wireless_terminal" scale="4" />

基本的なターミナルがポータブルになりました。  
<ItemLink id="wireless_access_point" />の範囲内であればどこからでも[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)の内容を表示してアクセスし、  
[自動クラフト](../ae2-mechanics/autocrafting.md)セットアップからリクエストできます。

## UI

[ターミナル](terminals.md)を参照してください

## アップグレード

無線ターミナルは、次の[アップグレード](upgrade_cards.md)をサポートしています:

* バッテリー容量を増やすための<ItemLink id="energy_card" />

## レシピ

<RecipeFor id="wireless_terminal" />

# 無線クラフトターミナル

<ItemImage id="wireless_crafting_terminal" scale="4" />

<ItemLink id="ae2:wireless_crafting_terminal" />は[AE2WTLib](ae2wtlib:ae2wtlib/ae2wtlib-index.md)によって変更されています。
説明は現在、[別のページ](ae2wtlib:ae2wtlib/wireless_crafting_terminal.md)にあります。
