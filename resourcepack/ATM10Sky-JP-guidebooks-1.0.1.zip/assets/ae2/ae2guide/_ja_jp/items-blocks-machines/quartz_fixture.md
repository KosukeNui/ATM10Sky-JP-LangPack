---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: クォーツ器具
  icon: quartz_fixture
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_fixture
- ae2:light_detector
---

# クォーツ器具

<Row>
<BlockImage id="quartz_fixture" scale="8" />

<BlockImage id="light_detector" scale="8" />
</Row>

充電されたクォーツ器具は、光を発する小さなグリーブルです。

代わりに、光検出器具は、ブロックの光レベルに応じてレッドストーン信号を発します。

## レシピ

<RecipeFor id="quartz_fixture" />

<RecipeFor id="light_detector" />
