---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: シンギュラリティ
  icon: singularity
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:singularity
- ae2:quantum_entangled_singularity
---

# シンギュラリティ

<ItemImage id="singularity" scale="4" />

非常にコンパクトな物質の球体。

特異点モードの<ItemLink id="condenser" />で256,000個のアイテムまたはバケツを使用して作成されました。

## 量子もつれシンギュラリティ

<ItemImage id="quantum_entangled_singularity" scale="4" />

2つの[量子ネットワークブリッジ](quantum_bridge.md)間の接続を作成するために必要なもので、常に一致するペアで生成されます。  
接続を作成するには、量子もつれシンギュラリティのペアの1つを、両側のブリッジの<ItemLink id="quantum_link" />に配置します。

これらは、<ItemLink id="minecraft:ender_pearl" />または<ItemLink id="ender_dust" />\
と<ItemLink id="singularity" />の間で反応を引き起こすことによって作成されます。  
爆発力があれば、反応を引き起こすのに十分なはずです。

<RecipeFor id="quantum_entangled_singularity" />

***ほぼすべての爆発、クリーパーでも機能します。***

常にペアで生成されますが、必要なのは1つの<ItemLink id="singularity" />だけです。

バニラの金床を使用して作成する場合は、名前を付けてラベルを付けることをお勧めします。
