---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: カッティングナイフ
  icon: certus_quartz_cutting_knife
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_cutting_knife
- ae2:nether_quartz_cutting_knife
---

# クォーツツール

<Row>
  <ItemImage id="certus_quartz_cutting_knife" scale="4" />

  <ItemImage id="nether_quartz_cutting_knife" scale="4" />
</Row>

カッティングナイフは、<ItemLink id="name_press" />や<ItemLink id="cable_anchor" />の作成に使用されます。

ネームプレスを作成するには、カッティングナイフを右クリックして金属のインゴットを挿入し、  
プレートに書きたい名前を入力して、完成したプレートを取り出すだけです。

## レシピ

<Row>
  <RecipeFor id="certus_quartz_cutting_knife" />

  <RecipeFor id="nether_quartz_cutting_knife" />
</Row>
