---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: P2Pトンネル
  icon: me_p2p_tunnel
  position: 210
categories:
- devices
item_ids:
- ae2:me_p2p_tunnel
- ae2:redstone_p2p_tunnel
- ae2:item_p2p_tunnel
- ae2:fluid_p2p_tunnel
- ae2:fe_p2p_tunnel
- ae2:light_p2p_tunnel
---

# ポイント to ポイントトンネル

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

P2Pトンネルは、アイテム、流体、レッドストーン信号、電力、ライト、[チャネル](../ae2-mechanics/channels.md)などを、  
ネットワークと直接やり取りすることなくネットワーク上で移動させる方法です。  
P2Pトンネルにはさまざまな種類がありますが、それぞれが特定の種類のものだけを転送します。  
基本的には、2つのブロック面を遠くから直接接続するポータルのように機能します。  
双方向ではなく、定義された入力と出力があります。

![Portal](../assets/assemblies/p2p_portal.png)

例えば、アイテムP2Pに面したホッパーは、樽に直接接続されているかのように動作し、アイテムが流れます。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_hopper_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ただし、隣り合った2つの樽間ではアイテムが転送されません。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_barrel_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

レッドストーンP2P のような他のバリエーションもあります。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_redstone.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

そして、チャンネルを運ぶME P2Pです。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## P2Pトンネルの種類と調整

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="180" pitch="90" />
</GameScene>

P2Pトンネルには多くの種類があります。  
直接作成できるのはMEP2Pトンネルのみで、他のトンネルは特定のアイテムを使って他のP2Pトンネルを右クリックすることで作成されます:
- MEP2Pトンネルは、任意の [ケーブル](../items-blocks-machines/cables.md)を使って右クリックすることで選択されます。
- レッドストーンP2Pトンネルは、さまざまなレッドストーンコンポーネントを使って右クリックすることで選択されます。
- アイテムP2Pトンネルは、チェストまたはホッパーを使って右クリックすることで選択されます。
- 流体P2Pトンネルは、バケツまたはボトルを使って右クリックすることで選択されます。
- エネルギーP2Pトンネルは、ほぼすべてのエネルギーを含むアイテムを使って右クリックすることで選択されます。
- ライトP2Pトンネルは、トーチまたはグロウストーンを使って右クリックすることで選択されます。

一部のトンネルタイプには癖があります。  
たとえば、MEP2Pトンネルのチャネルは他のMEP2Pトンネルを通過できず、  
エネルギー P2P トンネルは、[エネルギー](../ae2-mechanics/energy.md)の消費量を増やすことで、  
トンネル自体を流れるFEまたはEに対して間接的に5%の税金を課します。

## 最もよく使用されるP2Pの形式

P2Pトンネルの最も一般的な使用例は、MEP2Pトンネルを使用して[チャネル](../ae2-mechanics/channels.md)トランスポートの密度を圧縮することです。

高密度ケーブルの束の代わりに、1本の高密度ケーブルを使用して多くのチャネルを運ぶことができます。

この例では、8つのMEP2P入力がメインネットワークの<ItemLink id="controller" />から256チャネル(8*32)を取得し、  
8つのMEP2P出力がそれらを別の場所に出力します。  
各P2Pトンネルの入力または出力が1つのチャネルを取得する様子を確認してください。  
このようにして、細いケーブルを介して多くのチャネルを実行できます。  
また、P2Pトンネルは専用の[サブネットワーク](../ae2-mechanics/subnetworks.md)上にあるため、  
これを行うためにメインネットワークのチャネルを使用することもありません。  
また、P2Pトンネルをコントローラーに直接配置できる一方で、[高密度スマートケーブル](../items-blocks-machines/cables.md#smart-cable)を間に配置して、  
チャネルをより簡単に視覚化できることにも注目してください。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/p2p_compact_channels.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 1.3 6.3" max="2 2.7 6.7">
    クォーツファイバーはメインネットワークとP2Pサブネットワーク間でエネルギーを共有します。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.1 0 5.7" max="5 2.3 6.4">
        トンネルの入力側は、コントローラーに直接付けても、ケーブルでつないでもかまいません。
  </BoxAnnotation>

  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

別の例（[Quantum Bridges](quantum_bridge.md)での使用を含む）については、  
修正する気にならないMSペイントの図を参照してください。

![P2P and quantum bridges](../assets/diagrams/p2p_quantum_network.png)

## ネスト

ただし、これを使用して1本のケーブルで無限のチャネルを送信することはできません。  
MEP2Pトンネルのチャネルは別のMEP2Pトンネルを通過しないため、再帰的にネストすることはできません。  
赤いケーブル上のMEP2Pトンネルの外側の層がオフラインになっていることに注意してください。  
これはMEP2Pトンネルにのみ適用され、他のP2PトンネルタイプはMEP2Pトンネルを通過できます。  
RedstoneP2Pトンネルが正常に動作していることからもわかります。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_nesting.snbt" />
  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

## リンク

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_linking_frequency.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

P2Pトンネル接続の両端は、<ItemLink id="memory_card" />を使用してリンクできます。  
周波数は、トンネルの背面に2x2の色の配列として表示されます。
- Shiftキーを押しながら右クリックすると、新しいP2Pリンク周波数が生成されます。
- 右クリックすると、設定、アップグレード カード、またはリンク周波数が貼り付けられます。

Shiftキーを押しながら右クリックしたトンネルが入力になり、右クリックしたトンネルが出力になります。  
複数の出力を設定できますが、MEP2Pトンネルでは、入力に流れるチャネルが出力間で分割されるため、チャネルを複製することはできません。

## レシピ

<RecipeFor id="me_p2p_tunnel" />