---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: フルーシュパール
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# フルーシュパール

<ItemImage id="fluix_pearl" scale="4" />

<ItemLink id="fluix_crystal" />でコーティングされたエンダーパール。  
いくつかのAE2コンポーネントの製造に使用されます。

## レシピ

<RecipeFor id="fluix_pearl" />
