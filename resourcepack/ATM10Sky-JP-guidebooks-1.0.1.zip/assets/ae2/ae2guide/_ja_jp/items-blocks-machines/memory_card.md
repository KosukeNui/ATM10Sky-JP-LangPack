---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: メモリーカード
  icon: memory_card
  position: 410
categories:
- tools
item_ids:
- ae2:memory_card
---

# メモリーカード

<ItemImage id="memory_card" scale="4" />

メモリカードは、AE2[デバイス](../ae2-mechanics/devices.md)とリンク[P2Pトンネル](p2p_tunnels.md)間で設定をコピーして貼り付けるために使用されます。  
また、[アップグレードカード](upgrade_cards.md)をデバイスに貼り付けることもできます。

- Shiftキーを押しながら右クリックして設定をコピーするか、新しいP2Pリンク周波数を生成します。

- 右クリックして設定、アップグレードカード、またはリンク周波数を貼り付けます。

## レシピ

<RecipeFor id="memory_card" />
