---
navigation:
  title: アイテム、ブロック、マシン
  position: 50
---

# アイテム、ブロック、マシン

他のページがリンクするためのmod内の項目のリストと、それらの機能の説明。

## その他の材料とブロック

<CategoryIndex category="misc ingredients blocks" />

## ネットワークインフラ

<CategoryIndex category="network infrastructure" />

## デバイス

<CategoryIndex category="devices" />

## マシン

<CategoryIndex category="machines" />

## ツール

<CategoryIndex category="tools" />