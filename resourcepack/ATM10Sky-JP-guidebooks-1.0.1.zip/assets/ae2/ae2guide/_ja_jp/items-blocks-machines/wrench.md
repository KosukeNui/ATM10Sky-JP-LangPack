---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: レンチ
  icon: certus_quartz_wrench
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_wrench
- ae2:nether_quartz_wrench
---

# レンチ

<Row>
  <ItemImage id="certus_quartz_wrench" scale="4" />

  <ItemImage id="nether_quartz_wrench" scale="4" />
</Row>

レンチは、AE2デバイスを回転(右クリック)したり、AE2ブロックを分解(Shift キーを押しながら右クリック)したりするために使用されます。

[サブパーツ](../ae2-mechanics/cable-subparts.md)は、ケーブル上のすべてを壊すことなくケーブルから取り外すことができます
(または、サブパーツを壊すことなくケーブルを取り外すことができます)

多くのAE2ブロックは回転できるため、このガイドで何かを回転できると書かれていないからといって、  
できないというわけではありません。

## レシピ

<Row>
  <RecipeFor id="certus_quartz_wrench" />

  <RecipeFor id="nether_quartz_wrench" />
</Row>
