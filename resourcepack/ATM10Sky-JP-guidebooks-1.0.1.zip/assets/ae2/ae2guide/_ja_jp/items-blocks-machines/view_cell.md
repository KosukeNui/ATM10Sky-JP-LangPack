---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 表示セル
  icon: view_cell
  position: 410
categories:
- tools
item_ids:
- ae2:view_cell
---

# 表示セル

<ItemImage id="view_cell" scale="2" />

表示セルは、[ターミナル](terminals.md)の表示をフィルターするために使用されます。<ItemLink id="cell_workbench" />で分割します。

たとえば、ターミナルに石材の建材のみを表示したいとします。  
表示セルをそれらの材料に分割してターミナルに配置すると、それらのアイテムのみが表示されます。

表示セルは追加式です。オークの板材の表示セルと丸石の表示セルがある場合、  
両方を配置すると、板材と丸石の両方が表示されます。

## レシピ

<Recipe id="network/cells/view_cell_storage" />

<Recipe id="network/cells/view_cell" />
