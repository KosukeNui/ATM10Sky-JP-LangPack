---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: フルーシュツール
  icon: fluix_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_axe
- ae2:fluix_hoe
- ae2:fluix_shovel
- ae2:fluix_pickaxe
- ae2:fluix_sword
---

# フルーシュツール

<Row>
  <ItemImage id="fluix_axe" scale="4" />

  <ItemImage id="fluix_hoe" scale="4" />

  <ItemImage id="fluix_shovel" scale="4" />

  <ItemImage id="fluix_pickaxe" scale="4" />

  <ItemImage id="fluix_sword" scale="4" />
</Row>

[フルーシュ](fluix_crystal.md)ツールは鉄のツールに似ており、耐久性が3倍、攻撃ダメージと採掘速度がわずかに高くなっています。

すべてのフルーシュツールは、少なくとも幸運/略奪1を持っているかのように動作します。  
これは、エンチャントテーブルにアクセスする前に役立ちます。

<ItemLink id="fluix_upgrade_smithing_template" />を作成する必要があります。

## レシピ

<Column>
  <Row>
    <RecipeFor id="fluix_axe" />

    <RecipeFor id="fluix_hoe" />

    <RecipeFor id="fluix_shovel" />
  </Row>

  <Row>
    <RecipeFor id="fluix_pickaxe" />

    <RecipeFor id="fluix_sword" />
  </Row>
</Column>
