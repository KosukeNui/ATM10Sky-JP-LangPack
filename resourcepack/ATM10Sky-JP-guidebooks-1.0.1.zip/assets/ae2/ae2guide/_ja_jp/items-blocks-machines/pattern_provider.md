---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: パターンプロバイダー
  icon: pattern_provider
  position: 210
categories:
- devices
item_ids:
- ae2:pattern_provider
- ae2:cable_pattern_provider
---

# パターンプロバイダー

<Row gap="20">
<BlockImage id="pattern_provider" scale="8" />
<BlockImage id="pattern_provider" p:push_direction="up" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

パターンプロバイダーは、[自動クラフト](../ae2-mechanics/autocrafting.md)システムが世界とやり取りする主な方法です。  
パターンプロバイダーは[パターン](patterns.md)内の材料を隣接するインベントリにプッシュし、  
アイテムをパターンプロバイダーに挿入してネットワークに挿入することができます。  
多くの場合、マシンの出力を近くのパターンプロバイダー(多くの場合、  
材料をプッシュしたプロバイダー)にパイプすることで、チャネルを節約できます。  
<ItemLink id="import_bus" />を使用してマシンの出力をネットワークにプルする代わりにです。

なお、パターンプロバイダーはクラフトCPUの[クラフトストレージ](crafting_cpu_multiblock.md#crafting-storage)から材料を直接プッシュするため、  
実際にはインベントリに材料が含まれないため、そこからパイプすることはできません。  
プロバイダーを別のインベントリ(樽など)にプッシュしてから、そこからパイプする必要があります。

また、プロバイダーは一度にすべての材料をプッシュする必要があり、  
半分のバッチをプッシュすることはできません。  
これは、悪用すると便利です。

パターンプロバイダーは、[サブネット](../ae2-mechanics/subnetworks.md)上のインターフェイスと特別なやり取りを行います。  
インターフェイスが変更されていない場合(リクエスト スロットに何もない場合)、プロバイダーはインターフェイスを完全にスキップし、  
そのサブネットの[ストレージ](../ae2-mechanics/import-export-storage.md)に直接プッシュします。

インターフェイスをスキップしてレシピバッチで埋めず、さらに重要なことに、マシンにスペースができるまで次のバッチを挿入しません。

これはブロッキングモードで正しく機能し、プロバイダーはインターフェイスのスロットではなく、マシンのスロットで材料を監視します。

たとえば、この設定では、精錬する物と燃料の両方が、炉の対応するスロットに直接プッシュされます。

これを使用して、マシンの複数の側面、または複数のマシンにパターン提供することができます。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) パターンプロバイダー:  
        関連する処理パターンを使用して、ケルタスクォーツレンチを使用した方向指定。

        ![Iron Pattern](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) インターフェース:  
        デフォルト設定。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) ストレージバス #1:  
        石炭にフィルタリングされます。
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) ストレージバス #2:  
        反転カードを使用して、石炭をブラックリストにフィルタリングします。
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

  <DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        メインネットへ
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

これは複数のマシンに提供する一般的な例です

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        インターフェース（フルブロックではなくフラットである必要があります）
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        ストレージバス
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        パターン提供したい場所
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

同じパターンを持つ複数のパターンプロバイダーがサポートされており、並行して動作します。

パターンプロバイダーは、すべての面にバッチをラウンドロビンしようとします。  
そのため、接続されているすべてのマシンを並行して使用します。

## バリエーション

パターンプロバイダーには、通常、方向性、フラット/[サブパート](../ae2-mechanics/cable-subparts.md)の3つの異なるバリエーションがあります。  
これは、どの特定のサイドに材料をプッシュし、どのサイドからアイテムを受け取り、どのサイドにネットワーク接続を提供するかに影響します。

* 通常のパターンプロバイダーは、すべてのサイドに材料をプッシュし、すべてのサイドから入力を受け取り、  
  ほとんどのAE2マシンと同様に、すべてのサイドに[ネットワーク接続](../ae2-mechanics/me-network-connections.md)を提供するケーブルのように動作します。

* 方向性パターンプロバイダーは、通常のパターンプロバイダーで<ItemLink id="certus_quartz_wrench" />を使用して方向を変更することで作成されます。  
  選択されたサイドに材料をプッシュし、すべてのサイドから入力を受け取り、特に選択されたサイドに[ネットワーク接続](../ae2-mechanics/me-network-connections.md)を提供しません。  
  これにより、サブネットワークを作成したい場合に、ネットワークに接続せずにAE2マシンにプッシュできます。

* フラットパターンプロバイダーは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)であるため、  
  複数のプロバイダーを同じケーブルに配置でき、コンパクトなセットアップが可能になります。

これらは、方向性パターンプロバイダーの選択された側と同様に動作し、  
パターンを提供し、入力を受け取り、その面では[ネットワーク接続](../ae2-mechanics/me-network-connections.md)を提供しません。

パターンプロバイダーは、クラフトグリッドで通常とフラットの間で入れ替えることができます。

## 設定

パターンプロバイダーにはさまざまなモードがあります:

* **ブロッキング モード** では、マシンにすでに材料がある場合、プロバイダーが新しい材料のバッチをプッシュするのを止めます。

* **ロック クラフト** では、さまざまなレッドストーン条件で、  
  または前のクラフトの結果がその特定のパターンプロバイダーに挿入されるまで、プロバイダーをロックできます。

* プロバイダーは、<ItemLink id="pattern_access_terminal" />で表示または非表示にできます。

## 優先度

優先度は、GUIの右上にあるレンチをクリックして設定できます。  
同じアイテムに複数の[パターン](patterns.md)がある場合、ネットワークに優先度の高いパターンの材料がない限り、  
優先度の高いプロバイダーのパターンが優先度の低いプロバイダーのパターンよりも使用されます。

## よくある誤解

何らかの理由で、人々はこれを続けています。  
理由はわかりませんが、役立つことを期待してここに記載しています。  
(おそらく人々は、パターンプロバイダーもエクスポートすることを知らずに、  
<ItemLink id="export_bus" />がネットワークから出る唯一の方法だと考えているため、誤解しています)

これでは、期待どおりの動作は行いません。  
[ケーブル](cables.md)で述べたように、ケーブルはアイテムパイプではなく、内部インベントリがなく、プロバイダーはケーブルにプッシュしません。

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_1.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        かまどではない
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

プロバイダーにはプッシュする対象がないので、機能できません。  
ここでプロバイダーが行っているのは、ケーブルのように動作して、<ItemLink id="export_bus" />をネットワークに接続するだけです。

プロバイダーは、<ItemLink id="export_bus" />に何をエクスポートするかを指示することもなく、  
エクスポートバスはフィルターに入力したすべてのものをエクスポートするだけです。

ここで基本的に行ったことは次のようになります。

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_2.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        かまどではない
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

おそらく実際に作成したいのは、パターンプロバイダーがパターンの内容を隣接するマシンにエクスポートできる次のようなものです。

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_3.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        かまどではない
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

## 分子組立機と一緒に使う

<ItemLink id="molecular_assembler" />は、基本的にほかの機械とまったく同じです。中に入れられるインベントリがあり、その中のものに処理を行い、多くの機械と同じように結果を隣のインベントリへ押し出します。そのため、ほかの機械と同じようにプロバイダーと一緒に使いますが、1つだけ追加の点があります。

組立機は、組立機に直接入れた<ItemLink id="crafting_pattern" />・<ItemLink id="smithing_table_pattern" />・<ItemLink id="stonecutting_pattern" />から、目的のパターンを読み取れます。
これは組立ラインでは便利ですが、クラフトのレシピごとに専用の組立機を用意しなければならないのは面倒です。

そこで、パターンプロバイダーには組立機向けの特別な機能があり、材料と一緒にパターンのデータを送れます。こうすると、パターンプロバイダーの隣に組立機を置くだけで、プロバイダーはクラフト・鍛冶・石切りのすべてのパターンにその組立機を使えます。

本当にこれだけです。パターンをプロバイダーに入れるだけです:

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

*これはちょうど8台のプロバイダーになっていることに注意してください。これは、1台の組立機・プロバイダー、または高密度でないケーブルを通せるチャンネルの最大数です。*

## レシピ

<RecipeFor id="pattern_provider" />

<RecipeFor id="cable_pattern_provider" />
