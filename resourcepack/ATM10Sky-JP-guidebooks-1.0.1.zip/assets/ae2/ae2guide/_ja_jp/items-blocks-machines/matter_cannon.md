---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: マターキャノン
  icon: matter_cannon
  position: 410
categories:
- tools
item_ids:
- ae2:matter_cannon
---

# マターキャノン

<ItemImage id="matter_cannon" scale="4" />

マターキャノンは、<ItemLink id="matter_ball" />や金属塊などの小さなアイテムを発射物として発射できるポータブルレールガンです。  
ダメージは発射されるアイテムによって異なり、金塊(ダメージ 10)などの「重い」アイテムは、  
マターボール(ダメージ2)などの軽いアイテムよりも多くのダメージを与えます。
1発あたり1600AEの基本エネルギーを消費します。

設定オプション「matterCannonBlockDamage」がtrueの場合、  
キャノンはブロックの硬さと弾薬のダメージに応じてブロックを破壊します。

エネルギーは<ItemLink id="charger" />で充電できます。

マターキャノンは[ストレージセル](storage_cells.md)のように動作し、  
弾薬マガジンは、キャノンを<ItemLink id="chest" />のストレージセルスロットに差し込むことで最も簡単に充填できます。

## アップグレード

マターキャノンは、<ItemLink id="cell_workbench" />を介して挿入される次の[アップグレード](upgrade_cards.md)をサポートします:

* <ItemLink id="fuzzy_card" />を使用すると、セルをダメージレベル別に分割したり、アイテムNBTを無視したりできます
* <ItemLink id="inverter_card" />フィルターをホワイトリストからブラックリストに切り替えます
* <ItemLink id="speed_card" />を使用すると、ショットごとに使用するエネルギーが増加し、より強力に発射されます。
* <ItemLink id="void_card" />を使用すると、セルがいっぱいになると挿入されたアイテムが無効になります。  
  パーティション分割には注意してください。
* <ItemLink id="energy_card" />を使用すると、バッテリー容量を増やすことができます

## レシピ

<RecipeFor id="matter_cannon" />
