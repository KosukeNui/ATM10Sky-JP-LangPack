---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: アップグレードカード
  icon: speed_card
  position: 410
categories:
- tools
item_ids:
- ae2:basic_card
- ae2:advanced_card
- ae2:redstone_card
- ae2:capacity_card
- ae2:void_card
- ae2:fuzzy_card
- ae2:speed_card
- ae2:inverter_card
- ae2:crafting_card
- ae2:equal_distribution_card
- ae2:energy_card
---

# アップグレードカード

<Row>
  <ItemImage id="redstone_card" scale="2" />

  <ItemImage id="capacity_card" scale="2" />

  <ItemImage id="void_card" scale="2" />

  <ItemImage id="fuzzy_card" scale="2" />

  <ItemImage id="speed_card" scale="2" />

  <ItemImage id="inverter_card" scale="2" />

  <ItemImage id="crafting_card" scale="2" />

  <ItemImage id="equal_distribution_card" scale="2" />

  <ItemImage id="energy_card" scale="2" />
</Row>

アップグレードカードは、AE2[デバイス](../ae2-mechanics/devices.md)とマシンの動作を変更し、  
速度を上げたり、フィルター容量を改善したり、レッドストーン制御を有効にしたりします。

## カードコンポーネント

<Row>
  <ItemImage id="basic_card" scale="2" />

  <ItemImage id="advanced_card" scale="2" />
</Row>

カードは基本または上級カードベースで作成されます

<Row>
  <RecipeFor id="basic_card" />

  <RecipeFor id="advanced_card" />
</Row>

## レッドストーンカード

<ItemImage id="redstone_card" scale="2" />

レッドストーンカードはレッドストーンコントロールを追加し、  
デバイスのGUIにさまざまなレッドストーン条件を切り替えるための切り替えボタンを追加します。

<RecipeFor id="redstone_card" />

## 容量カード

<ItemImage id="capacity_card" scale="2" />

容量カードは、インポート、エクスポート、ストレージバス、  
およびフォーメーションプレーンのフィルタースロットの量を増加させます。

<RecipeFor id="capacity_card" />

## オーバーフロー破棄カード

<ItemImage id="void_card" scale="2" />

オーバーフロー破壊カードは、<ItemLink id="cell_workbench" />の[ストレージセル](storage_cells.md)に適用でき、  
セルがいっぱいの場合、入ってくるアイテムを削除します。  
(セルを[パーティション](cell_workbench.md)することを忘れないでください!)   
均等配分カードと組み合わせると、セルの特定のアイテムのセクションがいっぱいの場合、  
他のアイテムのセクションが空であっても、アイテムは無効になります。

<RecipeFor id="void_card" />

## ファジーカード

<ItemImage id="fuzzy_card" scale="2" />

ファジーカードを使用すると、フィルター付きのデバイスやツールでダメージレベルによるフィルター処理やアイテムNBTの無視が可能になり、  
ダメージレベルやエンチャントに関係なくすべての鉄の斧をエクスポートしたり、  
完全に修復されたダイヤモンドの剣ではなく、損傷したダイヤモンドの剣のみをエクスポートしたりできます。

以下は、ファジーダメージ比較モジュールの動作例です。  
左側はバス構成、上部は比較対象のアイテムです。

| 25%                    | 10% Damaged Pickaxe | 30% Damaged Pickaxe | 80% Damaged Pickaxe | Full Repair Pickaxe |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Nearly Broken Pickaxe  | ✅                 | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            |
| Fully Repaired Pickaxe | \*\*\*\*            | ✅                 | ✅                  | ✅                   |

| 50%                    | 10% Damaged Pickaxe | 30% Damaged Pickaxe | 80% Damaged Pickaxe | Full Repair Pickaxe |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Nearly Broken Pickaxe  | ✅                  | ✅                 | \*\*\*\*            | \*\*\*\*            |
| Fully Repaired Pickaxe | \*\*\*\*            | \*\*\*\*            | ✅                 | ✅                   |

| 75%                    | 10% Damaged Pickaxe | 30% Damaged Pickaxe | 80% Damaged Pickaxe | Full Repair Pickaxe |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Nearly Broken Pickaxe  | ✅                  | ✅                 | \*\*\*\*            | \*\*\*\*            |
| Fully Repaired Pickaxe | \*\*\*\*            |                     | ✅                 | ✅                   |

| 99%                    | 10% Damaged Pickaxe | 30% Damaged Pickaxe | 80% Damaged Pickaxe | Full Repair Pickaxe |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Nearly Broken Pickaxe  | ✅                 | ✅                  | ✅                 | \*\*\*\*            |
| Fully Repaired Pickaxe | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            | ✅                   |

| Ignore                 | 10% Damaged Pickaxe | 30% Damaged Pickaxe | 80% Damaged Pickaxe | Full Repair Pickaxe |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Nearly Broken Pickaxe  | ✅                 | ✅                  | ✅                 | **✅**               |
| Fully Repaired Pickaxe | **✅**             | **✅**              | **✅**             | ✅                   |

<RecipeFor id="fuzzy_card" />

## 加速カード

<ItemImage id="speed_card" scale="2" />

アクセラレーションカードにより、処理速度が向上し、  
インポートバスとエクスポートバスが1回の操作でより多くのアイテムを移動できるようになり、  
刻印機と分子組立機の動作が高速化されます。

<RecipeFor id="speed_card" />

## 反転カード

<ItemImage id="inverter_card" scale="2" />

反転カードは、デバイスとツールのフィルターをホワイトリストからブラックリストに切り替えます。

<RecipeFor id="inverter_card" />

## クラフトカード

<ItemImage id="crafting_card" scale="2" />

クラフトカードを使用すると、デバイスは[自動クラフト](../ae2-mechanics/autocrafting.md)システムにクラフト要求を送信して、必要なアイテムを取得できます。

<RecipeFor id="crafting_card" />

## 等分配カード

<ItemImage id="equal_distribution_card" scale="2" />

等分配カードは、<ItemLink id="cell_workbench" />の[ストレージセル](storage_cells.md)に適用でき、  
カードが[パーティション化](cell_workbench.md)されている内容に基づいてセルを均等サイズのセクションに分割できます。  
これにより、1つのアイテムタイプがセルを完全に埋めてしまうことを防ぎます。

<RecipeFor id="equal_distribution_card" />

## エナジーカード

<ItemImage id="energy_card" scale="2" />

エナジーカードは、ポータブルターミナルなどの特定のツールにエネルギー貯蔵量を追加し、<ItemLink id="vibration_chamber" />の効率を高めます。

<RecipeFor id="energy_card" />
