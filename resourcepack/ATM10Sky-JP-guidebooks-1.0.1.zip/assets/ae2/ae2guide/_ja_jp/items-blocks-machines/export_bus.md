---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: MEエクスポートバス
  icon: export_bus
  position: 220
categories:
- devices
item_ids:
- ae2:export_bus
---

# MEエクスポートバス

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/export_bus.snbt" />
</GameScene>

エクスポートバスは、アイテムと流体(およびアドオンが指定されている場合はその他すべて)を  
[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)から取得し、アクセスしているインベントリにプッシュします。

遅延を減らすために、エクスポートバスが最近何かをエクスポートしていない場合は、一種の「スリープモード」になり、ゆっくりと動作します。  
そして、何かを正常にエクスポートすると、起動してフルスピード(1秒あたり4操作)に加速します。

これらは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)です。

## フィルタリング

デフォルトでは、バスは何もエクスポートしません。  
フィルタースロットに挿入されたアイテムはホワイトリストとして機能し、特定のアイテムをエクスポートできます。

アイテムと流体は、実際にそのアイテムを持っていなくても、JEI/REIからスロットにドラッグできます。

流体コンテナー(バケツや流体タンクなど)を右クリックして、その流体をバケツやタンクアイテムではなくフィルターとして設定します。

## アップグレード

エクスポートバスは、次の[アップグレード](upgrade_cards.md)をサポートしています:

* <ItemLink id="capacity_card" />は、フィルタースロットの数を増やし、フィルターされたものをエクスポートする順序の設定を表示します。
* <ItemLink id="speed_card" />は、操作ごとに移動するアイテムの量を増やします
* <ItemLink id="fuzzy_card" />は、バスが損傷レベルでフィルター処理したり、アイテムNBTを無視したりできるようにします
* <ItemLink id="crafting_card" />は、バスが[自動クラフト](../ae2-mechanics/autocrafting.md)システムに作成要求を送信して、必要なアイテムを取得できるようにします。  
  可能な場合はアイテムをストレージから取得するように設定することも、  
  常に新しいアイテムを作成するように要求するように設定することもできます。
* <ItemLink id="redstone_card" />は、レッドストーン制御を追加し、高信号、低信号、またはパルスごとに1回アクティブにできるようにします

## 速度

| 加速カード          | 操作ごとに移動するアイテム   |
|:-------------------|:---------------------------|
| 0                  | 1                          |
| 1                  | 8                          |
| 2                  | 32                         |
| 3                  | 64                         |
| 4                  | 96                         |

## レシピ

<RecipeFor id="import_bus" />
