---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 無線受信機
  icon: wireless_receiver
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:wireless_receiver
---

# 無線受信機

<ItemImage id="wireless_receiver" scale="4" />

短距離無線MEテクノロジーのコンポーネントである反射皿内の<ItemLink id="fluix_pearl" />。

## レシピ

<RecipeFor id="wireless_receiver" />
