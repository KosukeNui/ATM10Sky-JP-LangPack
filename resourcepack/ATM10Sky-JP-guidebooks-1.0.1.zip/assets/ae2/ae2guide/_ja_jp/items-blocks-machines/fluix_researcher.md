---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: フルーシュ研究員（村人）
  icon: minecraft:emerald
  position: 310
categories:
- tools
---

# フルーシュ研究員

<Row>
![Fluix Researcher](../assets/diagrams/ae2_villager.png)
<BlockImage id="charger" scale="8" />
</Row>

フルーシュ研究員は村人の職業の1つです。対応する職業ブロックは<ItemLink id="charger" />です。

## 取引

取引はバニラと同じしくみで、レベルごとに2つの取引がランダムに選ばれて解放されます（そのレベルの取引が1つしかない場合を除く）

| レベル     | 求めるアイテム                                    | 渡すアイテム                                    |
|------------|---------------------------------------------------|-------------------------------------------------|
| 新米       | 3 <ItemLink id="minecraft:emerald" />             | 4 <ItemLink id="certus_quartz_crystal" />       |
| 新米       | 2 <ItemLink id="minecraft:emerald" />             | 1 <ItemLink id="meteorite_compass" />           |
|            |                                                   |                                                 |
| 見習い     | 3 <ItemLink id="charged_certus_quartz_crystal" /> | 1 <ItemLink id="minecraft:emerald" />           |
| 見習い     | 5 <ItemLink id="silicon" />                       | 1 <ItemLink id="minecraft:emerald" />           |
| 見習い     | 5 <ItemLink id="minecraft:emerald" />             | 8 <ItemLink id="sky_stone_block" />             |
|            |                                                   |                                                 |
| 一人前     | 2 <ItemLink id="quartz_glass" />                  | 1 <ItemLink id="minecraft:emerald" />           |
| 一人前     | 5 <ItemLink id="minecraft:emerald" />             | 4 <ItemLink id="fluix_crystal" />               |
|            |                                                   |                                                 |
| 熟練者     | 5 <ItemLink id="matter_ball" />                   | 1 <ItemLink id="minecraft:emerald" />           |
| 熟練者     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="silicon_press" />               |
| 熟練者     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="logic_processor_press" />       |
| 熟練者     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="calculation_processor_press" /> |
| 熟練者     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="engineering_processor_press" /> |
|            |                                                   |                                                 |
| 達人       | 8 <ItemLink id="minecraft:emerald" />             | 5 <ItemLink id="minecraft:slime_ball" />        |
