---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 無線アクセスポイント
  icon: wireless_access_point
  position: 210
categories:
- devices
item_ids:
- ae2:wireless_booster
- ae2:wireless_access_point
---

# 無線アクセスポイント

<BlockImage id="wireless_access_point" p:state="has_channel" scale="8" />

<ItemLink id="wireless_terminal" />経由でワイヤレスアクセスを許可します。

範囲と電力使用量は、インストールされている<ItemLink id="wireless_booster" />の数に基づいて決定されます。

ネットワークには任意の数のワイヤレスアクセスポイントがあり、  
各アクセスポイントには任意の数の<ItemLink id="wireless_booster" />があるため、  
設定を変更することで電力使用量と範囲を最適化できます。

[チャンネル](../ae2-mechanics/channels.md)が必要です。

[ワイヤレスターミナル](wireless_terminals.md)をバインドするためにも使用されます。

# 無線ブースター

<ItemImage id="wireless_booster" scale="2" />

ワイヤレスアクセスポイントの範囲を拡大するために使用されます。

## レシピ

<RecipeFor id="wireless_access_point" />

<RecipeFor id="wireless_booster" />
