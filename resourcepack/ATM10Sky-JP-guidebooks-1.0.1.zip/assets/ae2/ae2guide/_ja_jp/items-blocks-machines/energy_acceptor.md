---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: エナジーアクセプター
  icon: energy_acceptor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_acceptor
---

# エナジーアクセプター

<Row gap="20">
<BlockImage id="energy_acceptor" scale="8" /> 

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
</GameScene>
</Row>

エナジーアクセプターは、他の技術モジュールからの一般的なエネルギー形式をAE2の内部形式の[エネルギー](../ae2-mechanics/energy.md)、AEに変換します。  
<ItemLink id="controller" />でもこれを行うことができますが、コントローラーの面は貴重なので、  
代わりにエナジーアクセプターを使用する方がよい場合がよくあります。

フォージエネルギーとテックリボーンエネルギーの変換比率は次のとおりです。

* 2 FE = 1 AE (フォージ)
* 1 E = 2 AE (ファブリック)

変換速度は、ネットワークが保存できるAEの量に完全に依存します。  
その理由は、[このページ](../ae2-mechanics/energy.md)で説明されています。

## バリエーション

エナジーアクセプターには、通常とフラットの2種類があります/[サブパーツ](../ae2-mechanics/cable-subparts.md)。  
これにより、一部のセットアップをよりコンパクトにすることができます。

エナジーアクセプターは、クラフトグリッド内で通常とフラットの間で入れ替えることができます。

## レシピ

<RecipeFor id="energy_acceptor" />

<RecipeFor id="cable_energy_acceptor" />