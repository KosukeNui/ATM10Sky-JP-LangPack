---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: クランク
  icon: crank
  position: 310
categories:
- machines
item_ids:
- ae2:crank
---

# クランク

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/crank_on_stuff.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

クランクは、電力(または<ItemLink id="energy_acceptor" />)にアクセスできない場合に、マシンに電力を供給するために使用されます。  
ゲーム序盤の苦労ですよね?

## レシピ

<RecipeFor id="crank" />
