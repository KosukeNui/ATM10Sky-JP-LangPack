---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 照光パネル
  icon: semi_dark_monitor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:monitor
- ae2:semi_dark_monitor
- ae2:dark_monitor
---

# 照光パネル

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/illuminated_panels.snbt" />
  <IsometricCamera yaw="-75" pitch="30" />
</GameScene>

照光パネルは装飾用の光源で、[ターミナル](terminals.md)の製造にも使用されます。

これらは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)です。

## レシピ

<Row>
  <RecipeFor id="monitor" />

  <RecipeFor id="semi_dark_monitor" />

  <RecipeFor id="dark_monitor" />
</Row>
