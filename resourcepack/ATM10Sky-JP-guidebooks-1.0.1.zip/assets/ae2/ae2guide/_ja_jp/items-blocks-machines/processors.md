---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: プロセッサ
  icon: logic_processor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:logic_processor
- ae2:calculation_processor
- ae2:engineering_processor
- ae2:printed_silicon
- ae2:printed_logic_processor
- ae2:printed_calculation_processor
- ae2:printed_engineering_processor
- ae2:silicon
---

# プロセッサ

<Row>
  <ItemImage id="logic_processor" scale="4" />

  <ItemImage id="calculation_processor" scale="4" />

  <ItemImage id="engineering_processor" scale="4" />
</Row>

プロセッサは、AE2[デバイス](../ae2-mechanics/devices.md)およびマシンの主要な構成要素の1つです。  
また、最初の大きな自動化の課題の1つでもあります。  
プロセッサには、それぞれ金、<ItemLink id="certus_quartz_crystal" />、ダイヤモンドで作られた3つのタイプがあります。  
これらは、<ItemLink id="inscriber" />の[金型](presses.md)を使用して、複数のステップから成るプロセス  
(通常は、一連のインスクライバーとフィルター付き配管によって実現)で製造されます。

## 加工手順

<Column gap="5">
  1.  必要な材料を集めたり作ったりします:  
  シリコン、レッドストーン、金、<ItemLink id="certus_quartz_crystal" />、ダイヤモンド。

  <RecipeFor id="silicon" />

  <br />

  2.  必要なプリント回路部品を挿入する

  <Row>
    <RecipeFor id="printed_silicon" />

    <RecipeFor id="printed_logic_processor" />
  </Row>

  <Row>
    <RecipeFor id="printed_calculation_processor" />

    <RecipeFor id="printed_engineering_processor" />
  </Row>

  <br />

  3.  最終組立

  <Row>
    <RecipeFor id="logic_processor" />

    <RecipeFor id="calculation_processor" />
  </Row>

  <RecipeFor id="engineering_processor" />
</Column>
