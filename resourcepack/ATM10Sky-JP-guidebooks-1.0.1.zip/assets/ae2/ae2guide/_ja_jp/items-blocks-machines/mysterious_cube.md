---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 神秘的なキューブ
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# 神秘的なキューブ

<BlockImage id="mysterious_cube" scale="8" />

プレス機をすべて見つけるために隕石をたくさん見つけなければならなかったことを覚えていますか?  
もうそんなことはありません!  
今では隕石にはミステリアスキューブが付属しています。

これを壊すとどうなるか気になります(シルクタッチなしで)...

レプリカの「あまり神秘的ではないキューブ」も作ることができます

## レシピ

<RecipeFor id="not_so_mysterious_cube" />
