---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ペイントボール
  icon: green_lumen_paint_ball
  position: 410
categories:
- tools
item_ids:
- ae2:white_paint_ball
- ae2:orange_paint_ball
- ae2:magenta_paint_ball
- ae2:light_blue_paint_ball
- ae2:yellow_paint_ball
- ae2:lime_paint_ball
- ae2:pink_paint_ball
- ae2:gray_paint_ball
- ae2:light_gray_paint_ball
- ae2:cyan_paint_ball
- ae2:purple_paint_ball
- ae2:blue_paint_ball
- ae2:brown_paint_ball
- ae2:green_paint_ball
- ae2:red_paint_ball
- ae2:black_paint_ball
- ae2:white_lumen_paint_ball
- ae2:orange_lumen_paint_ball
- ae2:magenta_lumen_paint_ball
- ae2:light_blue_lumen_paint_ball
- ae2:yellow_lumen_paint_ball
- ae2:lime_lumen_paint_ball
- ae2:pink_lumen_paint_ball
- ae2:gray_lumen_paint_ball
- ae2:light_gray_lumen_paint_ball
- ae2:cyan_lumen_paint_ball
- ae2:purple_lumen_paint_ball
- ae2:blue_lumen_paint_ball
- ae2:brown_lumen_paint_ball
- ae2:green_lumen_paint_ball
- ae2:red_lumen_paint_ball
- ae2:black_lumen_paint_ball
---

# ペイントボール

<Row gap="-8">
  <ItemImage id="white_paint_ball" scale="4" />

  <ItemImage id="orange_paint_ball" scale="4" />

  <ItemImage id="green_paint_ball" scale="4" />

  <ItemImage id="blue_paint_ball" scale="4" />

  <ItemImage id="red_paint_ball" scale="4" />
</Row>

ペイントボールは、<ItemLink id="color_applicator" />で[ケーブル](cables.md)、ウール、テラコッタ、ガラス、コンクリートなどの  
着色可能なブロックをペイントするために使用します。  
また、<ItemLink id="matter_cannon" />で使用して、小さなペイントの斑点を発射することもできます。

## レシピ

染料の周りに8つのマターボール

<Column>
  <Row>
    <RecipeFor id="white_paint_ball" />

    <RecipeFor id="orange_paint_ball" />

    <RecipeFor id="green_paint_ball" />
  </Row>

  <Row>
    <RecipeFor id="blue_paint_ball" />

    <RecipeFor id="red_paint_ball" />

    <RecipeFor id="black_paint_ball" />
  </Row>

  <br />
</Column>

# 輝くペイントボール

<Row gap="-8">
  <ItemImage id="white_lumen_paint_ball" scale="4" />

  <ItemImage id="orange_lumen_paint_ball" scale="4" />

  <ItemImage id="green_lumen_paint_ball" scale="4" />

  <ItemImage id="blue_lumen_paint_ball" scale="4" />

  <ItemImage id="red_lumen_paint_ball" scale="4" />
</Row>

通常のペイントボールと同じように動作しますが、<ItemLink id="matter_cannon" />から発射されると斑点が光を発します。

一種のフレアガンとして役立つと思います。

## レシピ

グロウストーンダストの周りにペイントボール8個

<Column>
  <Row>
    <RecipeFor id="white_lumen_paint_ball" />

    <RecipeFor id="orange_lumen_paint_ball" />

    <RecipeFor id="green_lumen_paint_ball" />
  </Row>

  <Row>
    <RecipeFor id="blue_lumen_paint_ball" />

    <RecipeFor id="red_lumen_paint_ball" />

    <RecipeFor id="black_lumen_paint_ball" />
  </Row>
</Column>
