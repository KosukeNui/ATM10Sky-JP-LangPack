---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 空間アンカー
  icon: spatial_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:spatial_anchor
---

# 空間アンカー

<BlockImage id="spatial_anchor" p:powered="true" scale="8"/>

AE2ネットワークは、その[デバイス](../ae2-mechanics/devices.md)のいずれかが機能するためにチャンクロードされる必要があり、  
一部だけがロードされると、正しく機能しない可能性があります。  
空間アンカーはこの問題を解決します。  
空間アンカーは、ネットワークが占めるチャンクを強制的にロードします。
チャンクの境界を越えて伸びる1本のケーブルで、その新しいチャンクをロードできます。

空間アンカーは[量子ブリッジ](quantum_bridge.md)全体に「ロード」を伝播しますが、次元をまたいで伝播することはありません。  
そのため、ネザーへの量子ブリッジがある場合は、基地のネットワークとネザーのネットワークに空間アンカーが必要です。

デフォルトでは、ロードされたチャンクでランダムティックも有効になりますが、これはAE2構成でオフにできます。

何らかの理由で回転したい場合は、<ItemLink id="certus_quartz_wrench" />で回転できます。

## 設定

* 空間アンカーは、AEまたはE/FEでエネルギーを表示するためのグローバル設定へのアクセスを提供します。

* ロードされているチャンクを示すインワールドホログラムを表示できます。

## エネルギー

空間アンカーは、次の式に従って[エネルギー](../ae2-mechanics/energy.md)を使用します:

e = 80 + (x\*(x+1))/2

xはロードされているチャンクの数です

## レシピ

<RecipeFor id="spatial_anchor" />
