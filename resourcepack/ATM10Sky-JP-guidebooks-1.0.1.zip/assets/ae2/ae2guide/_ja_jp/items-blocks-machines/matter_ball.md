---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 物質ボール
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# 物質ボール

<ItemImage id="matter_ball" scale="4" />

一般的な物質のボール。<ItemLink id="matter_cannon" />の弾薬として、または[ペイントボール](paintballs.md)の作成に便利です。

物質ボールモードの<ItemLink id="condenser" />で256個のアイテムまたはバケツを使用して作成します。
