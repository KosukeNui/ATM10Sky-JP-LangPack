---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 火力発電機
  icon: vibration_chamber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:vibration_chamber
---

# 火力発電機

<BlockImage id="vibration_chamber" p:active="true" scale="8" />

ネットワークに[エネルギー](../ae2-mechanics/energy.md)を供給する主な方法は<ItemLink id="energy_acceptor" />ですが、  
火力発電機は少量から中程度のAEを直接生成できます。

デフォルト([アップグレード](upgrade_cards.md)なし、デフォルト構成)では40AE/tを生成します。

ネットワークの[エネルギー](../ae2-mechanics/energy.md)ストレージがいっぱいになると、  
火力発電機は燃料を節約するためにスロットルを下げますが、完全に停止することはできません。

## 設定

* 火力発電機は、AEまたはE/FEでエネルギーを表示するためのグローバル設定へのアクセスを提供します。

## アップグレード

火力発電機は、次の[アップグレード](upgrade_cards.md)をサポートしています:

* <ItemLink id="energy_card" />は、チャンバーの効率を+50%増加させます。最大+150%、つまり基本効率の250%です。

* <ItemLink id="speed_card" />は、チャンバーの燃焼率を+50%増加させます。最大+150%、つまり基本出力の250%です。

## 構成

火力発電機のプロパティは、.minecraft\ディレクトリの config フォルダーにある ae2 フォルダーの common.json で編集できます。

* baseEnergyPerFuelTick は、火力発電機のアップグレードされていない基本効率を設定します。

* minEnergyPerGameTick は、可能な限り低いエネルギー生成を設定します (ネットワークがエネルギーを必要としない場合でも、チャンバーは常に少しずつ燃料を使用します)。
* maxEnergyPerGameTick は、火力発電機のアップグレードされていない最大出力 (および速度) を設定します。

## レシピ

<RecipeFor id="vibration_chamber" />
