---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: スカイストーンダスト
  icon: sky_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_dust
---

# スカイストーンダスト

<ItemImage id="sky_dust" scale="4" />

<ItemLink id="inscriber" />によって押しつぶされた<ItemLink id="sky_stone_block" />ブロック。
<ItemLink id="cell_component_256k" />および<ItemLink id="sky_stone_block" />の作成に使用されます。

<ItemLink id="annihilation_plane" />をワールドの高さ制限まで上向きに向けることでも取得できます。

## レシピ

<RecipeFor id="sky_dust" />
