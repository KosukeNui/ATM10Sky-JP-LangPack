---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ストレージセル
  icon: item_storage_cell_1k
  position: 410
categories:
- tools
item_ids:
- ae2:item_cell_housing
- ae2:fluid_cell_housing
- ae2:cell_component_1k
- ae2:cell_component_4k
- ae2:cell_component_16k
- ae2:cell_component_64k
- ae2:cell_component_256k
- ae2:item_storage_cell_1k
- ae2:item_storage_cell_4k
- ae2:item_storage_cell_16k
- ae2:item_storage_cell_64k
- ae2:item_storage_cell_256k
- ae2:fluid_storage_cell_1k
- ae2:fluid_storage_cell_4k
- ae2:fluid_storage_cell_16k
- ae2:fluid_storage_cell_64k
- ae2:fluid_storage_cell_256k
---

# ストレージセル

<Column>
  <Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

  <Row>
    <ItemImage id="fluid_storage_cell_1k" scale="4" />

    <ItemImage id="fluid_storage_cell_4k" scale="4" />

    <ItemImage id="fluid_storage_cell_16k" scale="4" />

    <ItemImage id="fluid_storage_cell_64k" scale="4" />

    <ItemImage id="fluid_storage_cell_256k" scale="4" />
  </Row>
</Column>

ストレージセルは、Applied Energisticsにおける主要なストレージ方法の1つです。  
<ItemLink id="drive" />または<ItemLink id="chest" />に格納されます。

バイトとタイプの容量については、[バイトとタイプ](../ae2-mechanics/bytes-and-types.md)を参照してください。

セルが空の場合、セルを手に持ってShiftキーを押しながら右クリックすると、ストレージ コンポーネントをハウジングから取り外すことができます。

<Row>
    <Recipe id="upgrade/item_storage_cell_1k_to_4k" />

    ストレージセルは、作業台でより上位のストレージコンポーネントと組み合わせると、上位の段階にアップグレードできます。中身はそのまま残り、下位のコンポーネントは返却されます。
</Row>

## タイプ数が異なる場合のストレージ容量

[タイプの初期コスト](../ae2-mechanics/bytes-and-types.md)は、  
1つのタイプを保持するセルが、63種類すべてを使用しているセルの2倍を保持できるというものです。

| セル                                     | 1タイプ使用時のセルの合計容量                | 63タイプ使用時のセル合計容量                  |
| ---------------------------------------- | ----------------------------------------: | ------------------------------------------: |
| <ItemLink id="item_storage_cell_1k" />   |                                     8,128 |                                       4,160 |
| <ItemLink id="item_storage_cell_4k" />   |                                    32,512 |                                      16,640 |
| <ItemLink id="item_storage_cell_16k" />  |                                   130,048 |                                      66,560 |
| <ItemLink id="item_storage_cell_64k" />  |                                   520,192 |                                     266,240 |
| <ItemLink id="item_storage_cell_256k" /> |                                 2,080,768 |                                   1,064,960 |


## パーティション分割

セルは、<ItemLink id="storage_bus" />をフィルター処理する方法と同様に、特定のアイテムのみを受け入れるようにフィルター処理できます。  
これは、<ItemLink id="cell_workbench" />で行われます。

アイテムを実際に持っていなくても、JEI/REIからスロットにアイテムをドラッグできます。

## アップグレード

ストレージセルは、<ItemLink id="cell_workbench" />を介して挿入される次の[アップグレード](upgrade_cards.md)をサポートします:

* <ItemLink id="fuzzy_card" />(流体セルでは利用できません)を使用すると、セルを損傷レベル別に分割したり、アイテムNBTを無視したりできます
* <ItemLink id="inverter_card" />を使用すると、フィルターがホワイトリストからブラックリストに切り替わります
* <ItemLink id="equal_distribution_card" />を使用すると、各タイプに同じ量のセルバイトスペースが割り当てられるため、  
  1つのタイプでセル全体がいっぱいになることはありません
* <ItemLink id="void_card" />を使用すると、セルがいっぱいの場合(または均等配分カードの場合は、  
  その特定のタイプに割り当てられたスペース)、挿入されたアイテムが無効になります。  
  これは、ファームのバックアップを防ぐのに役立ちます。パーティション分割には注意してください!
* ポータブルセルは、バッテリー容量を増やすために<ItemLink id="energy_card" />を受け入れることができます

## 着色

ポータブルアイテムと流体セルは、染料と一緒に作成することで、革の鎧と同じように着色できます。

# ハウジング

セルは、ストレージコンポーネントとハウジングを使用して作成するか、  
ストレージ コンポーネントを囲むハウジングレシピを使用して作成できます。

<Row>
  <Recipe id="network/cells/item_storage_cell_1k" />

  <Recipe id="network/cells/item_storage_cell_1k_storage" />
</Row>

ハウジング自体は次のように作られています:

<Row>
  <RecipeFor id="item_cell_housing" />

  <RecipeFor id="fluid_cell_housing" />
</Row>

# ストレージコンポーネント

ストレージコンポーネントはすべてのAE2セルの中核であり、セルの容量を決定します。  
各ティアの容量は4倍になり、コストは前のティアの3倍になります。

<Column>
  <Row>
    <RecipeFor id="cell_component_1k" />

    <RecipeFor id="cell_component_4k" />

    <RecipeFor id="cell_component_16k" />
  </Row>

  <Row>
    <RecipeFor id="cell_component_64k" />

    <RecipeFor id="cell_component_256k" />
  </Row>
</Column>

# アイテムストレージセル

アイテムストレージセルには最大63種類のアイテムを保管でき、すべての標準容量で利用できます。

<Column>
  <Row>
    <Recipe id="network/cells/item_storage_cell_1k_storage" />

    <Recipe id="network/cells/item_storage_cell_4k_storage" />

    <Recipe id="network/cells/item_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/item_storage_cell_64k_storage" />

    <Recipe id="network/cells/item_storage_cell_256k_storage" />
  </Row>
</Column>

## ポータブルアイテムストレージ

これらはポケットの中の小さな<ItemLink id="chest" />として、またはバックパックのような形で機能します。  
<ItemLink id="charger" />で充電できます。

標準のストレージセルとは異なり、これらはバイト容量が増加するとタイプ容量が実際に *減少* し、合計バイト容量の半分になります。

すべてのセルが受け取ることができるアップグレードカードに加えて、  
これらは内部バッテリーをアップグレードするための<ItemLink id="energy_card" />も受け入れます。

<Column>
  <Row>
    <RecipeFor id="portable_item_cell_1k" />

    <RecipeFor id="portable_item_cell_4k" />

    <RecipeFor id="portable_item_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_item_cell_64k" />

    <RecipeFor id="portable_item_cell_256k" />
  </Row>
</Column>

# 液体貯蔵セル

液体貯蔵セルは最大5種類の液体を貯蔵でき、すべての標準容量で利用できます。

<Column>
  <Row>
    <Recipe id="network/cells/fluid_storage_cell_1k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_4k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/fluid_storage_cell_64k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_256k_storage" />
  </Row>
</Column>

## ポータブル液体ストレージ

これらはポケットの中の小さな<ItemLink id="chest" />として、またはバックパックのような形で機能します。  
これらは<ItemLink id="charger" />で充電できます。

標準のストレージセルとは異なり、これらはバイト容量が増加すると実際にタイプ容量が *減少* し、合計バイト容量の半分になります。

すべてのセルが受け取ることができるアップグレードカードに加えて、  
これらは内部バッテリーをアップグレードするための<ItemLink id="energy_card" />も受け入れます。

<Column>
  <Row>
    <RecipeFor id="portable_fluid_cell_1k" />

    <RecipeFor id="portable_fluid_cell_4k" />

    <RecipeFor id="portable_fluid_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_fluid_cell_64k" />

    <RecipeFor id="portable_fluid_cell_256k" />
  </Row>
</Column>

# クリエイティブストレージセル

<Row>
  <ItemImage id="creative_storage_cell" scale="2" />
</Row>

クリエイティブセルは、**無限のストレージを提供するわけではありません**。  
代わりに、任意のアイテムまたは流体を[パーティション](cell_workbench.md)して無限のソースおよびシンクとして機能します。
