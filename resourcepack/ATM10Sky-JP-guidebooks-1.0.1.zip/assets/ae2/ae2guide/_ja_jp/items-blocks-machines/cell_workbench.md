---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: セルワークベンチ
  icon: cell_workbench
  position: 310
categories:
- machines
item_ids:
- ae2:cell_workbench
---

# セルワークベンチ

<BlockImage id="cell_workbench" scale="8" />

セルワークベンチを使用すると、[ストレージセル](storage_cells.md)と<ItemLink id="view_cell" />を構成できます。

[アップグレードカード](upgrade_cards.md)を追加し、「パーティション」を構成して、セルに格納されるものをフィルターできます。

アイテムや液体は、実際にそのアイテムを持っていなくても、JEI/REI からスロットにドラッグできます。

液体コンテナ(バケツや液体タンクなど)を右クリックして、バケツやタンクアイテムの代わりにその液体をフィルターとして設定します。

## 設定

セルワークベンチの左上には、次のボタンがいくつかあります:

* 既存のコンテンツに基づいてセルをパーティション分割できます
* セルのパーティション分割をクリアできます
* セルが削除されたときにパーティション設定を保持するようにワークベンチを設定できるため、セル間で設定をコピーできます。

## レシピ

<RecipeFor id="cell_workbench" />
