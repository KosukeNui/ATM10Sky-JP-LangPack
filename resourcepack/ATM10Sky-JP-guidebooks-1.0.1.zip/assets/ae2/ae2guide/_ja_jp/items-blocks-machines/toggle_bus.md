---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: トグルバス
  icon: toggle_bus
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:toggle_bus
- ae2:inverted_toggle_bus
---

# トグルバス

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/toggle_bus.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="fluix_glass_cable" />や他のケーブルと同様に機能するバスですが、接続状態をレッドストーン経由で切り替えることができます。  
これにより、[MEネットワーク](../ae2-mechanics/me-network-connections.md)の一部を切断できます。

レッドストーン信号が供給されるとパーツは接続を有効にし、<ItemLink id="inverted_toggle_bus" />は接続を無効にすることで逆の動作を提供します。

なお、これらを切り替えると、ネットワークが再起動し、接続されているデバイスが再計算される可能性があります。

これらは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)です。

## レシピ

<RecipeFor id="toggle_bus" />

<RecipeFor id="inverted_toggle_bus" />
