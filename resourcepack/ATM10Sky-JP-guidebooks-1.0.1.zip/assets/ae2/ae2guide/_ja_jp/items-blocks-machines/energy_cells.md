---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: エナジーセル
  icon: energy_cell
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_cell
- ae2:dense_energy_cell
- ae2:creative_energy_cell
---

# エナジーセル

<Row gap="20">
  <BlockImage id="energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="8" />
</Row>

エネルギーセルは、ネットワークにより多くの[エネルギー](../ae2-mechanics/energy.md)ストレージを提供します。  
ある程度のエネルギーバッファは、大量のアイテムが挿入または抽出されるときにエネルギー消費の急増を緩和するのに役立ちます。  
また、大量のエネルギーストレージは、エネルギーが生成されていないとき(ソーラー パネルを使用した夜間など)にネットワークを実行したり、  
[空間ストレージ](../ae2-mechanics/spatial-io.md)の大量の瞬間エネルギー消費を処理したりすることができます。

## 塗りつぶしバー

<Row>
<BlockImage id="energy_cell" scale="4" p:fullness="0" />
<BlockImage id="energy_cell" scale="4" p:fullness="1" />
<BlockImage id="energy_cell" scale="4" p:fullness="2" />
<BlockImage id="energy_cell" scale="4" p:fullness="3" />
<BlockImage id="energy_cell" scale="4" p:fullness="4" />
</Row>

セルの側面にあるバーは、そのセルのエネルギー量に対応しています。

* 25% 未満の充電の場合 0
* 25% から 50% の充電の場合 1
* 50% から 75% の充電の場合 2
* 75% から 99% の充電の場合 3
* 99% を超える充電の場合 4

## セルの種類

* <ItemLink id="energy_cell" />は200kAEを保存でき、ほとんどの使用ケースでは1つで十分であり、  
  通常のネットワーク使用時の電力サージを簡単に処理できます。
* <ItemLink id="dense_energy_cell" />は1.6MAEを保存でき、保存された電力でネットワークを実行したい場合や、  
  大規模な[空間ストレージ](../ae2-mechanics/spatial-io.md)セットアップの大量の瞬間エネルギー消費を処理する場合に使用します。
* <ItemLink id="creative_energy_cell" />は、無制限のパワーなどを提供する、テスト用のクリエイティブアイテムです。

## レシピ

<Row>
  <RecipeFor id="energy_cell" />

  <RecipeFor id="dense_energy_cell" />
</Row>
