---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: スカイストーン
  icon: sky_stone_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_stone_block
- ae2:smooth_sky_stone_block
---

# スカイストーン

<BlockImage id="sky_stone_block" scale="8" />

材料[隕石](../ae2-mechanics/meteorites.md)は、<ItemLink id="sky_stone_tank" />、<ItemLink id="not_so_mysterious_cube" />、  
<ItemLink id="cell_component_256k" />、そして最も重要な<ItemLink id="controller" />のレシピで使用されます。

## レシピ

スカイ ストーンダストを取得するには、最大ワールド高度で上向きの消滅プレーンを配置します。

<RecipeFor id="sky_stone_block" />

<RecipeFor id="smooth_sky_stone_block" />
