---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: エントロピーマニピュレーター
  icon: entropy_manipulator
  position: 410
categories:
- tools
item_ids:
- ae2:entropy_manipulator
---

# エントロピーマニピュレーター

<ItemImage id="entropy_manipulator" scale="4" />

エントロピーマニピュレーターを使用すると、右クリックとShiftキーを押しながら右クリックすることで、  
それぞれ物を加熱したり冷却したりできます。

このツールでできることは多くありませんが、  
水を蒸発または凍結したり、溶岩を黒曜石に固めたり、丸太を木炭に精錬したり、丸石を石に精錬したりすることはできます。
ブロックに対して特定の操作ができない場合は、火打石と打ち金として機能します。

このツールのエネルギーは、<ItemLink id="charger" />で充電できます。

## レシピ

<RecipeFor id="entropy_manipulator" />
