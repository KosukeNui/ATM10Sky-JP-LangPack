---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 金型
  icon: silicon_press
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:silicon_press
- ae2:logic_processor_press
- ae2:calculation_processor_press
- ae2:engineering_processor_press
- ae2:name_press
---

# 金型

<ItemLink id="inscriber" />では5種類の金型が使用されています。

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

<ItemImage id="name_press" scale="4" />

## プロセッサプレス

[プロセッサ](processors.md)の製造には、シリコン、基本、上級、発展の金型が使用されます。

これらの4つの金型は、[隕石](../ae2-mechanics/meteorites.md)内の<ItemLink id="mysterious_cube" />を破壊することで取得できます。

これらは<ItemLink id="inscriber" />で複製することもできます。

<Column>
  <Row>
    <RecipeFor id="silicon_press" />

    <RecipeFor id="logic_processor_press" />
  </Row>

  <Row>
    <RecipeFor id="calculation_processor_press" />

    <RecipeFor id="engineering_processor_press" />
  </Row>
</Column>

## 名称銘記プレス

名称銘記プレスは、金床のように、刻印機でアイテムに名前を付けるために使用できます。

作成するには、<ItemLink id="certus_quartz_cutting_knife" />または<ItemLink id="nether_quartz_cutting_knife" />を右クリックして金属のインゴットを挿入し、　　
プレートに書きたい名前を入力して、完成したプレートを取り出すだけです。　　
刻印機では一度に1枚または2枚のプレートを使用できます。
2枚のプレートを使用する場合は、上部のスロット、次に下部のスロットの両方の名前の組み合わせを使用して名前が印刷されます。
