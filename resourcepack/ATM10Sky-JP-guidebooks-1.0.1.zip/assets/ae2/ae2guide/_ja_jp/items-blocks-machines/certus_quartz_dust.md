---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ケルタスクォーツダスト
  icon: certus_quartz_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_dust
---

# ケルタスクォーツダスト

<ItemImage id="certus_quartz_dust" scale="4" />

<ItemLink id="inscriber" />によって粉砕された<ItemLink id="certus_quartz_crystal" />。  
いくつかのAE2材料とコンポーネントの製造に使用されます。

## レシピ

<RecipeFor id="certus_quartz_dust" />
