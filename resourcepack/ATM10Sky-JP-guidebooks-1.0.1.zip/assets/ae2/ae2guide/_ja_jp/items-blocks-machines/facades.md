---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ファサード
  icon: facade
  icon_components:
    "ae2:facade_item": "minecraft:stone"
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:facade
---

# ファサード

ファサードを使用すると、基地をよりすっきりと見せることができます。  
ファサードは、両方のサイズのケーブルをカバーでき、さまざまな種類のブロックで作成できます。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/facades_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ケーブルのすべての側面を覆うことができますが、[サブパーツ](../ae2-mechanics/cable-subparts.md)とケーブル接続は突き出たままになります。

<GameScene zoom="6"  interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

これらを巧みに活用してベースの美観を向上させたり、各面に異なるテクスチャを持つブロックを作成したりします。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_3.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## ファサードを隠す

どちらかの手に<a href="network_tool.md">ネットワークツール</a>を持っている間は、ファサードは非表示になります。

最初にファサードを削除しなくても、非表示のファサードの背後にあるブロックを操作できます。

## レシピ

テクスチャを適用したいブロックを4つの<ItemLink id="cable_anchor" />の中央に配置します。

![ファサードレシピ](../assets/diagrams/facade_recipe.png)
