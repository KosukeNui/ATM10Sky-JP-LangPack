---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: MEチェスト
  icon: chest
  position: 210
categories:
- devices
item_ids:
- ae2:chest
---

# MEチェスト

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/chest.snbt" />
</GameScene>

MEチェストは、<ItemLink id="terminal" />、<ItemLink id="drive" />、<ItemLink id="energy_acceptor" />を備えたミニチュアネットワークのように機能します。

これは小さなストレージネットワークとして使用できますが、1つの[ストレージセル](../items-blocks-machines/storage_cells.md)のみに対応しているため、  
それ自体の有用性は限られています。

代わりに、内部にマウントされているストレージセルと具体的にやり取りする場合に役立ちます。  
統合ターミナルはマウントされたドライブ内のアイテムのみを表示およびアクセスできますが、  
一般ネットワーク上の[デバイス](../ae2-mechanics/devices.md)は、  
MEチェストを含むすべての[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)内のアイテムにアクセスできます。

2つの異なるGUIがあり、アイテムの転送用に側面が設けられています。  
上部のターミナルとやり取りすると、統合ターミナルが開きます。  
この面からマウントされたストレージセルにアイテムを挿入することはできますが、取り出すことはできません。  
他の面とやり取りすると、ストレージセルのスロットと優先度設定を含むGUIが開きます。  
アイテムロジスティクスによってセルを挿入および削除できるのは、セルスロットを含む面からのみです。

<ItemLink id="certus_quartz_wrench" />を使用して回転できます。

このセルには小さなAEエネルギーストレージバッファーがあるため、  
[エネルギーセル](../items-blocks-machines/energy_cells.md)のあるネットワークに接続されていない場合、  
一度にアイテムを挿入または取り出す回数が多すぎると、バッテリーが切れる可能性があります。

ターミナルは<ItemLink id="color_applicator" />を使用して色付けできます。

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/chest_color.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 設定

MEチェストには、<ItemLink id="terminal" />または<ItemLink id="crafting_terminal" />と同じ設定がすべてあります。
ただし、<ItemLink id="view_cell" />はサポートされていません。

## セルステータスLED

チェスト内のセルには、そのステータスを示すLEDが付いています。

| 色     | 状態                                                                                 |
| :----- | :----------------------------------------------------------------------------------- |
| 緑     | 空                                                                                   |
| 青     | 内容あり                                                                              |
| 橙     | [タイプ](../ae2-mechanics/bytes-and-types.md)フル, 新しいタイプを追加することはできません |
| 赤     | [バイト](../ae2-mechanics/bytes-and-types.md)フル, アイテムを追加することはできません    |
| 黒     | 電源無し or ドライブが[チャンネル](../ae2-mechanics/channels.md)無し                    |

## 優先度

優先度は、セルスロットGUIの右上にあるレンチをクリックして設定できます。

ネットワークに入るアイテムは、最初の宛先として優先度が最も高いストレージから開始されます。  
2つのストレージまたはセルの優先度が同じ場合、一方にすでにアイテムが含まれていると、  
そのストレージが他のストレージよりも優先されます。  
[パーティション化された](cell_workbench.md)セルは、他のストレージと同じ優先度グループにある場合、  
すでにアイテムが含まれているものとして扱われます。  
ストレージから削除されるアイテムは、優先度が最も低いストレージから削除されます。  
この優先度システムでは、アイテムがネットワーク ストレージに挿入および削除されると、  
優先度の高いストレージがいっぱいになり、優先度の低いストレージが空になります。

## レシピ

<RecipeFor id="chest" />
