---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 形成/消滅コア
  icon: formation_core
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:formation_core
- ae2:annihilation_core
---

# 形成/消滅コア

<Row>
  <ItemImage id="formation_core" scale="4" />

  <ItemImage id="annihilation_core" scale="4" />
</Row>

これらは、AE2の入力および出力[デバイス](../ae2-mechanics/devices.md)の主要コンポーネントです。  
<ItemLink id="fluix_crystal" />と[プロセッサ](processors.md)のパワーを使用して、  
デバイスがアイテム、ブロック、流体などを入力および出力できるようにします(実際の機能はなく、作成の中間体にすぎません)

## レシピ

<RecipeFor id="formation_core" />

<RecipeFor id="annihilation_core" />
