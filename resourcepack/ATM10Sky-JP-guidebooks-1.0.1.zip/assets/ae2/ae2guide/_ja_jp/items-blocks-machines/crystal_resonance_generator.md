---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 水晶共振発生器
  icon: crystal_resonance_generator
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:crystal_resonance_generator
---

# 水晶共振発生器

<BlockImage id="crystal_resonance_generator" scale="8" />

このデバイスは、燃料なしでMEネットワークのエネルギーを生み出します。このデバイスが起こす水晶の振動のため、1つのネットワークで使えるのは1台だけです。この振動は<ItemLink id="quartz_fiber" />さえも通り抜けます。

**発電量:** <ae2:ConfigValue name="crystalResonanceGeneratorRate"/> AE/t

## レシピ

<RecipeFor id="crystal_resonance_generator" />
