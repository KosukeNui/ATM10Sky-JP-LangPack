---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: フルーシュダスト
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# フルーシュダスト

<ItemImage id="fluix_dust" scale="4" />

<ItemLink id="inscriber" />によって粉砕された<ItemLink id="fluix_crystal" />。  
いくつかのAE2マシンとコンポーネントの製造に使用されます。

## レシピ

<RecipeFor id="fluix_dust" />
