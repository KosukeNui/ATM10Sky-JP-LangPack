---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: MEインポートバス
  icon: import_bus
  position: 220
categories:
- devices
item_ids:
- ae2:import_bus
---

# MEインポートバス

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/import_bus.snbt" />
</GameScene>

インポートバスは、アイテムと流体(およびアドオンが指定されている場合はその他すべて)を、  
アクセスしているインベントリから引き出して、[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)にプッシュします。

遅延を減らすために、インポートバスが最近何かをインポートしていない場合は、  
一種の「スリープモード」に入り、ゆっくりと動作します。  
そして、何かを正常にインポートすると、起動してフルスピード(1秒あたり4操作)に加速します。

これらは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)です。

## フィルタリング

デフォルトでは、バスはアクセスできるものすべてをインポートします。  
フィルタースロットに挿入されたアイテムはホワイトリストとして機能し、特定のアイテムのみをインポートできます。

アイテムと流体は、実際にそのアイテムを持っていなくても、JEI/REIからスロットにドラッグできます。

流体コンテナー(バケツや流体タンクなど)を右クリックして、その流体をバケツやタンクアイテムではなくフィルターとして設定します。

## アップグレード

インポートバスは、次の[アップグレード](upgrade_cards.md)をサポートします:

* <ItemLink id="capacity_card" />は、フィルタースロットの数を増やします
* <ItemLink id="speed_card" />は、操作ごとに移動するアイテムの量を増やします
* <ItemLink id="fuzzy_card" />は、バスがダメージレベルでフィルター処理したり、アイテムNBTを無視したりできるようにします
* <ItemLink id="inverter_card" />は、フィルターをホワイトリストからブラックリストに切り替えます
* <ItemLink id="redstone_card" />は、レッドストーン制御を追加し、高信号、低信号、またはパルスごとに1回アクティブにできるようにします

## 速度

| 加速カード          | 操作ごとに移動するアイテム  |
|:-------------------|:--------------------------|
| 0                  | 1                         |
| 1                  | 8                         |
| 2                  | 32                        |
| 3                  | 64                        |
| 4                  | 96                        |

## レシピ

<RecipeFor id="import_bus" />
