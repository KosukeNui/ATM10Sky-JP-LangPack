---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 消滅プレーン
  icon: annihilation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:annihilation_plane
---

# 消滅プレーン

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/annihilation_plane.snbt" />
</GameScene>

消滅プレーンはブロックを破壊してアイテムを拾います。  
<ItemLink id="import_bus" />と同様に動作し、物を[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)に押し込みます。  
アイテムを拾うには、プレーンの面に衝突する必要があります。エリア内で拾うことはできません。

消滅プレーンは、任意のツルハシエンチャントでエンチャントできます。  
そのため、MODパックで許可されている場合は、いくつかのプレーンに非常に高いレベルの幸運を設定し、[鉱石処理を自動化](../example-setups/ore-fortuner.md)できます。  
さらに、シルクタッチは期待どおりに機能し、効率強化はブロックを壊すためのエネルギーコストを削減し、  
ブロックを壊さないことでエネルギーをまったく使用しない可能性が高まります。

これらは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)です。

**チャンク保護することを忘れないでください**

## フィルタリング

消滅プレーンは、結果として生じるドロップ/アイテムをネットワーク内に保存できる場合にのみ、  
ブロックを破壊したりアイテムを拾ったりします。  
つまり、フィルタリングするには、*ネットワーク上に保存できるものを制限する必要があります*。  
おそらく、それを[サブネットワーク](../ae2-mechanics/subnetworks.md)に配置することによって制限されます。  
これを実現するには、<ItemLink id="storage_bus" />または[ストレージセル](../items-blocks-machines/storage_cells.md)を[パーティション分割](cell_workbench.md)できます。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/annihilation_filtering.snbt" />

  <DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        破壊したいものからドロップされるものにフィルタリングされます。
  </DiamondAnnotation>

  <DiamondAnnotation pos=".5 0.5 2.5" color="#00ff00">
        破壊したいものからドロップするものに分割されます。
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

繰り返しますが、これは*アイテムドロップ*によってフィルタリングされるため、  
たとえば、<ItemLink id="minecraft:amethyst_cluster" />の破壊をフィルタリングしたい場合、
シルクタッチでエンチャントされた消滅プレーンが必要です。  
そうしないと、以前の成長段階では何もドロップされず、ネットワークは常に「何も」保存できないため、  
プレーンは何をしてもそれらを破壊します。

## レシピ

<RecipeFor id="annihilation_plane" />
