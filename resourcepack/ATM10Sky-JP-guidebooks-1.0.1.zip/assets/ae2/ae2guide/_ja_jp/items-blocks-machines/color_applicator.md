---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 染色ブラシ
  icon: color_applicator
  position: 410
categories:
- tools
item_ids:
- ae2:color_applicator
---

# 染色ブラシ

<ItemImage id="color_applicator" scale="4" />

染色ブラシは、[ケーブル](cables.md)、ウール、テラコッタ、ガラス、コンクリートなどの着色可能なブロックをペイントするのに使用します。
[ペイントボール](paintballs.md)または染料を使用し、ケーブルの色やブロックのペイントボールのしみを落とすにはスノーボールを使用できます。

エネルギーは<ItemLink id="charger" />で充電できます。

染色ブラシは[ストレージセル](storage_cells.md)のように動作し、  
ペイントストレージはアプリケーターを<ItemLink id="chest" />のストレージセルスロットに差し込むことで最も簡単に満たすことができます。

対象を右クリックすると、選んでいる色を塗ります。色を変えるには、Shiftキーを押しながらマウスホイールを回すか、対象のないところで右クリックします。

## アップグレード

染色ブラシは、<ItemLink id="cell_workbench" />を介して挿入される次の[アップグレード](upgrade_cards.md)をサポートします:

* <ItemLink id="equal_distribution_card" />は各タイプに同じ量のセルバイトスペースを割り当てるため、1つのタイプでセル全体を埋めることはできません
* <ItemLink id="void_card" /> は、セルがいっぱいの場合(または均等配分カードの場合はその特定のタイプに割り当てられたスペース)、  
挿入されたアイテムを無効にします。これをパーティション分割するときは注意してください!
* <ItemLink id="energy_card" /> は、バッテリー容量を増やすために使用します

## レシピ

<RecipeFor id="color_applicator" />
