---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: フルーシュの水晶
  icon: fluix_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_crystal
---

# フルーシュの水晶

<ItemImage id="fluix_crystal" scale="4" />

*「フルーシュの水晶は、エネルギーを吸収してある形から別の形に変換する独自の能力を備えており、*  
*すべてのMEテクノロジーの基礎となっています」*

AE2ブロック、[デバイス](../ae2-mechanics/devices.md)、およびアイテムの主な材料の1つです。  
ネザークォーツ、レッドストーン、および<ItemLink id="charged_certus_quartz_crystal" />を水中に投げ込むことで作成されます。

<ItemLink id="formation_plane" />および<ItemLink id="annihilation_plane" />を使用して[自動化](../example-setups/throw-in-water-automation.md)できます。

## レシピ

<Row>
  <Recipe id="transform/fluix_crystals" />

  <Recipe id="transform/fluix_crystal" />

  <Recipe id="misc/deconstruction_fluix_block" />
</Row>
