---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: スカイストーンタンク
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# スカイストーンタンク

<BlockImage id="sky_stone_tank" scale="8" />

16バケツ分の液体を貯蔵する液体タンクです。  
持ち上げても中身は残りません。他に言うことはありません。

## レシピ

<RecipeFor id="sky_stone_tank" />
