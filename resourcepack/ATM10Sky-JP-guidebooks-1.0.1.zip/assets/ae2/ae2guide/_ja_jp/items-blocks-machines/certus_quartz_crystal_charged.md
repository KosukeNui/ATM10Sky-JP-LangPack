---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: チャージ済みのケルタスクォーツの水晶
  icon: charged_certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:charged_certus_quartz_crystal
---

# チャージ済みのケルタスクォーツの水晶

<ItemImage id="charged_certus_quartz_crystal" scale="4" />

<ItemLink id="charger" />で処理された<ItemLink id="certus_quartz_crystal" />。
<ItemLink id="fluix_crystal" />および[芽生えたケルタスブロック](../items-blocks-machines/budding_certus.md)の製造に使用されます。

## レシピ

<RecipeFor id="charged_certus_quartz_crystal" />
