---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: マターコンデンサー
  icon: condenser
  position: 310
categories:
- machines
item_ids:
- ae2:condenser
---

# マターコンデンサー

<BlockImage id="condenser" scale="8" />

マターコンデンサーはゴミ箱として、または<ItemLink id="matter_ball" />や[シンギュラリティ](singularities.md)を作成するために使用できます。  
ストレージセルに保存できるあらゆるアイテムや流体などを取得できます。

## 設定

* ゴミ箱モードでは、物質コンデンサーは、その中に入ったものをすべて無効にします
* 物質ボールモードでは、コンデンサーは、その中に入れたものから<ItemLink id="matter_ball" />を作成します。
  このモードでは、コンデンサーの上部スロットにストレージ コンポーネントを配置する必要があります。  
  物質ボールはそれぞれ256個のアイテムまたはバケツを取り込むため、<ItemLink id="cell_component_1k" />(8192 ビットの容量を提供)で十分です。
* 物質特異点モードでは、コンデンサーは、その中に入れたものから[シンギュラリティ](singularities.md)を作成します。
  このモードでは、コンデンサーの上部スロットにストレージコンポーネントを配置する必要があります。  
  特異点はそれぞれ256,000個のアイテムまたはバケツを取り込むため、<ItemLink id="cell_component_64k" />(524,288 ビットの容量を提供)で十分です。

なお、何かを生産する後ろの2つのモードでは、エネルギーと出力アイテムのバッファが両方とも完全にいっぱいになると、マターコンデンサーは詰まり、それ以上の入力を受け付けなくなる*ことがあります*。

## レシピ

<RecipeFor id="condenser" />
