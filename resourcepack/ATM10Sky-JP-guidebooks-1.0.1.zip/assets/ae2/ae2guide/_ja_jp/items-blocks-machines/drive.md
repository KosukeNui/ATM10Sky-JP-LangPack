---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: MEドライブ
  icon: drive
  position: 210
categories:
- devices
item_ids:
- ae2:drive
---

# MEドライブ

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/drive.snbt" />
</GameScene>

ドライブは、[ストレージセル](storage_cells.md)を[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)に使用するために接続するための[デバイス](../ae2-mechanics/devices.md)です。  
ドライブには10個のスロットがあり、それぞれにセルが挿入されます。

何らかの理由で必要な場合は、ホッパーやAE2バスなどのアイテムロジスティクスを使用して、  
インベントリからセルをプッシュしたりプルしたりできます。

<ItemLink id="certus_quartz_wrench" />を使用して回転できます。

## セルステータスLED

ドライブのセルには、ステータスを示す LED が付いています:

| 色      | ステータス                                                                                |
| :-----  | :--------------------------------------------------------------------------------------- |
| 緑      | 空                                                                                       |
| 青      | 内容あり                                                                                  |
| オレンジ | [タイプ](../ae2-mechanics/bytes-and-types.md)がいっぱいで、新しいタイプを追加できません      |
| 赤      | [バイト](../ae2-mechanics/bytes-and-types.md)がいっぱいで、これ以上アイテムを挿入できません   |
| 黒      | 電源が入っていないか、ドライブに[チャンネル](../ae2-mechanics/channels.md)がありません        |

## 優先度

優先順位は、GUIの右上にあるレンチをクリックして設定できます。  
ネットワークに入るアイテムは、最初の宛先として、優先順位が最も高いストレージから開始されます。  
2つのストレージまたはセルの優先順位が同じ場合、一方にすでにアイテムが含まれている場合は、  
そのストレージが他のストレージよりも優先されます。  
[パーティション化された](cell_workbench.md)セルは、他のストレージと同じ優先順位グループにある場合は、すでにアイテムが含まれているものとして扱われます。  
ストレージから削除されるアイテムは、優先順位が最も低いストレージから削除されます。  
この優先順位システムでは、アイテムがネットワークストレージに挿入および削除されると、  
優先順位の高いストレージがいっぱいになり、優先順位の低いストレージが空になります。

## レシピ

<RecipeFor id="drive" />
