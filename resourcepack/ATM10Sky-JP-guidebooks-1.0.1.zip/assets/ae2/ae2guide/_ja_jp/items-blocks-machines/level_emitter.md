---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: レベルエミッター
  icon: level_emitter
  position: 220
categories:
- devices
item_ids:
- ae2:level_emitter
- ae2:energy_level_emitter
---

# レベルエミッター

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/level_emitter.snbt" />
</GameScene>

レベルエミッターは、[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)内のアイテムの量に応じてレッドストーン信号を発します。

ネットワークに保存されている[エネルギー](../ae2-mechanics/energy.md)に応じてレッドストーン信号を発するバージョンもあります。

アイテムや液体は、実際にそのアイテムを持っていなくても、JEI/REIからスロットにドラッグできます。

液体コンテナ(バケツや液体タンクなど)を右クリックして、その液体をバケツやタンクアイテムではなくフィルターとして設定します。

これらは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)です。

他の[デバイス](../ae2-mechanics/devices.md)とは異なり、レベルエミッターは[チャンネル](../ae2-mechanics/channels.md)を必要としません。

## 設定

* レベル エミッターは、「以上/等しい」または「以下」モードに設定できます
* <ItemLink id="crafting_card" />を挿入すると、「アイテムのクラフト中にレッドストーンを放出」  
  または「アイテムをクラフトしたときレッドストーンを放出」に設定できます

## アップグレード

レベルエミッターは次の[アップグレード](upgrade_cards.md)をサポートします:

* <ItemLink id="fuzzy_card" />を使用すると、エミッターはダメージレベルでフィルター処理したり、アイテムNBTを無視したりできます
* <ItemLink id="crafting_card" />を使用すると、クラフト機能が有効になります

## クラフト機能

<ItemLink id="crafting_card" />が挿入されると、エミッターはクラフトモードに切り替わります。

これにより、次の2つのオプションが有効になります:

最初のオプション「アイテムのクラフト中にレッドストーンを放出」では、  
[自動クラフト](../ae2-mechanics/autocrafting.md)が<ItemLink id="pattern_provider" />を通じて特定のアイテムをクラフトしている間、エミッターがレッドストーン信号を放出します。  
これは、実際に使用されている間だけ、特定の電力を消費する自動化設定をオンにするのに便利です。

2番目のオプション「アイテムをクラフトしたときレッドストーンを放出」は、  
無限ファームや、出力が保証されているのではなく、出力を作成する可能性しかない自動化設定などの特定の使用例に非常に便利です。
この設定は、エミッターのフィルタースロットにあるアイテムに対して、[自動クラフト](../ae2-mechanics/autocrafting.md)が使用する仮想[パターン](patterns.md)を作成します。
(正しく機能させるには、同じアイテムの実際のパターンが<ItemLink id="pattern_provider" />に**存在してはいけません**)

この「パターン」は、材料を定義したり、材料について考慮したりしません。
「このレベルのエミッターからレッドストーンを放出すると、MEシステムは近い将来または遠い将来のある時点でこのアイテムを受け取ります」とだけ書かれています。  
これは通常、入力材料を必要としない無限ファームをアクティブ化および非アクティブ化するために、  
または、たとえば「1丸石 = 2丸石」のように、丸石を複製するマシンがある場合に、  
[再帰レシピを処理するシステム](../example-setups/recursive-crafting-setup.md)(標準の自動クラフトでは理解できない)をアクティブ化するために使用されます。

## レシピ

<RecipeFor id="level_emitter" />

<RecipeFor id="energy_level_emitter" />
