---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 空間入出力ポート
  icon: spatial_io_port
  position: 210
categories:
- devices 
item_ids:
- ae2:spatial_io_port
---

# 空間入出力ポート

<BlockImage id="spatial_io_port" p:powered="true" scale="8" />

空間入出力ポートは、[空間IO](../ae2-mechanics/spatial-io.md)で[空間セル](spatial_cells.md)を保持し、空間IO操作を制御するために使用されます。

自動化する場合は、ホッパーやAE2バスなどのアイテムロジスティクスによってセルを挿入および抽出できます。

## レシピ

<RecipeFor id="spatial_io_port" />