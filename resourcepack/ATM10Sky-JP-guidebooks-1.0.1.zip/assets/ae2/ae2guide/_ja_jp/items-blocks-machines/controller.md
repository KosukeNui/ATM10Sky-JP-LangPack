---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: コントローラー
  icon: controller
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:controller
---

# コントローラー

<BlockImage id="controller" p:state="online" scale="8" />

コントローラは、[MEネットワーク](../ae2-mechanics/me-network-connections.md)のルーティングハブです。

これがないと、ネットワークは「アドホック」になり、チャンネルを使用する[デバイス](../ae2-mechanics/devices.md)は合計で最大8個しか持てません。

1つの[MEネットワーク](../ae2-mechanics/me-network-connections.md)に2つのコントローラを配置することはできません。

コントローラは、面ごとに32個の[チャンネル](../ae2-mechanics/channels.md)を提供します。

コントローラが機能するには、コントローラブロックごとに6AE/tが必要です。各コントローラブロックには8000AEを保存できるため、  
大規模なネットワークでは追加のエネルギーストレージが必要になる場合があります。  
詳細については、[エネルギー](../ae2-mechanics/energy.md)を参照してください。

マルチブロックコントローラは、かなり自由な形式で構築できます。

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controllers.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ただし、従わなければならないルールがいくつかあります:

1. [MEネットワーク](../ae2-mechanics/me-network-connections.md)上のすべてのコントローラーブロックが接続されている必要があります。そうでない場合、ブロックは赤色に変わります。
2. コントローラーのサイズは7x7x7以内である必要があります。そうでない場合、ブロックは赤色に変わります。
3. コントローラーは、最大1つの軸に2つの隣接ブロックを持つことができます。  
   ブロックがこのルールに違反すると、無効になり、赤色に変わります。

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controller_rules.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

すべてのルールに従って電源が入っている限り、コントローラーは光り、色が変わります。

コントローラーを右クリックすると、<ItemLink id="network_tool" />と同じGUIが表示されます。

## レシピ

<RecipeFor id="controller" />
