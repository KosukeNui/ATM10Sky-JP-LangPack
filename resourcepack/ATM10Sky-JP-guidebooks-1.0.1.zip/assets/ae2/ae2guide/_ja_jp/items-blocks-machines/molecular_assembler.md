---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 分子組立機
  icon: molecular_assembler
  position: 310
categories:
- machines
item_ids:
- ae2:molecular_assembler
---

# 分子組立機

<BlockImage id="molecular_assembler" scale="8" />

分子組立機は、入力されたアイテムを受け取り、隣接する<ItemLink id="pattern_provider" />、  
または挿入された<ItemLink id="crafting_pattern" />、<ItemLink id="smithing_table_pattern" />、または<ItemLink id="stonecutting_pattern" />で定義された操作を実行し、  
その結果を隣接するインベントリにプッシュします。

この分子組立機には、1本のオークの丸太 = 4本のオークの板のレシピを指定するクラフトパターンがあります。  
オークの丸太が上部ホッパーに投入されると、分子組立機はオークの板をクラフトして下部ホッパーに吐き出します。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/standalone_assembler.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 分子組立機の主な用途

ただし、主な用途は<ItemLink id="pattern_provider" />の隣です。  
パターンプロバイダーはこの場合特別な動作をし、関連するパターンに関する情報を材料とともに隣接する分子組立機に送信します。  
分子組立機はクラフトの結果を隣接するインベントリ(つまりパターンプロバイダーの戻りスロット)に自動的に排出するため、  
パターンプロバイダー上の分子組立機だけでパターンの作成を自動化できます。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## アップグレード

分子組立機は次の[アップグレード](upgrade_cards.md)をサポートしています。

*   <ItemLink id="speed_card" />

## レシピ

<RecipeFor id="molecular_assembler" />

## 注意

Optifineは「隣接するインベントリにプッシュ」機能を無効にするため、分子組立機を使用したほとんどのクラフト設定は機能しません。