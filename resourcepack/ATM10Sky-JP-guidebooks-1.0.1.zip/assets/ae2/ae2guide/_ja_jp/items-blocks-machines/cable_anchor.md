---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ケーブルアンカー
  icon: cable_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:cable_anchor
---

# ケーブルアンカー

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/cable_anchor.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ケーブルが接続されるのを防いだり、ケーブルで梯子を作ったり、ケーブルが周囲の壁に接続されているように見せたりするために使用できる、  
ケーブルに取り付けられた小さな装飾用のスパイクです。<ItemLink id="facade" />の作成にも使用されます。

ケーブルアンカーは、取り付けられている側で接続が形成されるのを防ぎます。

梯子のように登ることができます。

## レシピ

<RecipeFor id="cable_anchor" />
