---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: チャージャー
  icon: charger
  position: 310
categories:
- machines
item_ids:
- ae2:charger
---

# チャージャー

<BlockImage id="charger" scale="8" />

チャージャーは、サポートされているツールと<ItemLink id="certus_quartz_crystal" />を充電する方法を提供します。

電源は、上部または下部、AE2の[ケーブル](cables.md)、またはその他のmod電源ケーブルを介して供給できます。

AE2の電源(AE)またはForge Energy(FE)のいずれかを受け入れることができます。  
アイテムはどの側からでも搬入出できます。  
搬出できるのは結果のみなので、  
チャージ済みのケルタスクォーツではなくケルタスクォーツの水晶を搬出することを防ぐフィルターは必要ありません。  
自動化を容易にするために、<ItemLink id="certus_quartz_wrench" />を使用して回転できます。

<ItemLink id="certus_quartz_crystal" />から<ItemLink id="charged_certus_quartz_crystal" />を作成し、  
<ItemLink id="minecraft:compass" />から<ItemLink id="meteorite_compass" />を作成するために使用できます。

手動で電源を入れるには、上部または下部に<ItemLink id="crank" />を配置し、  
アイテムが充電されるまで右クリックします。

[フルーシュ研究員](fluix_researcher.md)の職業ブロックとしても機能します。

## シンプルな自動化

たとえば、回転機能により、次のように充電器を半自動化できます。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/charger_hopper.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## レシピ

<RecipeFor id="charger" />
