---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ケルタスクォーツの水晶
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# ケルタスクォーツの水晶

<ItemImage id="certus_quartz_crystal" scale="4" />

*「セルタスクォーツの水晶は、結晶マトリックスに大量のエネルギーを受け入れるというユニークな特性を持っています」*

AE2ブロック、[デバイス](../ae2-mechanics/devices.md)、およびアイテムの主要材料の1つ。  
[芽生えたケルタスクォーツ](../ae2-mechanics/certus-growth.md)から成長させて作られます。

## 代替レシピ

<Recipe id="misc/deconstruction_certus_quartz_block" />

<Recipe id="transform/certus_quartz_crystals" />
