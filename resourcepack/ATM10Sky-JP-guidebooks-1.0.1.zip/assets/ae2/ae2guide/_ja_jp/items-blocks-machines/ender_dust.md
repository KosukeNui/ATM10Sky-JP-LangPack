---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: エンダーダスト
  icon: ender_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:ender_dust
---

# エンダーダスト

<ItemImage id="ender_dust" scale="4" />

<ItemLink id="inscriber" />によって粉砕されたエンダーパール。  
<ItemLink id="wireless_booster" />および<ItemLink id="quantum_entangled_singularity" />ペアの作成に使用されます。

## レシピ

<RecipeFor id="ender_dust" />
