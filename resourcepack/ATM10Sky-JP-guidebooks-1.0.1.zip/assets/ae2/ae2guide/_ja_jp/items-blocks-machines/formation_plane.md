---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 形成プレーン
  icon: formation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:formation_plane
---

# 形成プレーン

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/formation_plane.snbt" />
</GameScene>

形成プレーンはブロックを配置し、アイテムをドロップします。  
挿入専用の<ItemLink id="storage_bus" />と同様に動作し、  
<ItemLink id="import_bus" />や<ItemLink id="interface" />などの[デバイス](../ae2-mechanics/devices.md)によって  
[ネットワーク ストレージ](../ae2-mechanics/import-export-storage.md)に挿入されたアイテムが「格納」されると、配置/ドロップが行われます。

<GameScene zoom="8" interactive={true}>
  <ImportStructure src="../assets/assemblies/formation_plane_demonstration.snbt" />
  <IsometricCamera yaw="255" pitch="30" />
</GameScene>

これらは、[パイプサブネット](../example-setups/pipe-subnet.md)の「インポートバス→ストレージバス」や「インターフェース→ストレージバス」のパイプに似ていることに注目してください。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage_pipe.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

この[デバイス](../ae2-mechanics/devices.md)は、[パイプサブネット](../example-setups/pipe-subnet.md)などのストレージバスで使用されるメカニズムを利用し、  
アイテムを転送するのではなくアイテムをドロップしたりブロックを配置したりする場合、それらのセットアップでストレージバスを置き換えることができます。

これらは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md) です。

**チャンクロードを有効にすることを忘れないでください**

## フィルタリング

デフォルトでは、プレーンは何でも配置/ドロップします。  
フィルタースロットに挿入されたアイテムはホワイトリストとして機能し、特定のアイテムのみを配置できます。

アイテムや液体は、実際にそのアイテムを持っていなくても、JEI/REIからスロットにドラッグできます。

液体コンテナ(バケツや液体タンクなど)を右クリックして、  
バケツやタンクアイテムではなく、その液体をフィルターとして設定します。

## 優先度

優先順位は、GUIの右上にあるレンチをクリックして設定できます。
ネットワークに入るアイテムは、最も優先順位の高いストレージから開始されます。

## 設定

*   プレーンは、ワールド内にブロックを配置したり、アイテムをドロップするように設定できます。

## アップグレード

形成プレーンは以下の[アップグレード](upgrade_cards.md)をサポートします:

* <ItemLink id="capacity_card" />はフィルタースロットの数を増やします
* <ItemLink id="fuzzy_card" />はプレーンがダメージレベルでフィルターしたり、アイテムNBTを無視したりできるようにします
* <ItemLink id="inverter_card" />はフィルターをホワイトリストからブラックリストに切り替えます

## レシピ

<RecipeFor id="formation_plane" />
