---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ガイド
  icon: guide
categories:
- tools
item_ids:
- ae2:guide
---

# ガイド

<ItemImage id="guide" scale="8" />

### あなたが今読んでいるこのガイドは、AE2ガイドのあらゆるニーズに応えます。

* 左側のサイドバーにアクセスして目次を見つけます
* 多くのページにはインタラクティブなシーンがあります。  
  シーンの横に![プラス](../assets/diagrams/plus.png)と![マイナス](../assets/diagrams/minus.png)(ズーム)ボタンがある場合は、カメラを回転したり移動したりできます。  
  回転するには左クリックしてドラッグし、平行移動するには右クリックしてドラッグします。

## レシピ

<RecipeFor id="guide" />
