---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: モニター
  icon: storage_monitor
  position: 210
categories:
- devices
item_ids:
- ae2:storage_monitor
- ae2:conversion_monitor
---

# モニター

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/monitors.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

モニターを使用すると、GUIを開かずに、単一のアイテムまたは流体タイプを視覚化して操作できます。

モニターは、取り付けられている[ケーブル](cables.md)の色を継承します。

モニターが床または天井にある場合は、<ItemLink id="certus_quartz_wrench" />を使用して回転できます。

これらは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)です。

# ストレージモニター

アイテムまたは液体とその数量を表示します。農場などの横に置きます...

[チャンネル](../ae2-mechanics/channels.md)は必要ありません。

キーバインド:

* アイテムを右クリックするか、液体コンテナをダブルクリックしてモニターをそのアイテム/液体に設定します。
* 何も持たずに右クリックしてモニターをクリアします。
* 何も持たずにShiftキーを押しながら右クリックしてモニターをロックします。

## レシピ

<RecipeFor id="storage_monitor" />

# 変換モニター

変換モニターはストレージモニターに似ていますが、設定されたアイテムを挿入または抽出できます。

設定されたアイテムが[自動作成可能](../ae2-mechanics/autocrafting.md)であり、ストレージにアイテムがない場合、  
アイテムを取得しようとすると、代わりに作成するアイテムの量を指定するUIが開きます。

[チャンネル](../ae2-mechanics/channels.md)が必要です。

追加のキーバインド:

* 左クリックして、設定されたアイテムのスタックを抽出するか、ストレージにアイテムがない場合はそのアイテムの作成を要求します。

* 任意のアイテムで右クリックして、そのアイテムを挿入します。

* 空の手で右クリックして、インベントリから設定されたアイテムをすべて挿入します。

## レシピ

<RecipeFor id="conversion_monitor" />
