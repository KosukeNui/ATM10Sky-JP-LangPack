---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 空間標識
  icon: spatial_pylon
  position: 210
categories:
- devices
item_ids:
- ae2:spatial_pylon
---

# 空間標識

<BlockImage id="spatial_pylon" p:powered_on="true" scale="8" />

空間標識は、[空間IO](../ae2-mechanics/spatial-io.md)で空間フィールドを生成し、影響を受けるボリュームを定義するために使用されます。

パイロンの連続ラインごとに1つの[チャンネル](../ae2-mechanics/channels.md)が使用されます。

パイロンのラインが機能するには、少なくとも2ブロックの長さが必要です。

## レシピ

<RecipeFor id="spatial_pylon" />