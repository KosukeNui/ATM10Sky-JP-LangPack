---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 刻印機
  icon: inscriber
  position: 310
categories:
- machines
item_ids:
- ae2:inscriber
---

# 刻印機

<BlockImage id="inscriber" scale="8" />

刻印機は、[プレス](presses.md)を使用して回路や[プロセッサ](processors.md)に刻印したり、さまざまなアイテムを粉砕したりするために使用されます。

刻印機は、AE2のパワー(AE)またはファブリック/フォージエネルギー(E/FE)のいずれかを受け入れることができます。  
刻印機は、異なる側からアイテムを挿入すると、インベントリの異なるスロットに挿入されるように、側面を設定できます。  
これを容易にするために、<ItemLink id="certus_quartz_wrench" />を使用して回転させることができます。

また、クラフトの結果を隣接するインベントリにプッシュするように設定することもできます。

入力バッファのサイズは調整できます。  
たとえば、1つのインベントリから刻印機の大きな配列にフィードする場合、  
バッファを小さくして、刻印機間で材料がより最適に分散されるようにします  
(最初の刻印機が64までいっぱいになり、残りが空になるのではなく)。

4つの金型は、[プロセッサ](processors.md)を作成するために使用されます

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

名前プレスは、金床と同様にブロックに名前を付けるために使用できますが、  
<ItemLink id="pattern_access_terminal" />内のものにラベルを付けるのに役立ちます。

<ItemImage id="name_press" scale="4" />

## 設定

* 刻印機は、サイド付き下記で説明）に設定することも、どのサイドからでもどのスロットにも入力できるように設定することもできます。  
  内部フィルターによって、どこに何を入れるかが決まります。  
  サイドなしモードでは、アイテムを上部と下部のスロットから取り出すことはできません。
* 刻印機は、アイテムを隣接するインベントリにプッシュするように設定できます。
* 入力バッファのサイズは調整可能です。  
  大きいオプションは、手動で入力するスタンドアロン刻印機用で、  
  小さいオプションは、大規模な並列セットアップをより実行可能にするためのものです。

## GUIと側面

サイドモードの場合、刻印機は、挿入または抽出する側によって、どこに何を入れるかをフィルタリングします。

![刻印機GUI](../assets/diagrams/inscriber_gui.png)![刻印機サイド](../assets/diagrams/inscriber_sides.png)

A. 刻印機の上部からアクセスする **上部入力** (アイテムはこのスロットにプッシュすることも、このスロットからプルすることもできます)

B. 刻印機の左側、右側、前面、および背面から挿入する **中央入力** (アイテムはこのスロットにプッシュすることしかできず、プルすることはできません)

C. 刻印機の下部からアクセスする **下部入力** (アイテムはこのスロットにプッシュすることしかできず、プルすることはできません)

D. 刻印機の左側、右側、前面、および背面からプルする **出力** (アイテムはこのスロットにプッシュすることしかできず、プルすることはできません)

## シンプルな自動化

たとえば、側面性と回転可能性により、次のように刻印機を半自動化できます。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/inscriber_hopper_automation.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

または、非サイド モードの場合は、刻印機にパイプしたり、刻印機からパイプしたりします。

## アップグレード

刻印機は次の[アップグレード](upgrade_cards.md)をサポートしています。

*   <ItemLink id="speed_card" />

## レシピ

<RecipeFor id="inscriber" />
