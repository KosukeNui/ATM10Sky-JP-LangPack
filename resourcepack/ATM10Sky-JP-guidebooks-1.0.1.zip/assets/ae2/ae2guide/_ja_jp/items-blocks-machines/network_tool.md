---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ネットワークツール
  icon: network_tool
  position: 410
categories:
- tools
item_ids:
- ae2:network_tool
---

# ネットワークツール

<ItemImage id="network_tool" scale="4" />

ネットワークツールは、ネットワーク診断情報も表示し、[アップグレードカード](upgrade_cards.md)を保存できる、修正された[レンチ](wrench.md)です。
レンチの機能をそのままに、物を素早く分解したり、ケーブルから[サブパーツ](../ae2-mechanics/cable-subparts.md)を取り外したりできますが、物を回転させることはできません。

[アップグレードカード](upgrade_cards.md)を保存するためのスロットが9つあり、ツールがインベントリのどこかにある場合は、どのAE2デバイスUIでも使用できます。

ネットワークの任意の部分を右クリックすると、<ItemLink id="controller" />を右クリックする場合と同様に、診断情報ウィンドウが表示されます。
このウィンドウには次の情報が表示されます

* ネットワークで使用中のチャネル数
* AEまたはE/FEでエネルギーを表示するグローバル設定の切り替え
* ネットワークに保存されている[エネルギー](../ae2-mechanics/energy.md)の量と、ネットワークの最大エネルギー容量
* ネットワークに入力され、ネットワークによって使用されているエネルギーの量
* ネットワーク上のすべての[デバイス](../ae2-mechanics/devices.md)とコンポーネントのリスト

このウィンドウは、[サブネットワーク](../ae2-mechanics/subnetworks.md)を操作しているときに、  
2つの異なるケーブルまたはデバイスが同じネットワークの一部であるかどうかを確認するのにも役立ちます。

## ファサードの非表示

[ファサード](facades.md)は、どちらかの手にネットワークツールを持っている間は非表示になります。

最初にファサードを削除しなくても、非表示のファサードの背後にあるブロックを操作できます。

## レシピ

<RecipeFor id="network_tool" />
