---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ターミナル
  icon: crafting_terminal
  position: 210
categories:
- devices
item_ids:
- ae2:terminal
- ae2:crafting_terminal
- ae2:pattern_encoding_terminal
- ae2:pattern_access_terminal
---

# ターミナル

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminals.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="pattern_provider" />、<ItemLink id="import_bus" />、<ItemLink id="storage_bus" />などがAE2ネットワークが世界とやり取りする主な手段であるのに対し、  
ターミナルはAE2ネットワークが *あなた* とやり取りする主な手段です。  
機能の異なるいくつかのバリエーションがあります。

ターミナルは、マウントされている[ケーブル](cables.md)の色を継承します。

これらは[ケーブルサブパーツ](../ae2-mechanics/cable-subparts.md)です。

## ターミナルの配置

ターミナルは、誰かが配置する最初の[サブパーツ](../ae2-mechanics/cable-subparts.md)であることが多いため、  
間違ってターミナルを逆向きに配置することがよくあります。  
次に、何をすべきか、何をすべきでないかの例を示します。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminal_placement.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <LineAnnotation color="#ff3333" from="2.5 .5 .5" to="4.5 2.5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="2.5 2.5 .5" to="4.5 .5 .5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="-.5 2.5 .5" to="1 .5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1 .5 .5" to="1.5 1 .5" alwaysOnTop={true} thickness="0.05"/>
</GameScene>

端末とエネルギーアクセプタはまだありますが、端末が正しい向きで実際にネットワークに接続され、  
すべてがより小さなスペースに収まるようになりました。

<a name="terminal-ui"></a>

# ターミナルの検索

検索欄には正規表現を入力できます。たとえば「gtceu:.*ore」と書くと、Gregtechの鉱石がすべて表示されます。正規表現の学習は読者への課題とします。

# ターミナル

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

基本的なターミナルです。  
[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)の内容を表示してアクセスし、  
[自動クラフト](../ae2-mechanics/autocrafting.md)セットアップからアイテムをリクエストできます。

## UI

基本的なターミナルのUIにはいくつかのセクションがあります

中央のセクションからネットワークのストレージにアクセスできます。  
アイテムを入れたり取り出したりできます。  
マウス/キーのショートカットがいくつかあります:

* 左クリックでスタックをつかみ、右クリックでスタックの半分をつかみます。
* アイテムや流体などが[自動クラフト](../ae2-mechanics/autocrafting.md)可能な場合、  
  "ブロックを選択"(通常は中クリック)にバインドしたものは何でも、クラフトする量を指定するUIが表示されます。  
  また、`3*64/2`のような数式を入力するか、`=32` と入力して、ストレージの32に達するために必要なアイテムの数だけを作成することもできます。
* Shiftキーを押したままにすると、表示されているアイテムがその場で固定され、数量が変更されたり、  
  新しいアイテムがシステムに入ったりしても、アイテムが再編成されなくなります。
* バケツやその他の液体コンテナで右クリックすると液体が投入され、  
  空の液体コンテナでターミナル内の液体を左クリックすると液体が取り出されます。

左側のセクションには、次の設定ボタンがあります:

* 名前、mod、数量などのさまざまな属性で並べ替える
* 保存済み、作成可能、またはその両方を表示する
* アイテム、流体、またはその両方を表示する
* 並べ替え順序を変更する
* 詳細なターミナル設定ウィンドウを開く
* ターミナル UI の高さを変更する

右側には<ItemLink id="view_cell" />用のスロットがあります

中央セクションの右上(ハンマーボタン)をクリックすると、  
[自動作成](../ae2-mechanics/autocrafting.md)ステータスUIが表示され、自動作成の進行状況と各[クラフトCPU](crafting_cpu_multiblock.md)の動作を確認できます。

## レシピ

<RecipeFor id="terminal" />

<a name="crafting-terminal-ui"></a>

# クラフトターミナル

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/crafting_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

クラフトターミナルは通常のターミナルと似ており、設定やセクションはすべて同じですが、  
クラフトグリッドが追加されており、[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)から自動的に補充されます。  
出力をShiftキーを押しながらクリックするときは注意してください。

ターミナルをクラフトターミナルに早急にアップグレードしてください。

## UI

クラフトターミナルは通常のターミナルと同じUIですが、中央にクラフトグリッドが追加されています。

クラフトグリッドをネットワークストレージまたはインベントリに空にするためのボタンが2つ追加されています。

## レシピ

<RecipeFor id="crafting_terminal" />

<a name="pattern-encoding-terminal-ui"></a>

# パターンエンコーディングターミナル

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_encoding_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

パターンエンコーディングターミナルは通常のターミナルに似ており、設定やセクションはすべて同じですが、  
[パターン](patterns.md)エンコーディングインターフェイスが追加されています。  
クラフトターミナルのUIに似ていますが、このクラフトグリッドは実際にはクラフトを実行しません。

クラフトターミナルに加えて、このターミナルのいずれかが必要です。

## UI

クラフトターミナルは通常のターミナルと同じUIを持ち、[パターン](patterns.md)エンコーディングインターフェイスが追加されています。

パターンエンコーディングインターフェイスには、いくつかのセクションがあります:

<ItemLink id="blank_pattern" />を挿入するスロット。

パターンをエンコードする大きな矢印。

エンコードされたパターン用のスロット。  
編集するには、すでにエンコードされているパターンをこのスロットに配置してから、[エンコード]矢印をクリックします。

右側の4つのタブで、エンコードするパターンの種類を切り替えます

* クラフト
* 加工
* 鍛冶
* 石切り

中央のUIは、エンコードするパターンの種類に応じて変わります。

* クラフトモードの場合:
  * レシピを作成する材料をJEI/REIから左クリックまたはドラッグします。材料を削除するには右クリックします。
  * 代替を有効にすると、任意の種類の板から棒を作成するなどのことが可能になります。これは絶対に必要な場合にのみ使用してください。
  * 液体代替により、液体のバケツの代わりに保存されている液体を使用できます。
  * JEI/REIレシピ画面からパターンを直接エンコードすることもできます。

* 処理モードの場合:
  * レシピの入力と出力を指定するには、材料をJEI/REIから左クリックまたは右クリックまたはドラッグします。
  * 液体コンテナ(バケツや液体タンクなど)を右クリックして、バケツやタンクのアイテムではなく、その液体を材料として設定します。
  * スタックを保持している場合、左クリックでスタック全体を配置し、右クリックで1つのアイテムを配置します。  
    既存の材料スタックを左クリックするとスタック全体が削除され、右クリックするとスタックが 1 ずつ減ります。  
    「ブロックを選択」にバインドしたもの(通常は中クリック)を使用すると、アイテムまたは流体の正確な量を指定できます。
  * 出力スロットには、プライマリ出力と、自動クラフト アルゴリズムに知らせたいセカンダリ出力用のスペースがあります。
  * 入力スロットと出力スロットは両方ともスクロールするため、81種類の材料と26種類のセカンダリ出力を使用できます。
  * JEI/REIレシピ画面からパターンを直接エンコードすることもできます。

* 鍛冶と石切りモードのUIは、それぞれ鍛冶台と石切り機と同様に機能します。

## レシピ

<RecipeFor id="pattern_encoding_terminal" />

<a name="pattern-access-terminal-ui"></a>

# パターンアクセスターミナル

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_access_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

パターンアクセスターミナルは、特定の問題を解決するために役立ちます。  
<ItemLink id="pattern_provider" />と<ItemLink id="molecular_assembler" />の密集したタワーでは、  
プロバイダーに物理的にアクセスして新しいパターンを挿入することはできません。  
さらに、おそらくあなたは怠け者で、拠点を横断して[パターン](patterns.md)を挿入したくないでしょう。  
パターンアクセスターミナルは、ネットワーク上のすべてのパターンプロバイダーへのアクセスを許可します。

## UI

このターミナルは、他のすべてのターミナルとは異なるUIを持っています。

ターミナルの高さと表示するパターンプロバイダーの設定があります。

ターミナルの各行は、特定のパターンプロバイダーに対応しています。

ターミナル内のパターンプロバイダーは、接続されているブロック、  
または(金床または<ItemLink id="name_press" />を使用して)指定した名前で並べ替えられます。

## レシピ

<RecipeFor id="pattern_access_terminal" />
