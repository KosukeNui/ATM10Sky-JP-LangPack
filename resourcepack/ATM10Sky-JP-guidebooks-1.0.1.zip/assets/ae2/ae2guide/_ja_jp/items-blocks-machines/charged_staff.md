---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: チャージ済みのスタッフ
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# チャージ済みのスタッフ

<ItemImage id="charged_staff" scale="4" />

チャージ済みのスタッフは、先端に<ItemLink id="charged_certus_quartz_crystal" />が付いた棒です。  
攻撃ごとに 300 AE を消費し、6 ダメージを与えます。

エネルギーは<ItemLink id="charger" />で再チャージできます。

## レシピ

<RecipeFor id="charged_staff" />
