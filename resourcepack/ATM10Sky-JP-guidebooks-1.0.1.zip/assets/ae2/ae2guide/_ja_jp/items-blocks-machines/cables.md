---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ケーブル
  icon: fluix_glass_cable
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:white_glass_cable
- ae2:orange_glass_cable
- ae2:magenta_glass_cable
- ae2:light_blue_glass_cable
- ae2:yellow_glass_cable
- ae2:lime_glass_cable
- ae2:pink_glass_cable
- ae2:gray_glass_cable
- ae2:light_gray_glass_cable
- ae2:cyan_glass_cable
- ae2:purple_glass_cable
- ae2:blue_glass_cable
- ae2:brown_glass_cable
- ae2:green_glass_cable
- ae2:red_glass_cable
- ae2:black_glass_cable
- ae2:fluix_glass_cable
- ae2:white_covered_cable
- ae2:orange_covered_cable
- ae2:magenta_covered_cable
- ae2:light_blue_covered_cable
- ae2:yellow_covered_cable
- ae2:lime_covered_cable
- ae2:pink_covered_cable
- ae2:gray_covered_cable
- ae2:light_gray_covered_cable
- ae2:cyan_covered_cable
- ae2:purple_covered_cable
- ae2:blue_covered_cable
- ae2:brown_covered_cable
- ae2:green_covered_cable
- ae2:red_covered_cable
- ae2:black_covered_cable
- ae2:fluix_covered_cable
- ae2:white_covered_dense_cable
- ae2:orange_covered_dense_cable
- ae2:magenta_covered_dense_cable
- ae2:light_blue_covered_dense_cable
- ae2:yellow_covered_dense_cable
- ae2:lime_covered_dense_cable
- ae2:pink_covered_dense_cable
- ae2:gray_covered_dense_cable
- ae2:light_gray_covered_dense_cable
- ae2:cyan_covered_dense_cable
- ae2:purple_covered_dense_cable
- ae2:blue_covered_dense_cable
- ae2:brown_covered_dense_cable
- ae2:green_covered_dense_cable
- ae2:red_covered_dense_cable
- ae2:black_covered_dense_cable
- ae2:fluix_covered_dense_cable
- ae2:white_smart_cable
- ae2:orange_smart_cable
- ae2:magenta_smart_cable
- ae2:light_blue_smart_cable
- ae2:yellow_smart_cable
- ae2:lime_smart_cable
- ae2:pink_smart_cable
- ae2:gray_smart_cable
- ae2:light_gray_smart_cable
- ae2:cyan_smart_cable
- ae2:purple_smart_cable
- ae2:blue_smart_cable
- ae2:brown_smart_cable
- ae2:green_smart_cable
- ae2:red_smart_cable
- ae2:black_smart_cable
- ae2:fluix_smart_cable
- ae2:white_smart_dense_cable
- ae2:orange_smart_dense_cable
- ae2:magenta_smart_dense_cable
- ae2:light_blue_smart_dense_cable
- ae2:yellow_smart_dense_cable
- ae2:lime_smart_dense_cable
- ae2:pink_smart_dense_cable
- ae2:gray_smart_dense_cable
- ae2:light_gray_smart_dense_cable
- ae2:cyan_smart_dense_cable
- ae2:purple_smart_dense_cable
- ae2:blue_smart_dense_cable
- ae2:brown_smart_dense_cable
- ae2:green_smart_dense_cable
- ae2:red_smart_dense_cable
- ae2:black_smart_dense_cable
- ae2:fluix_smart_dense_cable
---

# ケーブル

<GameScene zoom="3" background="transparent">
  <ImportStructure src="../assets/assemblies/cables.snbt" />
  <IsometricCamera yaw="180" pitch="30" />
</GameScene>

MEネットワークは隣接するME対応マシンによっても作成されますが、  
ケーブルはMEネットワークをより広い範囲に拡張する主な方法です。

異なる色のケーブルを使用すると、隣接するケーブルが互いに接続されないようにすることができ、  
[チャンネル](../ae2-mechanics/channels.md)をより効率的に分散できます。  
また、接続されている端末の色にも影響するため、すべての端末を紫色にする必要はありません。  
フルーシュケーブルは他のすべての色に接続します。

なお、**チャンネルはケーブルの色とはまったく関係ありません**

## 重要なメモ

**AE2を初めて使用し、チャンネルに詳しくない場合は、できる限りスマートケーブルと高密度スマートケーブルを使用してください。**  
**これにより、チャンネルがネットワーク内でどのようにルーティングされるかが表示され、チャンネルの動作がより理解しやすくなります。**

## もう一つのメモ

**これらはアイテムや流体、エネルギーなどのパイプではありません。**  
内部インベントリはなく、パターンプロバイダーやマシンはパイプに「搬出」しません。  
AE2[デバイス](../ae2-mechanics/devices.md)をネットワークに接続するだけです。

## ガラスケーブル

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/fluix_glass_cable.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="fluix_glass_cable" />は最も簡単に作れるケーブルで、電力と最大8つの[チャンネル](../ae2-mechanics/channels.md)を転送します。  
17色が用意されており、デフォルトはフルーシュで、16色の​​染料のいずれかを使用して任意の色に染めることができます。

色付きケーブルを作成するには、任意のタイプの染料を同じタイプの8本のケーブルで囲みます  
(ケーブルの色は重要ではありませんが、ガラス、スマートなど、同じタイプである必要があります)。  
また、世界中のForge対応ペイントブラシを使用してケーブルをペイントすることもできます。

水バケツを使用して任意の色付きケーブルの染料を取り除くことができます。

ケーブルをウールで覆って<ItemLink id="fluix_covered_cable" />を作成し、<ItemLink id="fluix_smart_cable" />を作成して、  
[チャンネル](../ae2-mechanics/channels.md) で何が起こっているかをよりよく把握することができます。

<RecipeFor id="fluix_glass_cable" />

<RecipeFor id="blue_glass_cable" />

## カバーケーブル

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

カバー付きケーブルのバリエーションは、<ItemLink id="fluix_glass_cable" />の同等品と比べてゲームプレイ上の利点はありません。  
ただし、カバー付きの外観が好みであれば、代替の美的選択肢として使用できます。

<ItemLink id="fluix_glass_cable" />と同じ方法で色付けできます。  
4つの<ItemLink id="fluix_covered_cable" />をレッドストーンとグロウストーンで作成して、<ItemLink id="fluix_covered_dense_cable" />を作成できます。

<Recipe id="network/cables/covered_fluix" />

<RecipeFor id="blue_covered_cable" />

## 高密度ケーブル

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

大容量ケーブルは、8チャンネルしか伝送できない標準ケーブルとは異なり、32チャンネルを伝送できます。  
ただし、バスはサポートされていないため、バスまたはパネルを使用する前に、まず高密度ケーブルからより小さなケーブル  
(<ItemLink id="fluix_glass_cable" />または<ItemLink id="fluix_smart_cable" />など)にダウングレードする必要があります。

高密度ケーブルはチャンネルの「最短パス」動作をわずかにオーバーライドします。  
チャンネルは高密度ケーブルへの最短パスを取り、次にその高密度ケーブルを介してコントローラへの最短パスを取ります。

<Recipe id="network/cables/dense_covered_fluix" />

<RecipeFor id="blue_covered_dense_cable" />

## スマートケーブル

<Row>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
</Row>

外観は<ItemLink id="fluix_covered_cable" />と似ていますが、ケーブル上のチャンネル使用状況を視覚化することで診断機能を提供します。  
チャンネルはケーブル上の黒いストライプに沿って点灯した色の線として表示され、  
ネットワーク上でチャンネルがどのように使用されているかを把握できます。  
通常のスマートケーブルの場合、最初の4つのチャンネルはケーブルの色と同じ線として表示され、  
次の4つのチャンネルは白い線として表示されます。  
高密度スマートケーブルの場合、各ストライプは4つのチャンネルを表します。

<ItemLink id="controller" />があるネットワークでは、ケーブル上の線はチャンネルがたどる正確なパスを示します。

アドホックネットワーク上のスマートケーブルでは、特定のケーブルを通過するチャンネル数ではなく、  
ネットワーク全体で使用されているチャンネル数が表示されます。

これらは<ItemLink id="fluix_glass_cable" />と同じ方法で色分けすることもできます。

<Recipe id="network/cables/smart_fluix" />

<Recipe id="network/cables/dense_smart_fluix" />

<RecipeFor id="blue_smart_cable" />
