---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: クラフトCPU
  icon: 1k_crafting_storage
  position: 210
categories:
- devices
item_ids:
- ae2:1k_crafting_storage
- ae2:4k_crafting_storage
- ae2:16k_crafting_storage
- ae2:64k_crafting_storage
- ae2:256k_crafting_storage
- ae2:crafting_accelerator
- ae2:crafting_monitor
- ae2:crafting_unit
---

# クラフトCPU

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="crafting_accelerator" scale="4" />

  <BlockImage id="crafting_monitor" scale="4" />

  <BlockImage id="crafting_unit" scale="4" />
</Row>

クラフトCPUはクラフトリクエスト/ジョブを管理します。  
複数のステップを含むクラフトジョブの実行中に中間材料を保存し、ジョブの大きさや、ある程度は完了までの時間に影響します。  
詳細については、[自動クラフト](../ae2-mechanics/autocrafting.md) を参照してください。

各クラフトCPUは1つのリクエストまたはジョブを処理するため、  
計算プロセッサと256個のスムーズストーンの両方を同時に要求する場合は、2つのCPUマルチブロックが必要です。

これらは、プレイヤー、オートメーション(エクスポートバスとインターフェイス)、  
またはその両方からのリクエストを処理するように設定できます。

1つを右クリックすると、クラフトステータスUIが表示され、CPUが処理しているクラフトジョブの進行状況を確認できます。

## 設定

*   CPUは、プレイヤーからのリクエストのみ、自動化からのリクエストのみ(<ItemLink id="export_bus" />と<ItemLink id="crafting_card" />など)、  
    またはその両方を受け入れるように設定できます。

## 構成

クラフトCPUはマルチブロックで、隙間のない直方体でなければなりません。複数のコンポーネントから構成されています。

各CPUには少なくとも1つのクラフトストレージブロックが含まれている必要があります(実際、最小のCPUは1kクラフトストレージ1つだけです)。

# クラフティングユニット

<BlockImage id="crafting_unit" scale="4" />

(任意)ユニットの作成は、他のコンポーネントが足りない場合に、CPU内のスペースを埋めて直方体を作るだけです。  
ユニットは他のコンポーネントの基本材料でもあります。

<RecipeFor id="crafting_unit" />

# クラフティングストレージ

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="4k_crafting_storage" scale="4" />

  <BlockImage id="16k_crafting_storage" scale="4" />

  <BlockImage id="64k_crafting_storage" scale="4" />

  <BlockImage id="256k_crafting_storage" scale="4" />
</Row>

(必須)クラフトストレージは、すべての標準セルサイズ(1k、4k、16k、64k、256k)で利用できます。  
クラフトに関係する材料と中間材料を保管するため、CPUがより多くの材料を使用するクラフトジョブを処理するには、  
より大きなストレージまたはより多くのストレージが必要です。

<Column>
  <Row>
    <RecipeFor id="1k_crafting_storage" />

    <RecipeFor id="4k_crafting_storage" />

    <RecipeFor id="16k_crafting_storage" />
  </Row>

  <Row>
    <RecipeFor id="64k_crafting_storage" />

    <RecipeFor id="256k_crafting_storage" />
  </Row>
</Column>

# 並列クラフトユニット

<BlockImage id="crafting_accelerator" scale="4" />

(任意)クラフトコプロセッサは、CPUの処理を速くすることで、システムが<ItemLink id="pattern_provider" />からより頻繁に原料バッチを送信するようにします。
これにより、処理速度が速いマシンに追いつくことができます。  
この例としては、<ItemLink id="molecular_assembler" />に囲まれたパターンプロバイダが、  
単一のアセンブラが処理できるよりも速く原料をプッシュし、周囲のアセンブラ間で原料バッチを分配できることが挙げられます。

複雑なレシピの中には、本棚を作るために板材と本を同時に作るように、並行して進められる工程を複数持つものがあります。クラフト状況の画面（CPUを右クリックするか、[ターミナル](terminals.md)のハンマーのアイコンで表示）では、これらの工程はすべて「予定」と表示されます。コプロセッサが1つ増えるごとに、こうした工程をもう1つ並行して進められます（そして「クラフト中」と表示されます）。ただし、挿入速度のためだけでも、並行できそうな工程の数より多くのコプロセッサを置くのが普通なので、この点はあまり重要ではありません。

<RecipeFor id="crafting_accelerator" />

# クラフトモニター

<BlockImage id="crafting_monitor" scale="4" />

(任意)クラフトモニターには、CPUが現在処理しているジョブが表示されます。
画面は<ItemLink id="color_applicator" />で色付けできます。

<RecipeFor id="crafting_monitor" />
