---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME入出力ポート
  icon: io_port
  position: 210
categories:
- devices
item_ids:
- ae2:io_port
---

# ME入出力ポート

<BlockImage id="io_port" p:powered="true" scale="8" />

入出力ポートを使用すると、  
[ストレージセル](../items-blocks-machines/storage_cells.md)を[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)にすばやく充填したり、空にしたりできます。

<ItemLink id="certus_quartz_wrench" /> を使用して回転できます。

## 設定

* 入出力ポートは、セルが空、満杯、または作業が完了したときにセルを出力スロットに移動するように設定できます。
* <ItemLink id="redstone_card" />が挿入されている場合は、さまざまなレッドストーン条件のオプションが表示されます
* GUIの中央には、アイテムをセルから[ネットワークストレージ](../ae2-mechanics/import-export-storage.md)へ、  
  またはストレージからセルへ転送する方向を設定する矢印があります。

## アップグレード

入出力ポートは、次の[アップグレード](upgrade_cards.md)をサポートします:

* <ItemLink id="speed_card" />は、操作ごとに移動する物の量を増やします
* <ItemLink id="redstone_card" />は、レッドストーン制御を追加し、高信号、低信号、またはパルスごとに1回アクティブにできるようにします

## レシピ

<RecipeFor id="io_port" />
