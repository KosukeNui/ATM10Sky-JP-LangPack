---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: パターン
  icon: crafting_pattern
  position: 410
categories:
- tools
item_ids:
- ae2:blank_pattern
- ae2:crafting_pattern
- ae2:processing_pattern
- ae2:smithing_table_pattern
- ae2:stonecutting_pattern
---

# パターン

<ItemImage id="crafting_pattern" scale="4" />

パターンは、<ItemLink id="pattern_encoding_terminal" />で空のパターンから作成され、  
<ItemLink id="pattern_provider" />または<ItemLink id="molecular_assembler" />に挿入されます。

さまざまな用途に、いくつかの異なるタイプのパターンがあります:

* <ItemLink id="crafting_pattern" /> は、クラフトテーブルで作成されたレシピをエンコードします。  
  <ItemLink id="molecular_assembler" />に直接配置して、材料が与えられたときにいつでも結果を作成するようにできますが、  
  主な用途は、分子組立機の横にある<ItemLink id="pattern_provider" />です。
  この場合、パターンプロバイダーは特別な動作をし、関連するパターンを材料とともに隣接する分子組立機に送信します。  
  分子組立機はクラフトの結果を隣接するインベントリに自動的に排出するため、  
  パターンプロバイダー上の分子組立機だけでパターンの作成を自動化できます。

***

*   <ItemLink id="smithing_table_pattern" />はクラフトパターンと非常に似ていますが、鍛冶台のレシピをエンコードします。  
    パターンプロバイダーと分子組立機によって自動化されており、まったく同じように機能します。  
    実際、クラフト、鍛冶、石切りのパターンを同じセットアップで使用できます。

***

*   <ItemLink id="stonecutting_pattern" />はクラフトパターンと非常に似ていますが、石切り職人のレシピをエンコードします。  
    パターンプロバイダーと分子組立機によって自動化され、まったく同じように機能します。  
    実際、クラフト、鍛冶、石切りのパターンを同じセットアップで使用できます。

***

*   <ItemLink id="processing_pattern" /> は、オートクラフトの柔軟性の源です。  
    これらは最も汎用化されたタイプで、単に  
    「パターンプロバイダーがこれらの材料を隣接するインベントリにプッシュすると、  
    MEシステムは近い将来または遠い将来のある時点でこれらのアイテムを受け取ります」  
    と説明しています。  
    これらは、ほぼすべての改造マシンや炉などでオートクラフトを行う方法です。  
    これらは非常に汎用的に使用され、材料のプッシュから結果の受け取りまでの間に何が起こるかを気にしないため、  
    材料を複雑な工場生産チェーン全体に入力して、材料を分類し、無限に生産する農場から他の材料を取り込み、  
    Bee Movieスクリプト全体を印刷するなど、非常にファンキーなことができます。  
    パターンで指定された結果が得られる限り、MEシステムは気にしません。  
    実際、材料が結果に何らかの形で関連しているかどうかさえ気にしません。  
    「チェリー材の板1枚 = ネザースター1個」と指定して、  
    チェリー材の板を受け取ったらウィザーファームでウィザーを倒すようにすれば、うまくいきます。

同じパターンを持つ複数の<ItemLink id="pattern_provider" />がサポートされており、並行して動作します。  
さらに、パターンを、たとえば1つの丸石 = 1つの石ではなく  
8つの丸石 = 8つの石のように指定すると、パターンプロバイダーは、一度に1つではなく、  
操作ごとに 8 つの丸石を精錬セットアップに挿入します。

## レシピ

<RecipeFor id="blank_pattern" />
