---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 成長加速器
  icon: growth_accelerator
  position: 310
categories:
- machines
item_ids:
- ae2:growth_accelerator
---

# 成長加速器

<BlockImage id="growth_accelerator" p:powered="true" scale="8"/>

成長加速器は、芽生えブロックの隣に置くと、ケルタスまたはアメジストの[成長](../ae2-mechanics/certus-growth.md)を大幅に促進します。

興味深いことに、さまざまな植物の成長も促進できます。

これは、自然に起きるランダムティックに加えて、隣接するブロックに「ランダムティック」を与えることで行われます。
理論上、加速器1台でものが通常の約90倍の速さで育つはずで、効果は足し算で重なります。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/growth_accelerator.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

電力は、上面か下面から、AE2の[ケーブル](cables.md)またはほかのMODの電力ケーブルで供給できます。AE2の電力（AE）とForge Energy（FE）のどちらも受け付けます。

手動で電源を入れるには、上部または下部に<ItemLink id="crank" />を配置して右クリックします。

上面と下面は、ピンク色のフルーシュの装飾で見分けられます。

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/accelerator_connections.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## レシピ

<RecipeFor id="growth_accelerator" />
