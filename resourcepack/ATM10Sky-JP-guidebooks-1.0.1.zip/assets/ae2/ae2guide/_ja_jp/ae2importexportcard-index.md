---
navigation:
  title: "アドオン：AE2 インポート／エクスポートカード"
  icon: ae2importexportcard:export_card
  position: 150
categories:
  - tools
item_ids:
- ae2importexportcard:export_card
- ae2importexportcard:import_card
---

# AE2 インポート／エクスポートカード

<Row>
  <ItemImage id="ae2importexportcard:export_card" scale="2" />
  <ItemImage id="ae2importexportcard:import_card" scale="2" />
</Row>

インポートカードおよびエクスポートカードを使用すると、  
インベントリ内のアイテムをMEシステムに出し入れできます。

## インポートカード

<ItemImage id="ae2importexportcard:import_card" scale="2" />

インポートカードは、インベントリ内の特定スロットに入っているアイテムを、  
MEシステムへ転送します。

![Import Card](diagrams/import_card.png)

スロットをクリックするとチェックマークが付きます。  
チェックマークが付いたスロット内のアイテムは、MEシステムにインポートされます。  

上部のスロットにインベントリからアイテムをドラッグすることで、  
フィルター内容を変更できます。

### アップグレード

インポートカードは、以下の[アップグレード](items-blocks-machines/upgrade_cards.md)に対応しています。

* <ItemLink id="fuzzy_card" />：耐久値でのフィルター、またはNBTを無視
* <ItemLink id="inverter_card" />：フィルターをホワイトリストからブラックリストに切り替え

### レシピ

<RecipeFor id="ae2importexportcard:import_card" />

## エクスポートカード

<ItemImage id="ae2importexportcard:export_card" scale="2" />

エクスポートカードは、動作はインポートカードと同様ですが、  
MEシステムからインベントリへアイテムを取り出します。

![Export Card](diagrams/export_card.png)

対象アイテムを指定するには、  
インベントリからアイテムを上部スロットにドラッグし、  
インベントリ側のスロットをクリックして数量を設定します。  

右クリックすると、設定はXにリセットされます。

### アップグレード

エクスポートカードは、以下の[アップグレード](items-blocks-machines/upgrade_cards.md)に対応しています。

* <ItemLink id="fuzzy_card" />：耐久値でのフィルター、またはNBTを無視
* <ItemLink id="speed_card" />：転送速度を1個から1スタック分に向上
* <ItemLink id="crafting_card" />：在庫が不足している場合、自動で要求・クラフト

### レシピ

<RecipeFor id="ae2importexportcard:export_card" />
