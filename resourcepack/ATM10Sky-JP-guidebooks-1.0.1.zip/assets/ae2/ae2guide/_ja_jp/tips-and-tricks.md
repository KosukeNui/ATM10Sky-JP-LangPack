---
navigation:
  title: ヒントとコツ
  position: 20
---

# ヒントとコツ

ランダムな小さなおすすめがたくさん

* Optifineは外しましょう
* ズームボタンと注釈の非表示/表示ボタンがあるガイドブックの画像は回転したりズームしたりできます
* ネットワークは木構造を保ち、ループを作らないように意識しましょう
* [チャンネル](ae2-mechanics/channels.md)がネットワークを介してルーティングされる方法を深く理解していない限り、  
  8個以下のグループで[デバイス](ae2-mechanics/devices.md)でネットワークを構成しましょう
* すべての[パターン](items-blocks-machines/patterns.md)に使用する木材は1種類にしましょう。
  パターンの置換を有効にするとうまくいく場合もありますが、どこでも同じ木材を使用すると手間が大幅に軽減されます。
* [パターン](items-blocks-machines/patterns.md)を<ItemLink id="pattern_access_terminal" />に垂直に配置し、  
  [プロバイダ](items-blocks-machines/pattern_provider.md)間でパターンを分散します。レシピは並行して実行できます。
* [エナジーセル](items-blocks-machines/energy_cells.md)を追加して、ネットワークが電力不足に陥らないようにしましょう。
* <ItemLink id="condenser" />では水を使用できます。
* ネットワークをクリーンに保つ最善の方法は、剣や鎧などのランダムな敵Mobの戦利品を入れないことです。
  エンチャントと耐久性の固有の組み合わせはそれぞれ別の[タイプ](ae2-mechanics/bytes-and-types.md)です。
* <ItemLink id="import_bus" />、<ItemLink id="interface" />などを介して、[処理パターン](items-blocks-machines/patterns.md)の結果を返すときに、  
  「アイテムがシステムに入る」イベントが発生する必要があります。  
  または<ItemLink id="pattern_provider" />のリターンスロットを使用する場合、  
  <ItemLink id="storage_bus" />が含まれるチェストに結果をパイプすることはできません。
* ズームボタンと注釈の非表示/表示ボタンがあるガイドブックの画像を回転したりズームしたりできることを忘れないでください
* <ItemLink id="pattern_provider" />は、片面のみで完全なレシピバッチのみをプッシュします。  
  これは、マシンが部分的なバッチを取得しないようにするのに役立ちますが、材料を複数の場所に送りたい場合もあります。  
  これは、<ItemLink id="interface" />を["パイプ"サブネット](example-setups/pipe-subnet.md)として使用するか、  
  一種の中間チェスト/タンクとして使用し、複数の異なるアイテムスタック、液体、化学薬品を保持する機能を使用して実現できます。
* ズームボタンと注釈の非表示/表示ボタンがあるガイドブックの画像をズームしたり回転したりできます