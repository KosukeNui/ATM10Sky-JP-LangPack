---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 空間IO
  icon: spatial_storage_cell_2
---

# 空間IO

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/spatial_storage_1x1x1.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="2 2 2">
        移動するボリューム
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />

</GameScene>

空間IOは、ワールド内の空間の物理ボリュームをカット&ペーストする方法です。  
<ItemLink id="flawless_budding_quartz" />を移動したり、  
拠点内にさまざまなインテリアを交換してさまざまな目的に使用できる部屋を用意したり、  
エンド ポータルを移動したりするために使用できます。

これは、定義されたボリュームを空間ストレージディメンション内の同じサイズのボリュームと「交換」し、  
pylon アレイ内のすべてのものを空間ストレージディメンションに送信し、ディメンション内のすべてのものを pylon アレイに送信することによって機能します。

これは、次元間を移動する方法がある場合  
(空間IOを使用してテレポーターを作成できますが、それを行うのは非常に複雑で、少し不安定で、ガイドの範囲を超えています)、  
カスタムサイズのコンパクトマシンまたはポケットサイズように使用できることを意味します。。

# マルチブロックセットアップ

空間IOが機能し、カット&ペーストするボリュームを定義するには、コンポーネントの特定の配置が必要です。

機能するには、すべてのコンポーネントが同じ[ネットワーク](me-network-connections.md)上に存在する必要があり、  
ネットワーク上で空間IOセットアップを行えるのは1つだけです。  
したがって、[サブネットワーク](subnetworks.md)が推奨されます。

## 空間IOポート

<BlockImage id="spatial_io_port" p:powered="true" scale="4" />

<ItemLink id="spatial_io_port" />は空間IO操作を制御します。  
マルチブロック設定の統計を表示し、[空間セル](../items-blocks-machines/spatial_cells.md)を保持します。

空間IOポートは下記の情報を表示します
- ネットワークに保存されている最大[エネルギー](energy.md)
- 操作を実行するために必要なエネルギー。  
  これは非常に大きくなる可能性があり、瞬時に使用されるため、  
  すべてを保持するのに十分な[エナジーセル](../items-blocks-machines/energy_cells.md)があることを確認してください。
- パイロンアレイの効率
- 定義されたボリュームのサイズ

空間IO操作を実行するには、空間ストレージセルを入力スロットに配置し、空間IOポートにレッドストーンパルスを与えます。  
次に、パイロンの容積と空間ストレージ次元の容積を *交換*します。  
これは、あるブロックのセットを空間ストレージディメンションに送信し、  
*次に別のブロックのセットをパイロンに配置*し、セルを入力スロットに戻し、IOポートを再度トリガーすると、  
2番目のブロックのセットが消えると、最初のブロックが再び表示されます。

**注意してください。定義されたボリューム内のすべてのエンティティ(あなたを含む)が運ばれ、**  
**脱出する方法がない場合は閉じ込められます。**  
**空間保管次元の、暗くて特徴のない箱の中にあります。** これを使って友達にいたずらしましょう!

## パイロン

<BlockImage id="spatial_pylon" p:powered_on="true" scale="4" />

<ItemLink id="spatial_pylon" />は空間IOセットアップの主要部分であり、影響を受けるボリュームを定義します。

ボリュームは、パイロンの外側の境界ボックスによって定義され、全方向に 1 ブロックずつ縮小されます。

ルールは次のとおりです。
- 最小サイズ 3x3x3 (1x1x1 ボリュームを定義)
- すべての空間パイロンは外側の境界ボックス内にある必要があります
- すべての空間パイロンは同じネットワーク上にある必要があります
- すべてのパイロンは少なくとも2ブロックの長さでなければなりません

たとえば、3x3x3 ボリュームを定義するとします。  
ルール2に従って、すべてのパイロンは、定義するボリュームの周囲の 5x5x5 シェル内になければなりません。  
1ブロックの厚さの 5x5x5 のシェル内に収まる限り、ほぼすべての構成にすることができます。

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/spatial_storage_3x3x3_pylon_demonstration.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        移動するボリューム
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

より合理的な設定は次のとおりです:

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/better_spatial_storage_3x3x3.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        移動するボリューム
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 効率

パイロンアレイの効率は、充填するシェルの量によって異なります。  
大容量の最小限のセットアップは非常に非効率であり、おそらく「数十億」のAEが必要になります。

## セルの寸法

[空間セル](../items-blocks-machines/spatial_cells.md) が使用されると、  
永続的に定義された XYZ 次元のセット(例: 3x4x2)が得られ、空間ストレージ内のスペースのボリュームにリンクされます。  
**使用後の空間セルをリセット、再フォーマット、またはサイズ変更することはできません。**  
別のディメンションを使用する場合は、新しいセルを作成します。

これらはセル名における同じ寸法ではありません。16^3 セルは *最大* 16x16x16 の寸法を持つことができます。

このボリュームには方向性があり、回転できないことに注意してください。  
2x2x3 ボリュームは、同じサイズであっても 3x2x2 ボリュームと同じではありません。

セルの XYZ 寸法が定義されたボリューム(IOポートに表示される)と一致しない場合、IO ポートは動作しません。