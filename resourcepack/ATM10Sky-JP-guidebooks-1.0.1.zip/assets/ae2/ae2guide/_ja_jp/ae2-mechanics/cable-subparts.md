---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: ケーブルサブパーツ
icon: fluix_glass_cable
---

# ケーブルサブパーツ

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/subparts_demonstration.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

AE2では、特定の[デバイス](devices.md)とコンポーネントを同じブロック内のケーブルに配置できます。  
これはコンパクトなセットアップに役立ちます。  
<ItemLink id="certus_quartz_wrench" />または<ItemLink id="network_tool" />をShiftキーを押しながら右クリックすると、  
そのブロック内のすべてを壊すことなく、単一のサブパーツ(またはケーブル)を切り離すことができます。
