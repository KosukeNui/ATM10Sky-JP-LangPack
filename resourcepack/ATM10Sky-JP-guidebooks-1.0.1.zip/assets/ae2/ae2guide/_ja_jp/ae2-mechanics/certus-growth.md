---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: ケルタスクォーツの成長
  icon: quartz_cluster
---

# ケルタスクォーツの成長

## 基本的にははじめ方からコピー＆ペーストしただけです

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/budding_certus_1.snbt" />
</GameScene>

ケルタスクォーツの芽は、アメジストと同様に、[芽生えたケルタスクォーツ](../items-blocks-machines/budding_certus.md)から芽が出ます。  
成長が完了していない芽を破壊すると、幸運によって変化しない<ItemLink id="certus_quartz_dust" /> が1つドロップします。  
完全に成長した塊を破壊すると、4つの <ItemLink id="certus_quartz_crystal" /> がドロップし、幸運によってこの数が増加します。

ケルタスクォーツブロックには、「完璧」、「傷ついた」、「角の欠けた」、「壊れかけ」の4つの段階があり、最初は[隕石](../ae2-mechanics/meteorites.md)の中で見つかります。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

芽が別の段階で成長するたびに、芽生えたブロックは1段階ずつ劣化する可能性があり、  
最終的には普通のケルタスクォーツブロックに変わります。  
1つ以上の<ItemLink id="charged_certus_quartz_crystal" />と一緒に芽生えたブロック(またはケルタスクォーツブロック)を水に投げ込むことで、  
それらを修復する(そして新しい芽生えたブロックを作成する)ことができます。

<RecipeFor id="damaged_budding_quartz" />

完璧な芽生えたケルタスブロックは劣化せず、無限にケルタスクォーツを生成します。
ただし、シルクタッチであっても、ツルハシで作成したり移動したりすることはできません。  
(ただし、[空間ストレージ](../ae2-mechanics/spatial-io.md)を使用して移動することは*できます*)

ケルタスクォーツの芽は、それ自体では非常にゆっくりと成長します。  
幸いなことに、<ItemLink id="growth_accelerator" />は、出芽ブロックに隣接して配置されると、このプロセスを大幅に加速します。  
これらをいくつか構築するのは最優先事項です。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_certus_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

複雑な相互作用により、芽生えたブロックの面がふさがれるたびに、そのブロックから育つ量の合計が遅くなり、やがて加速器を増やす効果を上回ります。実際に試した結果は次のとおりです。

![Items/min for ratios](../assets/diagrams/certus_farm_speed_chart_1.png)

![common setups](../assets/diagrams/certus_farm_speed_chart_2.png)

<ItemLink id="energy_acceptor" />または<ItemLink id="vibration_chamber" />を作成するのに十分なクォーツがない場合は、<ItemLink id="crank" />を作成して、手動で動かしましょう。

ケルタスクォーツの自動収集については、[ここで説明されています](../example-setups/simple-certus-farm.md)。