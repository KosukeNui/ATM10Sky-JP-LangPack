---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 隕石
  icon: sky_stone_block
---

# 隕石

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/meteor_interior.snbt" />
</GameScene>

隕石は AE2 を使用するための出発点です。彼らは重要な資料を提供します:  
さまざまなタイプの [芽生えたケルタスクォーツブロック](../items-blocks-machines/budding_certus.md)と中央にある<ItemLink id="mysterious_cube" />。

[はじめ方](../getting-started.md)には、見つけた後に何をすべきかについての情報が記載されています。

## 隕石を見つける

隕石はかなり一般的で、地面に大きな穴を残すため、すでにいくつかを見つけているかもしれません。  
そうでない場合は、<ItemLink id="meteorite_compass" />が最も近い神秘的なキューブを指します。

![Meteorite Crater](../assets/assemblies/meteorite-crater.png)