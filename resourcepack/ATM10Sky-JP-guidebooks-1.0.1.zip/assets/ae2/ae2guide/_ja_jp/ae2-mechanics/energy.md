---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: エネルギー
  icon: energy_cell
---

# エネルギー

ネットワークを実行するにはエネルギーが必要です。  
ネットワークには、[デバイス](../ae2-mechanics/devices.md)から直接引き出すエネルギーのプールがあり、  
<ItemLink id="vibration_chamber" />、<ItemLink id="energy_acceptor" />、および<ItemLink id="controller" />に追加します。  
ネットワークのエネルギー統計を確認するには、<ItemLink id="network_tool" />を使用してネットワーク上の任意の場所を右クリックするか、  
ネットワークのコントローラーがある場合はそれを右クリックします。  
このネットワーク全体のストレージと配信は、エネルギー転送速度の制限がないことを意味するため、  
デバイスは任意の大量のエネルギーを引き出すことができ、エナジーアクセプターは機能的に無制限の速度で取り込むことができますが、  
制限されるのはエネルギーストレージによってのみです。

## エネルギー受け入れ

<Row>
  <BlockImage id="energy_acceptor" scale="4" />

  <GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
  </GameScene>

  <BlockImage id="controller" p:state="online" scale="4" />

  <BlockImage id="vibration_chamber" p:active="true" scale="4" />
  
  <BlockImage id="crystal_resonance_generator" scale="4" />
</Row>

AE2は内部的にForge Energy(Forge上)またはTechReborn Energy(Fabric上)を使用しません。  
代わりに、それらを独自の単位AEに変換します。  
この変換は一方向です。  
エネルギーは<ItemLink id="energy_acceptor" />と<ItemLink id="controller" />によって変換できますが、  
コントローラーの面はより多くの[チャンネル](../ae2-mechanics/channels.md)に使用する方が適切です。  
<ItemLink id="vibration_chamber" />で生成したり、<ItemLink id="crystal_resonance_generator" />で受動的に生成したりすることもできますが、  
AE2はより優れたエネルギー生成を備えた他の技術MODと一緒に使用できるように設計されています。

これらすべては、基地のエネルギー分配インフラストラクチャをレイアウトするときに、  
AE2ネットワークを単一の大きなマルチブロックマシンとして考慮するのが最善であることを意味します。

Forge EnergyとTechReborn Energyの変換比率は以下の通りです

*   2 FE = 1 AE (Forge)
*   1 E  = 2 AE (Fabric)

## エネルギーストレージ

<Row>
  <BlockImage id="energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="4" />
</Row>

比較的明白な理由により、ネットワークは、貯蔵できる以上のエネルギーをゲームティックから取り込んだり、消費したりすることはできません。  
ネットワークが800AEしか保存できない場合、その[デバイス](../ae2-mechanics/devices.md)がエネルギーを要求すると、  
最大800AE(ストレージがいっぱいであると仮定)のエネルギーしか使用できなくなります。  
アクセプターは、ネットワークに最大800AEしか挿入できません(ストレージが空であると仮定して)。

これは、エナジーアクセプタ、ドライブ、端末、およびいくつかのデバイスだけで小さなネットワークを作成し、  
そのインベントリから丸石でいっぱいのインベントリをネットワークにダンプしようとする、奇妙な動作の一般的な原因です。  
その丸石を1つのゲームティックに一度に挿入するには、　　
ネットワークがストレージに持っているエネルギーよりも多くのエネルギーが必要となるため、  
すべての丸石が挿入されず、ネットワークがエネルギーを使い果たして再起動します。

**これはエナジーセルを追加することで解決できます。**

ネットワークには、ケーブル、マシン、または部品ごとに25AEのエネルギーバッファーが組み込まれています。

<ItemLink id="controller" />には、8,000AEの少量の内部エネルギー貯蔵があります。

<ItemLink id="energy_cell" />は200kAEを保存でき、ほとんどのユースケースでは1つだけで十分であり、　　
通常のネットワーク使用時の電力サージを簡単に処理できます。

<ItemLink id="dense_energy_cell" />は1.6MAEを保存でき、保存された電力でネットワークを実行する場合、  
または大規模な[空間ストレージ](spatial-io.md)の大量の瞬間エネルギー消費を処理する場合に最適です。

<ItemLink id="creative_energy_cell" />はテスト用のクリエイティブアイテムで、無制限のパゥワーなどを提供します。