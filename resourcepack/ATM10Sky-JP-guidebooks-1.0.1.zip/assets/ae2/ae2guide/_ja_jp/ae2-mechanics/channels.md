---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: チャンネル
  icon: controller
---

# チャンネル

Applied Energistics 2の[MEネットワーク](me-network-connections.md)では、  
ネットワークストレージやその他のネットワークサービスを使用する[デバイス](../ae2-mechanics/devices.md)をサポートするチャンネルが必要です。  
チャンネルは、すべてのデバイスに接続されるUSBケーブルのようなものだと考えてください。  
コンピューターにあるUSBポートの数には限りがあり、コンピューターに接続されているデバイスの数には限りがあります。  
ほとんどのマシン、フルブロックデバイス、および標準ケーブルは、最大8チャンネルしか通過できません。  
フルブロックデバイスと標準ケーブルは、8本の「チャンネルワイヤ」の束と考えることができます。  
ただし、[高密度ケーブル](../items-blocks-machines/cables.md#dense-cable)は最大32チャンネルをサポートできます。  
32チャンネルを送信できる他のデバイスは、<ItemLink id="me_p2p_tunnel" />と[量子ネットワークブリッジ](../items-blocks-machines/quantum_bridge.md)だけです。  
デバイスがチャンネルを使い果たすたびに、バンドルからUSBの「ワイヤ」を引き抜くことを想像してください。  
これは明らかに、「ワイヤ」がその後利用できなくなることを意味します。

<GameScene zoom="7" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_demonstration_1.snbt" />

  <LineAnnotation color="#33ff33" from="1 .4 .7" to="2.4 .4 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .7" to="2.4 .6 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .6" to="2.6 .4 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.4 .6 .7" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .4 .7" to="2.4 .4 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .6 .6" to="2.6 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 .6" to="2.6 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.1 .6 1.5" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 1.5" to="2.9 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.6 .6 1.5" to="2.6 .9 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .1 1.5" to="2.4 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .4" to="3.5 .6 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="3.5 .6 .4" to="3.5 .9 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="3.5 .1 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .3" to="1.5 .6 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1.5 .6 .3" to="1.5 .9 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1.5 .1 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#ff3333" from="3.5 .5 .5" to="5.5 .5 .5" alwaysOnTop={true}>
    ケーブル内の8チャンネルすべてが使用されているため、ドライブはチャンネルを取得できません。 
  </LineAnnotation>

  <LineAnnotation color="#993333" from="1 .5 .5" to="1.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="1.5 .5 .5" to="1.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2 .5 .5" to="2.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2.5 .5 .5" to="2.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="3 .5 .5" to="3.25 .5 .5" alwaysOnTop={true}/>

  <DiamondAnnotation pos="3.6 0.5 0.5" color="#ff0000">
    ケーブル内の8チャンネルすべてが使用されているため、ドライブはチャンネルを取得できません。
  </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

チャンネルがどのように使用され、ネットワーク内でルーティングされているかを確認する簡単な方法は、[スマートケーブル](../items-blocks-machines/cables.md) を使用することです。  
これにより、チャンネルのパスと使用状況が表示されます。

チャンネルは横断するノードごとに1⁄128 AE/tを消費します。  
これは、8つのデバイスと96ノードを超えるネットワークに<ItemLink id="controller" />を追加することで、  
電力使用量が実際に減少する可能性があることを意味します。  

**チャンネルはケーブルの色とは関係ありません**。ケーブルの色によってケーブルが接続されなくなることに注意してください。

## チャンネルルーティング

<ItemLink id="controller" />を使用する場合、チャンネルは3つのステップを介してルーティングされます。  
まず、隣接するマシンを経由して最も近い[通常のケーブル](../items-blocks-machines/cables.md)(ガラス、カバー、またはスマート)に至る最短パスをたどります。  
次に、その通常のケーブルを通って最も近い[高密度ケーブル](../items-blocks-machines/cables.md)(高密度または高密度スマート)までの最短パスをたどります。  
次に、その密集したケーブルを通って<ItemLink id="controller" />までの最短パスをたどります。  
最短パスがすでに最大値に達している場合、一部の[デバイス](devices.md)は必要なチャンネルを取得できない可能性があります。  
色付きのケーブル、ケーブルアンカー、トンネルを有効に使用して、チャンネルが希望のパスに確実に到達するようにします。

たとえば、この場合、一部のドライブはチャンネルを取得できません。これは、ケーブルに十分な容量があるにもかかわらず、  
チャンネルが最短パスを選択しようとするため、一部のケーブルが過負荷になり、他のケーブルが空のままになるためです。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 3.6" to="1.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.4 0.5 3.6" to="1.4 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 1.6" to="0.6 .5 1.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 1.6" to="0.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 3.4" to="1.4 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 3.4" to="1.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <BoxAnnotation color="#dddddd" min="1.2 0.2 3.2" max="1.8 0.8 3.8" alwaysOnTop={true} thickness="0.05">
    8つ以上のチャンネルがここを経由しようとするため、一部が切断されます。
  </BoxAnnotation>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

これは、チャンネルが通過できるパスをより慎重に制限することで修正できます。ネットワークは樹木状(または低木状)である必要があります。  
ループとあいまいなチャンネルパスは最小限に抑える必要があります。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue_fix.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 5.6" to="1 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

## アドホックネットワーク

<ItemLink id="controller" />のないネットワークはアドホックとみなされ、デバイスを使用して最大8つのチャンネルをサポートできます。  
デバイスが8台を超えると、デバイスを使用しているネットワークチャンネルがシャットダウンされ、  
デバイスを削除するか、<ItemLink id="controller" />を追加する必要があります。

制御されたネットワークとは異なり、アドホックネットワーク上の[スマートケーブル](../items-blocks-machines/cables.md)には、  
その特定のケーブルを流れるチャンネルの数ではなく、ネットワーク全体で使用されているチャンネルの数が表示されます。

アドホックネットワークを使用している間、各デバイスはネットワーク全体で1チャンネルを使用しますが、  
これは<ItemLink id="controller" />が最短ルートに基づいてチャンネルを割り当てる方法とは大きく異なります。

## デザイン

[チャンネルルーティング](channels.md#channel-routing)で前述したように、ネットワークをツリー状の構造で設計するのが最適です。　
つまり、コントローラから高密度のケーブルが分岐し、高密度ケーブルから通常のケーブルが分岐し、  
通常のケーブル上に8つ以下の[デバイス](../ae2-mechanics/devices.md)のクラスタが形成されます。　

以下に、してはいけないことの例を示します:

チャンネルパスに従って、

1. 右側のコントローラーから出てすぐに、ドライブが通常のケーブルのように動作するため、8チャンネルがボトルネックになります。  
ただし、ここではスマートケーブルを使用していないため、使用されているチャンネルの数を確認できません。  
残り8チャンネル。  
2. ドライブはチャンネルを使用します。  
残り7チャンネル。  
3. 2チャンネルが端子まで上がります。  
残り5チャンネル。  
4. 右に進むと、インターフェイスは別のチャンネルを使用します。  
残り4チャンネル。  
5. 1 チャンネルはパターンプロバイダーに送られます。  
残り3チャンネル。  
6. 右に進むと、1 チャンネルがインポート バスに上がります。  
残り2チャンネル。  
7. 分子組立機に供給するパターンプロバイダーのクラスターは2つのチャンネルしか取得しないため、  
プロバイダーのうち2つはチャンネルを取得しません。

結局のところ、間違いはチャンネルがボトルネックになっていることと、チャンネルがどのように分散されるかをよく考えていないことにあります。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/bad_network_structure.snbt" />

<LineAnnotation color="#33ff33" from="6.5 .5 1.5" to="6 .5 1.5" alwaysOnTop={true} thickness="0.4">
  32 channels
</LineAnnotation>

<LineAnnotation color="#33ff33" from="6 .5 1.5" to="5.5 .5 1.5" alwaysOnTop={true} thickness="0.2">
  8 channels
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 1.5 1.5" alwaysOnTop={true} thickness="0.1">
  2 channels
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 1.5 1.5" to="5.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 2.5 1.5" to="5.5 2.5 1.1" alwaysOnTop={true} thickness="0.071">
  1 channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="4.5 .5 1.5" alwaysOnTop={true} thickness="0.158">
  5 channels
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 1.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="3.5 .5 1.5" alwaysOnTop={true} thickness="0.122">
  3 channels
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="3.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 2.5 1.5" to="3.7 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="1.5 .5 1.5" alwaysOnTop={true} thickness="0.1">
  2 channels
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="1.5 0.3 1.5" alwaysOnTop={true} thickness="0.071">
  1 channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="0.5 0.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="0.5 0.5 1.5" to="0.5 0.5 0.5" alwaysOnTop={true} thickness="0.071">
  1 channel
</LineAnnotation>

<LineAnnotation color="#ff3333" from="0.5 1.5 1.5" to="0.5 1.3 1.5" alwaysOnTop={true} thickness="0.071">
  no channels
</LineAnnotation>

<LineAnnotation color="#ff3333" from="1.5 1.5 0.5" to="1.5 1.3 0.5" alwaysOnTop={true} thickness="0.071">
  no channels
</LineAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

---

これは良い構造の例です:

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/treelike_network_structure.snbt" />

    <BoxAnnotation color="#dddddd" min="6.9 0 4.9" max="9.1 4 7.1" thickness="0.05">
        パターンプロバイダーが8つの別々のグループに属していることに注意してください。
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 4 4" max="8 5 5" thickness="0.05">
        チャンネルが詰まった2本の通常のケーブルを一緒に接続するには、高密度のケーブルが必要であることを意味します。
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 0 13" max="8 1 14" thickness="0.05">
        隣接するケーブルが接続されないように、異なるケーブル色が使用されています。
    </BoxAnnotation>


  <IsometricCamera yaw="315" pitch="30" />
</GameScene>

## チャンネルモード

Minecraft 1.18 用 AE2 10.0.0 では、ワールド内でのAE2チャンネルの動作を変更する新しいオプションが導入されています。  
このオプションを制御する一般セクション(チャンネル)には新しい設定オプションがあり、  
オペレーターがゲーム内からモードと設定を変更するための新しいゲーム内コマンドがあります。  
コマンドは「`/ae2 channelmode <mode>`」で変更し、「`/ae2 channelmode`」で現在のモードを表示します。  
ゲーム内でモードが変更されると、既存のグリッドはすべて再起動され、新しいモードがすぐに使用されます。

これは、Minecraft 1.12 で利用可能だったオプションを復活および改良し、もう少しリラックスしたゲームプレイを望んでいるが、  
メカニズムを完全に削除したくないプレイヤー向けに、より良いオプションを導入します。

次の表に、構成ファイルとコマンドの両方で使用可能なモードを示します。

| Setting    | Description                                                                                                                                                                                                                               |
| ---------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `default`  | このWebサイト全体で説明されているように、  ケーブルおよびアドホック ネットワークのチャンネル容量を備えた標準モード                                                                                                                           |
| `x2`       | すべてのチャンネル容量が2倍になります  (通常のケーブルで16、高密度ケーブルで64、  アドホックネットワークは16チャンネルをサポートします)。                                                                                                                           |
| `x3`       | すべてのチャンネル容量が3倍になります  (通常のケーブルで24、高密度ケーブルで92、  アドホックネットワークは24チャンネルをサポートします)。                                                                                                                           |
| `x4`       | すべてのチャンネル容量が4倍になります  (通常のケーブルで32、高密度ケーブルで128、  アドホックネットワークは32チャンネルをサポートします)。                                                                                                                       |
| `infinite` | すべてのチャンネル制限が解除されます。  コントローラーは依然としてグリッドの電力消費を「大幅に」削減します。  スマートケーブルは、完全にオフ(チャンネルが伝送されない)と  完全にオン(1つ以上のチャンネルが伝送される)の間でのみ切り替わります。 |