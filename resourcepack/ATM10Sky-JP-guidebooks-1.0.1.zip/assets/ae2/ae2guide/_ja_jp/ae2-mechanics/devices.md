---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: デバイス
  icon: interface
---

# デバイス

「デバイス」とは、ネットワーク自体に関連する何らかの機能を実行するAE2ネットワークコンポーネントを指します。  
[レベルエミッタ](../items-blocks-machines/level_emitter.md)の注目すべき例外を除いて、ほとんどの場合チャネルが必要です。

いくつかの例としては:

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />
