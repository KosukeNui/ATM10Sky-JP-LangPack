---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: ネットワーク接続
  icon: fluix_glass_cable
---

# ネットワーク接続

## 「ネットワーク」とはどういう意味ですか?

「ネットワーク」とは、[ケーブル](../items-blocks-machines/cables.md)やフルブロックのマシンや[デバイス](../ae2-mechanics/devices.md)など、  
[チャンネル](../ae2-mechanics/channels.md)が通過できるブロックによってリンクされた[デバイス](../ae2-mechanics/devices.md)のグループです。  
(<ItemLink id="charger" />、<ItemLink id="interface" />、<ItemLink id="drive" />など)  
技術的には、1本のケーブルがネットワークになります。

## デバイスの配置に関する余談

特定のネットワーク機能 ([ネットワークストレージ](../ae2-mechanics/import-export-storage.md)に搬入出する<ItemLink id="interface" />、  
ネットワークストレージの内容を読み取る<ItemLink id="level_emitter" />、  
ネットワークストレージそのものである<ItemLink id="drive" />など)を持つ[デバイス](../ae2-mechanics/devices.md)の場合、デバイスの物理的な位置は関係ありません。

繰り返しますが、**デバイスの物理的な位置は重要ではありません**。  
重要なのは、デバイスがネットワークに接続されているかどうか(もちろん、どのネットワークに接続されているか)だけです。

## ネットワーク接続

ネットワーク内に何が接続されているかを確認する簡単な方法は、<ItemLink id="network_tool" />を使用することです。  
ネットワーク上のすべてのコンポーネントが表示されるため、表示すべきでないものが表示されたり、  
表示されるべきものが表示されなかったりする場合は、問題があります。

たとえば、これは2つの別個のネットワークです。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        ネットワーク1
  </BoxAnnotation>

<BoxAnnotation color="#5CA7CD" min="2 0 0" max="3 2 2">
        ネットワーク2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="quartz_fiber" />はネットワーク接続を提供せずに[エネルギー](../ae2-mechanics/energy.md)を共有するため、  
これも2つの別個のネットワークです。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        ネットワーク1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="1.3 0 0" max="3 2 2">
        ネットワーク2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ただし、これは1つのネットワークにすぎず、2つの別個のネットワークではありません。  
[量子ブリッジ](../items-blocks-machines/quantum_bridge.md)は無線の[高密度ケーブル](../items-blocks-machines/cables.md#dense-cable)のように動作するため、両端は同じネットワーク上にあります。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="7 3 3">
        全体で1つのネットワーク
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

[ケーブル](../items-blocks-machines/cables.md)の色は、異なる色のケーブルが互いに接続されないことを除き、  
ネットワーク接続とは関係がないため、これも1つのネットワークにすぎません。すべての色はフルーシュ(または「無色」)ケーブルに接続します。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        全体で1つのネットワーク
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## サブネットの観点から見た接続

[サブネットワーク](../ae2-mechanics/subnetworks.md)は、ネットワーク接続(特に、接続**しない**こと)を利用して、  
どの[デバイス](../ae2-mechanics/devices.md)がどのデバイスにアクセスできるかを制限します。

サブネットとは、実のところ、別個のネットワークにすぎません。

たとえば、[鉱石幸運採掘の自動化](../example-setups/ore-fortuner.md)のセットアップを見てみましょう。ここには3つの別個のネットワークがあり、  
どれもセットアップの中で特定の役割を果たしています。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 2" max="3 1 3">
        ネットワーク1。パイプサブネットのように働き、インポートバスがアクセスできる先を制限して、
        鉱石ブロックを形成プレーンを通して「格納」させます。
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="0 0 0" max="3 1 1">
        ネットワーク2。もう1つのパイプサブネットのように働き、消滅プレーンがアクセスできる先を制限して、
        幸運で増えた鉱石の塊をメインネットワークではなくバレルに格納させます。また、メインネットワークの
        チャンネルを使わずに済みます。
  </BoxAnnotation>

  <BoxAnnotation color="#82CD5C" min="2 0 1" max="4 1 2">
        ネットワーク3。すべてのストレージとクラフトがあるメインネットワークです。実のところ電力を供給するためだけにあり、
        2つのサブネットには*接続していません*。
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## P2Pの観点から見た接続

[P2Pトンネル](../items-blocks-machines/p2p_tunnels.md)の種類の1つは、アイテムや流体やレッドストーン信号ではなく[チャンネル](channels.md)を運びますが、  
なぜかこれが混乱のもとになります。トンネルが取り付けられているネットワークと、トンネルが運んでいるネットワークは関係ありません。  
同じネットワークに*することもできます*が、そうする必要はなく、たいていは別のネットワークです。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels_network_connection.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 1">
        ネットワーク1。運ばれる側のネットワーク(たいていはメインネットワーク)
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="3.98 1 1">
        ネットワーク2。ME P2Pトンネルを動かしているネットワーク(たいていはメインネットワーク*ではない*)
  </BoxAnnotation>

  <BoxAnnotation color="#915dcd" min="4.02 0 0" max="6 1 1">
        ネットワーク1。運ばれる側のネットワーク(たいていはメインネットワーク)
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 直感的ではない接続

この場合、フルブロックデバイスである<ItemLink id="pattern_provider" />はケーブルのように動作し、  
<ItemLink id="inscriber" />も同様の動作をするため、これは1つのネットワークにすぎません。  
したがって、ネットワーク接続はプロバイダーと刻印機を通過します。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        全体で1つのネットワーク
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

これを防ぐには([サブネットワーク](../ae2-mechanics/subnetworks.md)を含む多くの自動クラフトのセットアップに役立ちます)、  
<ItemLink id="certus_quartz_wrench" />でプロバイダーを右クリックして方向を指定できます。この場合、片側にはチャンネルが通過しません。

<Row gap="40">
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 2">
        ネットワーク1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="4 2 2">
        ネットワーク2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_directional_connection.snbt" />

  <BoxAnnotation color="#ee3333" min="1 .3 .3" max="1.3 .7 .7">
        ケーブルが接続されない様子を観察してください
  </BoxAnnotation>

  <IsometricCamera yaw="255" pitch="30" />
</GameScene>
</Row>

方向性のあるネットワーク接続を提供しない他のパーツは、  
<ItemLink id="import_bus" />、<ItemLink id="storage_bus" />、<ItemLink id="cable_interface" />などの  
ほとんどの[サブパーツ](../ae2-mechanics/cable-subparts.md)の[デバイス](../ae2-mechanics/devices.md)です。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/subpart_no_connection.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
