---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: インポート、エクスポート、外部ストレージ
---

# インポート、エクスポート、外部ストレージ

**あなたの ME システムと世界**

AE2 の重要な概念は、ネットワークストレージの概念です。  
これは、ネットワークのコンテンツが保存される場所であり、通常は[ストレージセル](../items-blocks-machines/storage_cells.md)または  
<ItemLink id="storage_bus" />が接続されているインベントリです。ほとんどのAE2[デバイス](../ae2-mechanics/devices.md)は、何らかの方法でこれとやり取りします。

例えば,

*   <ItemLink id="import_bus" />はネットワークストレージにデータを搬入します
*   <ItemLink id="export_bus" />はネットワークストレージからデータを搬出します
*   <ItemLink id="interface" /> はネットワークストレージからの搬出とネットワークストレージへの搬入の両方を行います
*   [ターミナル](../items-blocks-machines/terminals.md)はアイテムを挿入または取得するとき、  
    またはクラフトスロットを補充するときに、ネットワークストレージへの搬入出を行います。
*   <ItemLink id="storage_bus" />は、実際にはストレージに搬入出するのではなく、  
    ネットワークストレージとして使用するために、接続されたインベントリに搬入出します 　
    (つまり、実際には他のデバイスがそれらに搬入出します)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_export_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="8 1 1" max="9 1.3 2">
        インポートバスは、接しているインベントリからネットワークストレージにインポートします。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="8 2 1" max="9 3 1.3">
        インベントリから端末に何かを挿入すると、それをインポートするネットワークとしてカウントされます
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="7 0 1" max="8 1 2">
        そのスロットが何もストックするように構成されていない場合、またはそれ以上のスロットがある場合、インターフェイスは内部インベントリからインポートします。
        そのスロット内のアイテムはストックされるように構成されているため、そこに物を押し込んでネットワークに挿入できます
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="6 0 1" max="7 1 2">
        パターン プロバイダーは内部の返品スロットインベントリからインポートするため、それらにプッシュしてネットワークに挿入できます。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 1" max="5 2 2">
        ドライブは挿入されたセルをネットワークストレージとして提供します
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        ストレージバスは、ネットワークストレージとして指定しているインベントリを使用します。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 1" max="2 1.3 2">
        エクスポートバスは、ネットワークストレージから対象のインベントリに内容をエクスポートします。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="2 3 1.3">
        端末から何かを引き出すと、ネットワークがそれをエクスポートしたとみなされます
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 1" max="1 2 2">
        そのスロットが何かをストックするように構成されている場合、インターフェイスは内部インベントリにエクスポートされます。
        そのため、そこから物事を取り出してネットワークから抽出することができます
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ネットワークストレージへの搬入およびネットワークストレージからの搬出のアクション/イベントは、  
自動化および物流セットアップを設計するときに念頭に置くことが重要です。

## ストレージの優先度

一部の GUI の右上にあるレンチをクリックすると、優先順位を設定できます。  
ネットワークに入るアイテムは、最初の宛先として最も優先度の高いストレージから開始されます。  
2つのストレージの優先度が同じ場合、一方のストレージにすでにアイテムが含まれている場合は、  
そのストレージが他のストレージよりも優先されます。  
ホワイトリストに登録されたセルは、他のストレージと同じ優先グループにある場合、  
そのアイテムがすでに含まれているものとして扱われます。  
ストレージから削除されるアイテムは、最も低い優先順位でストレージから削除されます。  
この優先順位システムは、アイテムがネットワーク ストレージに挿入および削除されると、  
優先順位の高いストレージがいっぱいになり、優先順位の低いストレージが空になることを意味します。
