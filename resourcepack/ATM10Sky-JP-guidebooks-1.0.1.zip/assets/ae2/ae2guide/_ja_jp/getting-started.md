---
navigation:
  title: はじめ方 (1.20+)
  position: 10
---

<div class="notification is-info">
  次の情報は、Minecraft 1.20 以降の Applied Energistics 2 にのみ適用されます。
</div>

# はじめ方

## 初期材料の入手

<GameScene zoom="4" background="transparent">
  <ImportStructure src="assets/assemblies/meteor_interior.snbt" />
</GameScene>


Applied Energistics 2 を始めるには、まず[隕石](ae2-mechanics/meteorites.md)を見つける必要があります。  
これらはかなり一般的で、地形に大きな穴を残す傾向があるため、おそらく旅の中で遭遇したことがあるでしょう。  
まだ見つけていない場合は、最も近い<ItemLink id="mysterious_cube" />を指す<ItemLink id="meteorite_compass" />を作成できます。

隕石を見つけたら、その中心に向かって採掘します。  
ケルタスクォーツの塊、ケルタスクォーツの芽、様々な種類の[芽生えたケルタスクォーツ](items-blocks-machines/budding_certus.md)、そして中央に神秘的なキューブがあります。

ケルタスクォーツの塊と見つけたケルタスクォーツブロックを採掘します。  
芽が出ているケルタスクォーツブロックを拾うこともできますが、シルクタッチがないと1段階劣化します。

シルクタッチでも傷ついた芽生えたケルタスクォーツに劣化し、完璧な芽生えたケルタスクォーツを修復することは不可能であるため、  
完璧な芽生えたケルタスクォーツを壊さないでください。

また、隕石の中心にある神秘的なキューブを採掘して、4種類の金型をすべて入手します。

## ケルタスクォーツの成長

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_1.snbt" />
</GameScene>

ケルタスクォーツの芽は、アメジストと同様に、[芽生えたケルタスクォーツ](items-blocks-machines/budding_certus.md)から芽が出ます。  
成長が完了していない芽を破壊すると、幸運によって変化しない<ItemLink id="certus_quartz_dust" /> が1つドロップします。  
完全に成長した塊を破壊すると、4つの <ItemLink id="certus_quartz_crystal" /> がドロップし、幸運によってこの数が増加します。

ケルタスクォーツブロックには、「完璧」、「傷ついた」、「角の欠けた」、「壊れかけ」の4つの段階があります。

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_blocks.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

芽が別の段階で成長するたびに、芽生えたブロックは1段階ずつ劣化する可能性があり、  
最終的には普通のケルタスクォーツブロックに変わります。  
1つ以上の<ItemLink id="charged_certus_quartz_crystal" />と一緒に芽生えたブロック(またはケルタスクォーツブロック)を水に投げ込むことで、  
それらを修復する(そして新しい芽生えたブロックを作成する)ことができます。

<RecipeFor id="damaged_budding_quartz" />

完璧な芽生えたケルタスブロックは劣化せず、無限にケルタスクォーツを生成します。
ただし、シルクタッチであっても、ツルハシで作成したり移動したりすることはできません。  
(ただし、[空間ストレージ](ae2-mechanics/spatial-io.md)を使用して移動することは*できます*)

ケルタスクォーツの芽は、それ自体では非常にゆっくりと成長します。  
幸いなことに、<ItemLink id="growth_accelerator" />は、出芽ブロックに隣接して配置されると、このプロセスを大幅に加速します。  
これらをいくつか構築するのは最優先事項です。

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_2.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="energy_acceptor" />または<ItemLink id="vibration_chamber" />を作成するのに十分なクォーツがない場合は、<ItemLink id="crank" />を作成して、手動で動かしましょう。

ケルタスクォーツの自動収集については、[ここで説明されています](example-setups/simple-certus-farm.md)。

## フルーシュについての簡単な余談

必要となるもう1つの材料は、成長加速器を作成する際にすでに使用したフルーシュです。  
チャージ済みのケルタスクォーツ、レッドストーン、ネザークォーツを水に投入して作ります。  
これを自動的に行うことは、「読者の演習として残される」ことになります。

まだ作成していない場合は、<ItemLink id="charger" />は<ItemLink id="charged_certus_quartz_crystal" />を生成するために必要です。

## 刻印機によるプロセッサー作成

隕石の略奪では、神秘的なキューブを壊すことでドロップした4つの「金型」を見つけることになります。  
これらは<ItemLink id="inscriber" />で3種類のプロセッサを作成するために使用されます。

<ItemGrid>
  <ItemIcon id="silicon_press" />

  <ItemIcon id="logic_processor_press" />

  <ItemIcon id="calculation_processor_press" />

  <ItemIcon id="engineering_processor_press" />
</ItemGrid>

刻印機は、バニラのかまどとよく似た側面型のマシンです。  
上または下から挿入するとアイテムは上または下のスロットに配置され、横または後ろから挿入すると中央のスロットにアイテムが挿入されます。  
制作物は側面または背面から引き出すことができます。

ホッパーによる自動化を容易にする(およびパイプスパゲッティを減らす)ために、<ItemLink id="certus_quartz_wrench" />を使用して刻印器を回転できます。

次のステップに備えて各タイプのプロセッサをいくつか作成し、非常に基本的なMEシステムを作成します。  
プロセッサ製造の自動化は「[読者の演習として残されています](example-setups/processor-automation.md)」。

## Matter Energy Tech: ME ネットワークとストレージ

### MEストレージとは?

「エムイー」と発音し、Matter Energy を表します。

Matter EnergyはApplied Energistics2の主要コンポーネントであり、マルチブロックチェストのマッドサイエンティストバージョンのようなもので、  
保管状況に革命を起こすことができます。  
MEはMinecraftの他のストレージシステムとは大きく異なり、慣れるまでに少し独創的な考え方が必要になるかもしれません。  
しかし、一度始めてみると、狭いスペースに膨大な量のストレージがあり、複数のアクセス端末は可能になるものの氷山の一角にすぎません。

### 始めるために知っておくべきことは何ですか?

まず、MEは[ストレージセル](items-blocks-machines/storage_cells.md)と呼ばれる他のアイテムの中にアイテムを格納します。  
5つの段階があり、ストレージの量は増え続けています。  
ストレージセルを使用するには、ストレージセルを <ItemLink id="chest" />または<ItemLink id="drive" />内に配置する必要があります。

<ItemLink id="chest" />はセルの中に配置されるとすぐにその内容を表示し、<ItemLink id="minecraft:chest" />であるかのようにアイテムを追加したり削除したりできます。  
ただし、アイテムは実際には<ItemLink id="chest" />自体ではなく、ストレージセルに保存されます。

<ItemLink id="chest" />は使える場面が限られ、用途もかなり限定的です。AE2を本当に活用するには、  
[MEネットワーク](ae2-mechanics/me-network-connections.md)をセットアップする必要があります。

## 初めてのMEシステム

Applied Energistics2の基本的な材料と機械がすべて揃ったので、最初のME(Matter Energy)システムを作成できます。  
これは非常に基本的なもので、自動作成や物流はなく、ただ素晴らしく、シンプルで、検索可能なストレージです。

<GameScene zoom="6" interactive={true}>
<ImportStructure src="assets/assemblies/tiny_me_system.snbt" />

</GameScene>

*   材料リスト:
    * 1x <ItemLink id="drive" />
    * 1x <ItemLink id="terminal" /> or <ItemLink id="crafting_terminal" />
    * 1x <ItemLink id="energy_acceptor" />
    * 数本の[ケーブル](items-blocks-machines/cables.md)、ガラス製、カバー付き、またはスマートだが高密度ではないもののいずれか
    * いくつかの[ストレージセル](items-blocks-machines/storage_cells.md)。  
    容量とタイプを適切に組み合わせるには4Kタイプが推奨されます  
    ([パーティション](items-blocks-machines/cell_workbench.md)4kと1kの混合ですが、それは複雑ですので、ここでは説明しません)
---
1.  MEドライブを置きます。
2.  エナジーアクセプター(および他のいくつかのAE2[デバイス](ae2-mechanics/devices.md))には、キューブとフラットの2つのモードがあります。  
    これらはクラフトグリッドで切り替えることができます。  
    エナジーアクセプターがキューブの場合は、ドライブの隣に置きます。フラットの場合は、ドライブ上にケーブルを配置し、  
    その上にエナジーアクセプターを配置します。
3.  お気に入りのエネルギー生成MODからのケーブル/パイプ/導管を使用して、エナジーアクセプターにエネルギーを流し込みます。
4.  ケーブルをドライブの上(または目の高さ)に置き、その上にMEターミナルまたはMEクラフトターミナルを置きます。
5.  ストレージセルをMEドライブに挿入します
6.  やったぜ
7.  端末の設定をいじる
8.  究極の力と能力を満喫しましょう
9.  このネットワークは、大まかに言えばかなり小規模であることを認識してください

### ネットワークの拡張

基本的なストレージがあり、そのストレージにアクセスできれば良いスタートですが、  
おそらく一部の処理を自動化することを検討することになるでしょう。

この好例として、  
かまどの上部に<ItemLink id="export_bus" />を配置して鉱石を投入し、  
<ItemLink id="import_bus" />をかまどの底部に配置して炉から鉱石を取り出すことが挙げられます。

<ItemLink id="export_bus" />を使用すると、ネットワークから接続されたインベントリにアイテムをエクスポートできます。  
一方、<ItemLink id="import_bus" />は、接続されたインベントリからネットワークにアイテムをインポートします。

### 限界を超える

この時点で、おそらく8つほどの[デバイス](ae2-mechanics/devices.md)に近づいていますが、  
9つのデバイスに到達したら、[チャンネル](ae2-mechanics/channels.md)の管理を開始する必要があります。  
すべてではありませんが、多くのデバイスが機能するにはチャネルが必要です。

デフォルトでは、ネットワークは8チャンネルをサポートできますが、この制限を超えると、  
ネットワークに<ItemLink id="controller" />を追加する必要があります。  
これにより、ネットワークを大幅に拡張できます。  
[スマートケーブル](items-blocks-machines/cables.md)を使用すると、チャンネルがネットワークを介してどのようにルーティングされるかを確認できます。  
チャンネルがどのように機能するかを学び始めるとき、または大量のレッドストーンとグロウストーンがある場合は、  
これらを幅広く使用してください。
