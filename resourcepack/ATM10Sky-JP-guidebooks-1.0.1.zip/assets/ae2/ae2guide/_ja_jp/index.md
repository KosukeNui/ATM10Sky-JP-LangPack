---
navigation:
  title: 目次
  position: 0
---

![Logo](assets/logo.png)

# Applied Energistics 2とは?

# このガイドの使い方

* 左側のサイドバーにアクセスして目次を見つけます

* 多くのページには操作可能な画像があります。画像の横にある![Plus](assets/diagrams/plus.png)
![Minus](assets/diagrams/minus.png) (ズーム) ボタンを使用すると、カメラを拡大・縮小できます。
左クリックしてドラッグすると回転し、右クリックしてドラッグすると平行移動します。

# Applied Energistics 2とは何か?

Applied Energistics 2 は、物流および保管ソリューションを提供するコンポーネントと機構を追加します。 
チェストでいっぱいの広大な部屋をコンパクトな ME ネットワークに置き換えることはできますが、それはほんの始まりにすぎません。  
Applied Energistics は、MODPack 内の他の MOD と連携して自動化できるようにすることを目的としています。 
ワンクリックで、複雑な作成チェーンのすべての中間素材(および最終成果物)を作成したり、一定量のアイテムを在庫として保持し、  
必要に応じてさらに作成したり、単純にアイテムを周囲に移動したりできるようにシステムを設定できます。 

* [はじめ方](getting-started.md)
* [ヒントとコツ](tips-and-tricks.md)
* [AE2の機械](ae2-mechanics/ae2-mechanics-index.md)
* [構築例](example-setups/example-setups-index.md)
* [アイテム, ブロック, 機械](items-blocks-machines/items-blocks-machines-index.md)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>