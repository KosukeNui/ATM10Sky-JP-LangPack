---
navigation:
  title: ComputerCraft
  parent: integrations/index.md
  position: 1
---

# ComputerCraft

[CC: Tweaked](https://modrinth.com/mod/cc-tweaked)が入っていると、コンピューターは周辺機器としても使えます。スクリプトから、コンピューターの画面に出るすべてのもの（ネットワーク、チャンネル、ノード、ノードのつながり、その場の入出力の様子）を読み、モニターに描けます。

## つなぎ方

CCのコンピューターをコンピューターの横に置くか、有線モデムでつなぎます。周辺機器の種類は`logistics_computer`です:

```lua
local lc = peripheral.find("logistics_computer")
```

## 持ち主

コンピューターは、置いたプレイヤーのものです。スクリプトに見えるのは、サーバーのノードの利用の決まりとFTB Teamsに従って、そのプレイヤーが開けるネットワークだけです。CCのコンピューターをつないだ人は誰でもそのネットワークを読めるので、自分しか近づけない場所に置いてください。

このアップデートより前に置いたコンピューターには、持ち主がいません。ComputerCraftで使うには、一度壊して置き直してください。

## メソッド

`net`は、ネットワークのIDか、その正確な名前です。チャンネルの一覧は画面と同じ順で、それぞれの項目の`index`は、[入出力モニター](../computer/io-monitor.md)に出る`CH`の番号です。番号は0から始まるので、CH0は`channels[1]`です。つながりの辺の`channels`にも、CHの番号が入ります。

| メソッド | 返すもの |
|---|---|
| `listNetworks()` | `{ {id, name, nodeCount, starred, color, createdAt}, ... }` |
| `getChannels(net)` | `{ {index, name, type, nodeCount}, ... }` — 有効なノードのないチャンネルでは`type`はnil |
| `getNodes(net)` | `{ {id, label, block, pos, attachedPos, dimension, visible, highlighted}, ... }` — 読み込まれているノードだけ |
| `getGraph(net)` | `{ name, totalNodes, vertices, edges }` — 頂点は`key, label, x, y, nodes`、辺は`from, to, type, channels`を持つ |
| `watch(net)` | このコンピューターで、その場の様子の記録を始める |
| `unwatch(net)` | 記録を止める |
| `getFlow(net)` | 最後の記録。最初の1秒より前はnil。見ていないネットワークではエラー |

種類は`item`・`fluid`・`energy`・`chemical`・`source`です。

## その場の様子

`watch`のあと、毎秒`logistics_flow`のイベントが届きます:

```lua
local _, side, networkId, sample = os.pullEvent("logistics_flow")
-- sample.channels[1].total, sample.channels[1].resources[1].displayName
```

それぞれのチャンネルには、`index`、`type`、`total`（その1秒に動いた量。単位は入出力モニターと同じ）、`resources`（いちばん多い16のアイテム・液体・化学物質で、`kind`・`name`・`displayName`・`amount`を持つ）があります。エネルギーとソースのチャンネルでは、資源の一覧は空です。

見るのはコンピューターが再起動するか、つながりが切れると終わるので、`startup`のスクリプトから`watch`を呼んでください。持ち主がネットワークに触れられなくなったときや、ネットワークが消されたときも、エラーなしに止まります。

## 例

つないだモニターに、すべてのチャンネルのその場の量を出します:

```lua
local lc = peripheral.find("logistics_computer")
local mon = peripheral.find("monitor")
local net = "Main Base"

mon.setTextScale(0.5)
lc.watch(net)
while true do
  local _, _, _, sample = os.pullEvent("logistics_flow")
  mon.clear()
  for i, ch in ipairs(sample.channels) do
    mon.setCursorPos(1, i)
    mon.write(("CH%d %-8s %d/s"):format(ch.index, ch.type or "-", ch.total))
  end
end
```
