---
item_ids: [logisticsnetworks:dimensional_upgrade, logisticsnetworks:mekanism_chemical_upgrade, logisticsnetworks:ars_source_upgrade, logisticsnetworks:network_upgrade]
navigation:
  title: 特別なアップグレード
  parent: nodes/index.md
  icon: logisticsnetworks:dimensional_upgrade
  position: 5
---

# 特別なアップグレード

特別なアップグレードは、ノードの処理量の上限は変えません。かわりに、ディメンションをまたぐ輸送、Mekanismの化学物質、Ars Nouveauのソース、貯蔵のネットワークへの接続などの**新しい機能**を解放します。どれもアップグレードの枠に入れ、同じノードで[性能のアップグレード](upgrades-performance.md)と組み合わせられます。

アップグレードの枠は、[フィルターとアップグレード](filters-upgrades.md)の欄にあります。同じものは入れられませんが、違うアップグレードなら問題なく重ねられます。よくある上位のノードは、ネザライト・ディメンション・Mekanismの化学物質・Arsのソースを1つずつ持っています。

## ディメンションアップグレード

**ディメンションをまたいで運べるようにします。** このアップグレードがないと、ノードは同じディメンションのノードとしかやり取りできません。ディメンションアップグレードを取り付けると、オーバーワールドとネザー、エンドとオーバーワールド、MODのディメンションなど、ほかのディメンションのノードとのあいだで運べるようになります。

**両方の端に必要です。** 送信側のノードと受信側のノードの両方に、ディメンションアップグレードが必要です。片方だけでは足りません。ディメンションをまたぐ前に、仕組みが両方のノードを確かめます。

同じディメンションの中では、このアップグレードは何もしません。ふつうの輸送はこれがなくても動きます。

<RecipeFor id="logisticsnetworks:dimensional_upgrade" />

## Mekanismの化学物質アップグレード

**化学物質のチャンネルの種類を使えるようにします。** このアップグレードがないと、そのノードでは[チャンネルの設定](channel-settings.md)の種類を化学物質にできません。取り付けると、種類を化学物質にしたチャンネルで、Mekanismの化学物質（気体・注入素材・顔料・スラリー）を感知して運べます。

このアップグレードが必要なのは、そのチャンネルを設定したノードだけです。化学物質の送信側にはこのアップグレードが要り、化学物質の受信側にも、そのノードにこのアップグレードが要ります。化学物質を運ばないノードには要りません。

クラフトにも使うのにも**Mekanism**のMODが必要です。下のレシピは、Mekanismが読み込まれているときだけ表示されます。

<RecipeFor id="logisticsnetworks:mekanism_chemical_upgrade" fallbackText="Install Mekanism to unlock this recipe." />

## Arsのソースアップグレード

**ソースのチャンネルの種類を使えるようにします。** Mekanismの化学物質アップグレードと同じ形で、Ars Nouveauのソース用です。取り付けると、チャンネルの種類をソースにでき、Ars Nouveauのソースの瓶と、ソースに対応したほかのブロックのあいだでソースを運べます。

ソースを運ぶノード（送信側でも受信側でも）には、それぞれArsのソースアップグレードが必要です。

クラフトにも使うのにも**Ars Nouveau**のMODが必要です。下のレシピは、Ars Nouveauが読み込まれているときだけ表示されます。

<RecipeFor id="logisticsnetworks:ars_source_upgrade" fallbackText="Install Ars Nouveau to unlock this recipe." />

## ネットワークアップグレード

**貯蔵のネットワークに直接つなげるようにします。** Applied Energistics 2かRefined Storageのインターフェースに付けたノードにこのアップグレードがあると、[チャンネルの設定](channel-settings.md)で説明しているとおり、つながった貯蔵のネットワーク全体とのあいだで、アイテムと液体を直接運べます。これがないと、インターフェースはただのインベントリの1つで、ノードに見えるのはインターフェースそのものにある分だけです。

ネットワークまで届かせたいインターフェースのノードには、それぞれネットワークアップグレードが必要です。ほかのブロックのノードには要りません。

レシピは貯蔵のMODごとに1つずつ、2つあります。どちらも、そのMODが読み込まれているときだけ表示されます。

<Recipe id="logisticsnetworks:network_upgrade_ae2" fallbackText="Install Applied Energistics 2 to unlock this recipe." />

<Recipe id="logisticsnetworks:network_upgrade_refinedstorage" fallbackText="Install Refined Storage to unlock this recipe." />
