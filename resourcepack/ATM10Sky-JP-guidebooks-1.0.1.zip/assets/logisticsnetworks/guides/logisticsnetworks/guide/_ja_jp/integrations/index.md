---
navigation:
  title: ほかのMODとの連携
  position: 6
---

# ほかのMODとの連携

Logistics Networksは、ほかのいくつかのMODと一緒に動きます。ここでは遊び方が変わるものを紹介します。どの連携も、そのMODが入っているときだけ有効になります。

- [ComputerCraft](computercraft.md): Luaのスクリプトやモニターから、ネットワーク・ノード・ノードの図・入出力の計測をリアルタイムで読み取れます。
- [Building Gadgets](building-gadgets.md): カット＆ペーストのガジェットでノードを動かしたり、コピー＆ペーストのガジェットやテンプレートでノードの設定をコピーしたりできます。
