---
navigation:
  title: リンクと感謝
  position: 10
---

# リンクと感謝

Logistics Networksを使ってくれてありがとうございます！ 置かれたノード、作られたネットワーク、設定されたチャンネルの一つひとつが、本当に励みになっています。このMODが役に立ったら、コミュニティに参加したり、リポジトリにスターを付けたりして、プロジェクトの成長を手伝ってください。

## コミュニティとソース

- **Discord**: [discord.gg/xTeHR2tdYh](https://discord.gg/xTeHR2tdYh)。助けを求めたり、バグを報告したり、機能を提案したり、作ったものを見せたりするのに参加してください。
- **GitHub**: [github.com/Almana-mc/LogisticsNetworks](https://github.com/Almana-mc/LogisticsNetworks)。ソースを見たり、問題を報告したり、プルリクエストで貢献したりできます。

バグを見つけたりアイデアがあったりしたら、DiscordとGitHubの問題の管理が、いちばん早く見てもらえる場所です。遊んでくれて改めてありがとうございます。
