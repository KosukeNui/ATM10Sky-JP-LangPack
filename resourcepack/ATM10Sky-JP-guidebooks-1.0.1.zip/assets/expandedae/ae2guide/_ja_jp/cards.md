---
navigation:
  parent: expandedae-index.md
  title: アップグレードカード
  icon: auto_complete_card
  position: 5
categories:
  - expandedae
item_ids:
- expandedae:auto_complete_card
- expandedae:pattern_refiller_card
---

## 現在、このMODで追加されるアップグレードカードは以下の2種類のみです

- **自動補完カード**  
  このカードはパターンプロバイダー用のアップグレードです。  
  パターンを押し出した時点で、自動的にクラフトをキャンセルします。  
  _注意：クラフトパターンでは正常に動作せず、問題が発生する可能性があるため注意してください_  
  <ItemImage id="auto_complete_card" />

- **パターン補充カード**  
  このカードは、<ItemLink id="wireless_exp_encoding_terminal" />および  
  <ItemLink id="ae2wtlib:wireless_universal_terminal" />用のアップグレードです。  
  Expanded Encoding Terminalにおいて、空のパターンスロットを自動的に補充します。  

  _注意：このカードは、エンコードボタンがクリックされたタイミングでのみパターン補充を試みます。  
  これは、最もリソース効率の良い方法として設計された挙動です_  
  <ItemImage id="pattern_refiller_card" />
