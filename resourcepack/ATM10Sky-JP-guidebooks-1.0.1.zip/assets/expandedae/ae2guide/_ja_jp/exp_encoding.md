---
navigation:
  parent: expandedae-index.md
  title: 拡張エンコーディングターミナル
  icon: exp_encoding_terminal
  position: 7
categories:
  - expandedae
item_ids:
- expandedae:exp_encoding_terminal
- expandedae:wireless_exp_encoding_terminal
---

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/exp_encoding.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 拡張エンコーディングターミナルは、元のターミナルを拡張するアップグレードで、以下の機能が追加されます

- パターンをエンコードする際、Shiftクリックするとインベントリへ移動する
- ターミナル内に個数倍率ボタンを追加

![pattern_mult_screen.png](assets/pattern_mult_screen.png)
