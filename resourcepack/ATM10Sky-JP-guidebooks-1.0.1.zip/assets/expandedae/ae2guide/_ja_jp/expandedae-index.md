---
navigation:
  title: "アドオン：ExpandedAE"
  position: 150
---

# AppliedE

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/expandedae.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

**ExpandedAE**は、[*Applied Energistics 2*](https://github.com/AppliedEnergistics/Applied-Energistics-2)向けのアドオンです。  
AE2をさらに拡張し、過去のAE2バージョンで提供されていたが現在は失われたQoL（利便性向上）機能を追加します。
