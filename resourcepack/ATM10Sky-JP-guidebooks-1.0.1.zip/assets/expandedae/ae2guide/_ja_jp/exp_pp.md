---
navigation:
  parent: expandedae-index.md
  title: 拡張型パターンプロバイダー
  icon: exp_pattern_provider
  position: 0
categories:
  - expandedae
item_ids:
  - expandedae:exp_pattern_provider
  - expandedae:exp_pattern_provider_part
---

# 拡張型パターンプロバイダー

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/exp_pp.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

### 拡張型パターンプロバイダーは、通常のパターンプロバイダーを大型化したもので、フルブロック版とパーツ版の2種類が存在します。  
### 最大で72個のパターンを格納できます。

![exp_pp_screen.png](assets/exp_pp_screen.png)

## すべてのレシピ

<Row>
  <RecipesFor id="exp_pattern_provider" />
  <RecipesFor id="exp_pattern_provider_part" />
</Row>
