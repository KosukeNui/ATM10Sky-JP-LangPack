---
navigation:
  parent: expandedae-index.md
  title: QoL機能
  icon: expandedae:exp_pattern_provider
  position: 10
categories:
  - expandedae
---

# このMODで追加されるQoL機能一覧

## パターンプロバイダーでのパターン倍率変更
パターンプロバイダーにボタンが追加され、  
内部に格納されているすべてのパターンに対して、  
**一括で倍率を掛ける／割る**ことができます。

__倍率は累積します。__

![modify_patterns.png](assets/modify_patterns.png)

## 追加のブロッキングモード
すべてのパターンプロバイダーに、  
2種類の追加ブロッキングモードが追加されます。

### デフォルト
AE2標準のブロッキングモードです。  
接続先ストレージに、このパターンプロバイダー内の  
**パターン入力に含まれるアイテムが存在しない場合**にパターンを搬出します。  

ストレージ内に、パターン入力以外のアイテムが存在していても、  
それらは無視され、パターンは搬出されます。

![blocking_1.png](assets/blocking/blocking_1.png)

### フル
接続先ストレージ内に**何らかの内容が存在する場合**、  
パターンを一切搬出しないブロッキングモードです。

![blocking_2.png](assets/blocking/blocking_2.png)

### スマート
接続先ストレージに、  
**この特定のパターンの入力要素のみ**が存在する場合に限り、  
同じパターンの搬出を許可します。

![blocking_3.png](assets/blocking/blocking_3.png)
