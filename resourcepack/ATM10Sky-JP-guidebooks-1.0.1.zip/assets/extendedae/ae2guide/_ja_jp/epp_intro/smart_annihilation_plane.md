---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: MEスマート消滅プレーン
    icon: extendedae:smart_annihilation_plane
categories:
- extended devices
item_ids:
- extendedae:smart_annihilation_plane
---

# MEスマート消滅プレーン

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_smart_annihilation_plane.snbt"></ImportStructure>
</GameScene>

MEスマート消滅プレーンは、設定インベントリに従ってブロックを壊したりアイテムを吸い込んだりできる<ItemLink id="ae2:annihilation_plane" />です。

このためにサブネットを組む必要はありません。<ItemLink id="ae2:import_bus" />のように動作しますが、チェストから搬入する代わりにブロックを壊します。
