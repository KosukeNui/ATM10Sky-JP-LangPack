---
navigation:
  title: MEリクエスター
  icon: requester
  position: 100
item_ids:
  - merequester:requester
  - merequester:requester_terminal
---

# MEリクエスター

<Row>
  <ItemImage id="requester" scale="3"/>
  <ItemImage id="requester_terminal" scale="3"/>
</Row>

MEリクエスターは、[MEシステム](ae2:getting-started.md#your-very-first-me-system)内のアイテムや流体を、常に一定量在庫として維持するためのアドオンMODです。  
<br/>

## 導入

まず<ItemLink id="requester"/>を設置し、ネットワークに接続します。  
この際、[自動クラフト](ae2:ae2-mechanics/autocrafting.md)の処理が行われているのと**同じネットワーク**に接続してください。  
そこには、[クラフトCPU](ae2:ae2-mechanics/autocrafting.md#the-crafting-cpu)および<ItemLink id="ae2:pattern_provider"/>が存在している必要があります。

<RecipeFor id="requester"/>

<ItemLink id="requester"/>が機能するためには、  
在庫を維持したいアイテムや流体に対して**パターンが存在し**、  
かつ、プレイヤー自身が要求した場合にもクラフト可能である必要があります。  

リクエスターは「要求の自動化」のみを行います。  
実際のクラフト処理は、[MEシステム](ae2:getting-started.md#your-very-first-me-system)側で行われます。
<br/>

<FloatingImage src="assets/gui.png" align="right"/>

## 設定

<ItemLink id="requester"/>を初めて開くと、リクエスト設定の一覧画面が表示されます。  
1ブロックあたりに保持できるスロット数は、設定ファイルで変更可能です。  
GUIの各行は、それぞれ1つのリクエストを表しています。
<br/>

### トグルスイッチ

左側のチェックボックスで、その行のリクエストを有効／無効に切り替えます。  
無効化されている場合、チェックは行われず、在庫も維持されません。  
<br/>
特定のリクエストを一時的に停止したい場合や、  
設定変更中に<ItemLink id="requester"/>がクラフトジョブを発行しないようにする際に使用できます。
<br/>

### 在庫対象

2列目では、在庫として維持したい対象を指定します。  
これらのスロットはゴーストスロットであり、実際のアイテムは保持されません。  

アイテムをドラッグした場合、  
右クリックで数量を1に設定、左クリックでドラッグ中のスタック数を設定します。  

流体入りバケツをドラッグした場合は、  
右クリックで中身の流体を設定、左クリックでバケツ自体を設定します。  

また、Shiftクリックで素早くアイテム種を設定できます。  
インベントリに対象アイテムがない場合でも、  
Applied Energisticsに対応したレシピビューアからドラッグ＆ドロップできます。
<br/>

### 在庫数量

「在庫数量」欄では、維持したい数量を指定します。  
先に在庫対象を設定し、その後で数値を入力してください。  

アイテム以外のリクエストでは、表示形式が自動で切り替わります。  
例えば、流体の場合は単位として`B`（バケツ）が表示されます。  
<br/>
現在の在庫が指定数を下回ると、<ItemLink id="requester"/>が追加分を要求します。
<br/>

### バッチサイズ

次の入力欄では、在庫不足時に**一度に要求する数量**を指定します。  
<br/>
これにより、[クラフトCPU](ae2:ae2-mechanics/autocrafting.md#the-crafting-cpu)や  
クラフトに使用される機械への負荷を軽減できます。  
指定量をまとめて要求するため、多数の小さなジョブが発行されるのを防げます。
<br/>

### 送信ボタン

「在庫数量」と「バッチサイズ」を入力後、  
Enterキーを押すか、行右側の送信ボタンをクリックすると変更が適用されます。  

別の行をクリックすると、入力中の値は元に戻ります。
<br/>

### ステータスバー

入力欄および送信ボタンの下にあるバーは、  
現在のリクエスト状態を示します。
<br clear="all" />
<br/>

## ステータス一覧

各リクエストには、以下のステータスが表示されます。
<br/>

### グレー：未設定

行が無効、または在庫対象が指定されていません。
<br/>

### 緑：待機中

目標在庫量に達している、または対応するパターンが存在しません。
<br/>

### 赤：素材不足

クラフトに必要な素材が不足しています。  
素材が十分に揃い次第、自動的に再開されます。
<br/>

### 黄：クラフト中

対象のリクエストが現在クラフト中です。  
ジョブの完了を待っています。  
<br/>
この状態の間、該当リクエストの設定はロックされ、変更できません。
<br/>

### 紫：搬出中

クラフト結果をすべて受け取り、  
ストレージへ搬出しようとしています。  
<br/>
通常は一瞬しか表示されませんが、  
長時間続く場合はストレージ容量が不足しています。
<br/>

### ブロックの外観変化

<ItemLink id="requester"/>内に、待機中・未設定以外のステータスを持つリクエストがある場合、  
ブロックの外観が変化します。

<Row>
  <Column>
    非アクティブ
    <BlockImage id="requester" scale="3" p:active="false"/>
  </Column>
  <Column>
    アクティブ
    <BlockImage id="requester" scale="3" p:active="true"/>
  </Column>
</Row>
<br/>

## ターミナル

このMODは、<ItemLink id="requester_terminal"/>という専用ターミナルも追加します。  
同一ネットワーク内のすべての<ItemLink id="requester"/>に、  
1か所からアクセスできます。

このターミナルは<ItemLink id="ae2:pattern_access_terminal"/>と同等の機能を持ち、  
特定のリクエストを検索することも可能です。  

すべての<ItemLink id="requester"/>はデフォルトでは同じ名前を持つため、  
リクエストは1つの見出しにまとめて表示されます。  

<ItemLink id="requester_terminal"/>内で  
<ItemLink id="requester"/>を別グループとして表示したい場合は、  
金床または<ItemLink id="ae2:name_press"/>を使用して名前を変更してください。
