---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: MEスループットモニター
  icon: advanced_ae:throughput_monitor
categories:
  - advanced items
item_ids:
  - advanced_ae:throughput_monitor
  - advanced_ae:throughput_monitor_configurator
---

# MEスループットモニター

<GameScene zoom="8" background="transparent">
<ImportStructure src="../structure/throughput_monitors.snbt"></ImportStructure>
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

スループットモニターは、モニターの一種です。  
<ItemLink id="ae2:storage_monitor" />と同じ機能を持ちますが、スループットメーターが追加されています。  
単一のアイテムまたは流体タイプを追跡し、その数量の変化を監視して、1秒あたりの量をユーザーに表示します。

このモニターはチャンネルを必要としません。

## キー割り当て

* アイテムを持って右クリック、または流体コンテナを持ってダブル右クリックすると、そのアイテム／流体にモニターを設定します。
* 何も持たずに右クリックすると、モニターをクリアします。
* 何も持たずにシフト右クリックすると、モニターをロックします。

## スループットモニター設定ツール

<ItemImage id="advanced_ae:throughput_monitor_configurator" scale="4"></ItemImage>

スループットモニター設定ツールは、表示されるデータを変更するためのツールです。  
これを手に持ってモニターを右クリックすると、次の3つの表示モードが順番に切り替わります。

* ティックあたりのアイテム数
* 秒あたりのアイテム数
* 分あたりのアイテム数

注意：モードを切り替えた直後は、数値が安定するまでに時間がかかる場合があります。  
そのため、初期値は信用しないでください。
