---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 入出力バス
  icon: advanced_ae:import_export_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:import_export_bus_part
---

# 入出力バス

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_import_export_bus.snbt"></ImportStructure>
</GameScene>

入出力バスは、<ItemLink id="ae2:import_bus" />と<ItemLink id="ae2:export_bus" />を組み合わせたものです。
フィルターは搬出されるスタックを設定するために使用されます。
フィルターに含まれていないものは、搬入対象として有効なスタックになります。
