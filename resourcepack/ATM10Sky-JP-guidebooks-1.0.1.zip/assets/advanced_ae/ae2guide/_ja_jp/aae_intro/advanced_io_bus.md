---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 発展型入出力バス
  icon: advanced_ae:advanced_io_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:advanced_io_bus_part
---

# 発展型入出力バス

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_advanced_io_bus.snbt"></ImportStructure>
</GameScene>

発展型入出力バスは、外部インベントリとやり取りするための非常に強力なツールです。
これは<ItemLink id="advanced_ae:import_export_bus_part"/>と<ItemLink id="advanced_ae:stock_export_bus_part"/>を組み合わせて作成されます。
両方の親要素の機能を継承しています。
さらに、発展型入出力バスの基本速度は<ItemLink id="ae2:export_bus"/>の基本速度の8倍です。
最大速度に到達するまでには少し時間がかかりますが、完全にアップグレードされた状態では非常に高速になります。

## 搬出

発展型入出力バスは、フィルターに従って固定量まで搬出し、そこで停止します。
UIの左側には、アイテムの在庫量を調整するかどうかを選択できる設定もあります。

## 搬入

発展型入出力バスは、搬出対象としてフィルターされていないものをすべて搬入します。
搬入と搬出の処理は別々にカウントされるため、どちらか一方の処理で詰まることはありません。
バスが在庫調整を行うように設定されている場合、設定量を超えているアイテムの搬入を優先します。
処理に余裕がある場合は、フィルターされていないものを搬入します。

<RecipeFor id="advanced_ae:advanced_io_bus_part"/>
