---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 発展型パターンプロバイダー
  icon: advanced_ae:adv_pattern_provider
categories:
  - advanced devices
item_ids:
  - advanced_ae:adv_pattern_provider
  - advanced_ae:small_adv_pattern_provider
  - advanced_ae:adv_pattern_provider_part
  - advanced_ae:small_adv_pattern_provider_part
---

# 発展型パターンプロバイダー

<Row gap="20">
<BlockImage id="advanced_ae:adv_pattern_provider" scale="8"></BlockImage>
<BlockImage id="advanced_ae:adv_pattern_provider" p:push_direction="up" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_app_part.snbt"></ImportStructure>
</GameScene>
</Row>

発展型パターンプロバイダーは、<ItemLink id="ae2:pattern_provider" />や<ItemLink id="extendedae:ex_pattern_provider" />を強化した、新しいタイプのパターンプロバイダーです。
このブロックでは、パターン内の**各アイテムごとに**、どの面へ搬出するかを設定できます。
この強力な追加要素により、特定の入力面を必要とする機械の自動化を、**1ブロックのみ・配管なし**で実現できます。

*見てるぞ、Mekanism。*

この機能を使用するには、<ItemLink id="advanced_ae:adv_pattern_encoder" />でエンコード済みパターンを加工し、
<ItemLink id="advanced_ae:adv_processing_pattern" />として取り出したものを挿入する必要があります。

また、1つのパターンプロバイダーに最大36個のパターンを格納できる拡張版も存在します。

![AAEGui](../pic/app_gui.png)
