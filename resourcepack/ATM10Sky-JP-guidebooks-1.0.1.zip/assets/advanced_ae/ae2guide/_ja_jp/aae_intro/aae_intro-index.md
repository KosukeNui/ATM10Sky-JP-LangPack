---
navigation:
  title: Advanced AEのすすめ
  position: 70
---

# Advanced AE!

Advanced AEは、MEシステムを扱う際のユーザー体験を向上させ、エンドゲームシステムの可能性を拡張することに焦点を当てたMODです。
このMODでは、パターンプロバイダーを強化して、対象マシンの特定の面にアイテムを搬出できるようにしたり、
クラフトストレージが残っている限り無制限のクラフトを実行でき、補助プロセッサを共有するマルチブロックコンピュータを作成したりできます。
そのほかにも、多数のQoL（利便性向上）要素が追加されています。

![PEGui1](../pic/aae_intro.png)

提供されるブロックやアイテムの一覧については、以下のガイドページを参照してください。

## Advanced Devices

<CategoryIndex category="advanced devices"></CategoryIndex>

## Advanced Items

<CategoryIndex category="advanced items"></CategoryIndex>

問題を見つけましたか？機能が不足していますか？
以下から報告してください：
[Advanced AE GitHub](https://github.com/pedroksl/AdvancedAE)
