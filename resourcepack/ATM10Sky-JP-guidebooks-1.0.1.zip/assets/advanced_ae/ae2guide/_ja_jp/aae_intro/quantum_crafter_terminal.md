---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 量子クラフトターミナル
  icon: advanced_ae:quantum_crafter_terminal
categories:
  - advanced devices
item_ids:
  - advanced_ae:quantum_crafter_terminal
  - advanced_ae:wireless_quantum_crafter_terminal
---

# 量子クラフトターミナル

<Row gap="20">
<ItemImage id="advanced_ae:quantum_crafter_terminal" scale="4"></ItemImage>
<ItemImage id="advanced_ae:wireless_quantum_crafter_terminal" scale="4"></ItemImage>
</Row>

量子クラフトターミナルを使用すると、1か所からネットワーク内のすべての<ItemLink id="advanced_ae:quantum_crafter"/>を管理できます。  
ワイヤレス版は、移動中に設定を変更する際に便利です。無線アクセスポイントに挿入してグリッドにリンクするだけで、すぐに使用できます。

<Row gap="20">
<RecipeFor id="advanced_ae:quantum_crafter_terminal" />
<RecipeFor id="advanced_ae:wireless_quantum_crafter_terminal" />
</Row>
