---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 量子コンピューター
  icon: advanced_ae:quantum_core
categories:
  - advanced devices
item_ids:
  - advanced_ae:quantum_unit
  - advanced_ae:quantum_core
  - advanced_ae:quantum_structure
  - advanced_ae:quantum_accelerator
  - advanced_ae:quantum_multi_threader
  - advanced_ae:quantum_storage_128
  - advanced_ae:quantum_storage_256
  - advanced_ae:data_entangler
---

# 量子コンピューター

量子コンピューターは、特別な種類のクラフト用コンピューターです。
十分なクラフトストレージがある限り、無制限のクラフト要求を同時に処理できます。

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../structure/quantum_computer_multiblock.snbt"></ImportStructure>
</GameScene>

## 量子コンピューターコア

<BlockImage id="advanced_ae:quantum_core" p:powered="true" p:formed="true" scale="4"></BlockImage>

量子コアは量子コンピューターの中核です。
単体で256Mのクラフトストレージと8本の補助プロセッサスレッドを備えています。
形成済みの量子コンピューターを単体で作成できる唯一のブロックであり、
量子コンピューターのすべての恩恵を提供します。
ただし、マルチブロックとして使用した場合は、さらに強力なコンピューターを構築できます。
単体で使用する場合、電力はコネクタのある上面または下面から供給する必要があります。

## 量子コンピュータストレージ

<Row gap="20">
<BlockImage id="advanced_ae:quantum_storage_128" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_storage_256" scale="4"></BlockImage>
</Row>

これらのブロックは量子コアのクラフトストレージを拡張します。
量子コンピューターが同時に実行できるタスク数を実質的に増加させます。
容量は128Mと256Mの2種類があります。

## 量子データエンタングラー

<BlockImage id="advanced_ae:data_entangler" scale="4"></BlockImage>

データエンタングラーは、マルチブロック内に存在するすべてのストレージブロックに影響を与える特殊なブロックです。
ストレージブロックが複数次元にデータを保存できるようになり、
実質的にストレージ容量が4倍になります。
量子コンピューターマルチブロック1つにつき、1個のみ設置できます。

## 量子コンピューター加速器

<BlockImage id="advanced_ae:quantum_accelerator" scale="4"></BlockImage>

量子コンピューター加速器は、量子コンピューターマルチブロックに
8本の補助プロセッサを追加します。
量子コンピューターで実行されるすべてのクラフトパターンは、
これらの補助プロセッサを共有できるため、
多数設置する価値があります。

## 量子コンピュータ多重スレッド処理装置

<BlockImage id="advanced_ae:quantum_multi_threader" scale="4"></BlockImage>

データエンタングラーと同様に、
多重スレッド処理装置は加速器が別次元で追加スレッドを実行できるようにし、
補助プロセッサ性能を4倍にします。
量子コンピューターマルチブロック1つにつき、1個のみ設置できます。

## 量子コンピューターの構造ガラス

<Row gap="20">
<BlockImage id="advanced_ae:quantum_structure" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_structure" p:formed="true" p:powered="true" scale="4"></BlockImage>
</Row>

これらのブロックは量子コンピューターの外枠を構成します。
量子コンピューターの建材として使用され、全体を接続します。

## マルチブロック

量子コンピューターのマルチブロックを作成するには、以下のルールを満たす必要があります。
- 最大サイズは7×7×7（外寸）
- 内部に空間を作ることはできません。追加効果はありませんが、<ItemLink id="advanced_ae:quantum_unit" />で埋めることができます
- <ItemLink id="advanced_ae:quantum_core" />は必ず1個
- <ItemLink id="advanced_ae:data_entangler" />は最大1個
- <ItemLink id="advanced_ae:quantum_multi_threader" />は最大1個
- 外側の層はすべて<ItemLink id="advanced_ae:quantum_structure" />である必要があります
- 内部に<ItemLink id="advanced_ae:quantum_structure" />を配置することはできません

## サーバー設定

以下の値はサーバー設定で調整できます。
- マルチブロックの最大サイズ
- 各量子コンピューター加速器の補助プロセッサ数
- 量子コンピューター多重スレッド処理装置の最大数
- 多重スレッド処理装置のスレッド倍率
- データエンタングラーの最大数
- データエンタングラーのストレージ倍率

現在の制限値は、アイテムのツールチップから確認できます。
