---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 発展型パターンプロバイダーアップグレードアイテム
  icon: advanced_ae:adv_pattern_provider_upgrade
categories:
  - advanced items
item_ids:
  - advanced_ae:adv_pattern_provider_upgrade
  - advanced_ae:adv_pattern_provider_capacity_upgrade
---

# 発展型パターンプロバイダーアップグレード

パターンやアップグレードをすべて移動することなく、
パターンプロバイダーをアップグレードできるAdvancedAEのプロバイダー用アイテムです。

## 発展型パターンプロバイダーアップグレード

<ItemImage id="advanced_ae:adv_pattern_provider_upgrade" scale="3"></ItemImage>

このアップグレードは、通常のAEパターンプロバイダーおよびExtendedAEの拡張パターンプロバイダーに使用できます。
これらのブロックに使用すると、既存のスロット数を保持したまま発展型バージョンへアップグレードされます。
つまり、通常のプロバイダーを拡張プロバイダーへアップグレードする際に使用した素材を失うことはありません。

## 発展型パターンプロバイダー容量アップグレード

<ItemImage id="advanced_ae:adv_pattern_provider_capacity_upgrade" scale="3"></ItemImage>

容量アップグレードは、通常のパターンプロバイダーを直接、
36個のパターンスロットを持つ発展型パターンプロバイダーへアップグレードするために使用されます。
