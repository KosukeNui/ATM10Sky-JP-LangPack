---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: ストック出力バス
  icon: advanced_ae:stock_export_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:stock_export_bus_part
---

# ストック出力バス

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_stock_export_bus.snbt"></ImportStructure>
</GameScene>

ストック出力バスは、フィルターされたスタックを指定した正確な数量だけ搬出するように設定できます。  
対象インベントリ内に現在存在する数量を常に追跡し、その数を超えて挿入することはありません。

設定するには、GUIを開き、目的のアイテムをフィルタースロットにドラッグし、ホイールクリックを使用して数量を設定します。  
なお、このバスは出力の調整は行いません。つまり、設定した数量を超えた場合でも、余分なアイテムや流体をインベントリから引き出すことはありません。
