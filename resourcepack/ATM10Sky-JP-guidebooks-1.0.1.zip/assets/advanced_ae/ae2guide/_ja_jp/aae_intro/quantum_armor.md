---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 量子アーマーセット
  icon: advanced_ae:quantum_helmet
categories:
  - advanced items
item_ids:
  - advanced_ae:quantum_helmet
  - advanced_ae:quantum_chestplate
  - advanced_ae:quantum_leggings
  - advanced_ae:quantum_boots
  - advanced_ae:quantum_upgrade_base
  - advanced_ae:walk_speed_card
  - advanced_ae:sprint_speed_card
  - advanced_ae:step_assist_card
  - advanced_ae:jump_height_card
  - advanced_ae:lava_immunity_card
  - advanced_ae:flight_card
  - advanced_ae:water_breathing_card
  - advanced_ae:auto_feeding_card
  - advanced_ae:auto_stock_card
  - advanced_ae:magnet_card
  - advanced_ae:hp_buffer_card
  - advanced_ae:evasion_card
  - advanced_ae:regeneration_card
  - advanced_ae:strength_card
  - advanced_ae:attack_speed_card
  - advanced_ae:luck_card
  - advanced_ae:reach_card
  - advanced_ae:swim_speed_card
  - advanced_ae:night_vision_card
  - advanced_ae:flight_drift_card
  - advanced_ae:recharging_card
  - advanced_ae:portable_workbench_card
  - advanced_ae:pick_craft_card
---

# 量子アーマーセット

<Row gap="10">
<ItemImage id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
</Row>

<ItemGrid>
<ItemIcon id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d"></ItemIcon>
</ItemGrid>

AEシステムを身にまとったらどうなるか、考えたことはありませんか？もう想像する必要はありません。量子アーマーセットは、AE2システムに接続して、出先でもあらゆるものへ手軽にアクセスできる、高度な技術でできた隠密性の高い装備です！初期状態では、ネザライト装備に匹敵する防御力を持つ、エネルギーで動くスーツです。バッファのエネルギーを使ってエネルギーシールドを作り、かなりの量のダメージを吸収できます。さらにブーツは落下ダメージを無効にし、チェストプレートは飛行中の採掘速度の低下をなくします。ただし、このスーツの本当の力は、アップグレードを詰め込んではじめて引き出されます！

<br/>

## アーマーのリンク

アーマーの各部位は、<ItemLink id="ae2:wireless_access_point" />の対応するスロットに入れることで、1つずつシステムにリンクできます。これにより、部位と取り付けたアップグレードカードに応じた特典が解放されます。詳しくはあとで説明します。なお、これらの追加機能を正しく働かせるには、接続したアクセスポイントの範囲内にいる必要もあります。

<br/>

## アップグレードの取り付け

アップグレードを取り付けるには、各部位を装備した状態で、ホットキー（初期設定はN）を押して量子アーマー設定メニューを開きます。

![QAGUI](../pic/quantum_armor_config.png)

この画面では、アップグレードの追加・取り外し、オン・オフの切り替え、設定のあるアップグレードの設定ができます。

<br/>

## 量子アップグレードの基礎カード

<ItemImage id="advanced_ae:quantum_upgrade_base" scale="2"></ItemImage>

<ItemLink id="advanced_ae:quantum_upgrade_base" />はそれ自体では特別な効果はありませんが、すべてのアップグレードカードのクラフト材料になります。

<br/>

## 自動食糧補給カード

<ItemImage id="advanced_ae:auto_feeding_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:auto_feeding_card" />を使うと、プレイヤーに食べさせるアイテムを選べます。フィルタースロットに食べさせたいアイテムをドラッグするだけです。装備がAE2のグリッドにリンクされていれば、お腹がすいたときにシステムの中からそのアイテムを探して食べさせます。

<br/>

## オートストックカード

<ItemImage id="advanced_ae:auto_stock_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:auto_stock_card" />も、装備がAE2システムにリンクされていて、アクセスポイントの範囲内にいる必要があります。いくつかのアイテムを、インベントリの中に常に決まった数だけ保つように設定できます。スロットは1スタックに限られないので、望むなら常にインベントリの複数のスロットが埋まるように設定することもできます。

<br/>

## 速度カード

<Row gap="10">
<ItemImage id="advanced_ae:walk_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:sprint_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:swim_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:walk_speed_card" />
* <ItemLink id="advanced_ae:sprint_speed_card" />
* <ItemLink id="advanced_ae:swim_speed_card" />

これらのアップグレードカードは、着用者の移動速度を上げます。どれも速さを設定でき、スニーク中や飛行中の移動にも効果があります。大事な点として、ほかの速度上昇の効果がかかっているときに操作しやすくするため、速度を下げる方向にも使えます。

<br/>

## 高さのカード

<Row gap="10">
<ItemImage id="advanced_ae:jump_height_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:step_assist_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:jump_height_card" />
* <ItemLink id="advanced_ae:step_assist_card" />

これらのアップグレードは上下の移動を変え、設定できるジャンプの高さの上昇や、段差を登る補助を与えます。

<br/>

## 飛行のカード

<Row gap="10">
<ItemImage id="advanced_ae:flight_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:flight_drift_card" scale="2"></ItemImage>
</Row>

### 飛行カード

<ItemLink id="advanced_ae:flight_card" />を取り付けると、クリエイティブ飛行ができるようになります。飛行速度は画面のスライダーで設定できます。歩行速度・スプリント速度のアップグレードの効果も足し合わされます。

### 飛行ドリフトカード

<ItemLink id="advanced_ae:flight_drift_card" />は飛行カードが取り付けられているときだけ働き、クリエイティブ飛行にかかる慣性を変える設定のスライダーを追加します。値が小さいほど早く止まり、0にするとすぐに止まります。

<br/>

## ME再充電カード

<ItemImage id="advanced_ae:recharging_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:recharging_card" />を使うと、装備した部位を無線で充電できます。グリッドへのリンクと、アクセスポイントの範囲内にいることが必要です。チェストプレートに取り付けると、インベントリのスロットも充電されるという利点があります。

<br/>

## ポータブル作業台カード

<ItemImage id="advanced_ae:portable_workbench_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:portable_workbench_card" />は、量子スーツに持ち運べるセル作業台を追加します。開くには、設定したホットキーを押します。ブロック版とまったく同じように使えます。

<br/>

## ピッククラフトカード

<ItemImage id="advanced_ae:pick_craft_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:pick_craft_card" />は、アーマーに新しいホットキーの機能を追加します。押すと、プレイヤーが見ているブロックのクラフトを試みます。この機能には、グリッドへのリンクと、対象に合うパターンが必要です。欲しい数を入力する画面が出て、そのあとは通常の自動クラフトの依頼とまったく同じように進みます。

<br/>

## 便利なカード

<Row gap="10">
<ItemImage id="advanced_ae:night_vision_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:lava_immunity_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:water_breathing_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:magnet_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:camo_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:night_vision_card" />
* <ItemLink id="advanced_ae:lava_immunity_card" />
* <ItemLink id="advanced_ae:water_breathing_card" />
* <ItemLink id="advanced_ae:magnet_card" />
* <ItemLink id="advanced_ae:camo_card" />

これらのカードは、着用者にさまざまな便利な効果を与え、いくつかの種類のダメージを無効にしたり、暗視を与えたりします。特に磁石カードには設定画面があり、拾うもの・拾わないもののフィルターや、範囲を設定できます。

<br/>

## 防御のカード

<Row gap="10">
<ItemImage id="advanced_ae:hp_buffer_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:regeneration_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:evasion_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:hp_buffer_card" />
* <ItemLink id="advanced_ae:regeneration_card" />
* <ItemLink id="advanced_ae:evasion_card" />

これらのアップグレードは、さまざまな形で着用者の守りを固めます。HPのカードは最大体力を増やし、再生カードは体力の回復速度を上げます。回避カードは、一定の確率であらゆるダメージを完全に無効にします。

<br/>

## 攻撃のカード

<Row gap="10">
<ItemImage id="advanced_ae:strength_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:attack_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:strength_card" />
* <ItemLink id="advanced_ae:attack_speed_card" />

これらのアップグレードは、着用者の攻撃能力を上げます。攻撃力と攻撃速度が上がります。

<br/>

## ステータスのカード

<Row gap="10">
<ItemImage id="advanced_ae:luck_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:reach_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:luck_card" />
* <ItemLink id="advanced_ae:reach_card" />

これらのアップグレードカードは、着用者のステータスを一定量上げます。ドロップの抽選がよくなる幸運と、ブロックに手が届く距離に効果があります。リーチカードは、好きな値に設定できます。

<br/>

## 今後の予定

この装備セットは基本形としてリリースされたもので、ほかにもたくさんの機能が追加される予定です。お楽しみに！
