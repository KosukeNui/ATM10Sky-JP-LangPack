---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 発展型パターンエンコーダー
  icon: advanced_ae:adv_pattern_encoder
categories:
  - advanced items
item_ids:
  - advanced_ae:adv_pattern_encoder
  - advanced_ae:adv_processing_pattern
---

# 発展型パターンエンコーダー

ME発展型パターンプロバイダーに、アイテムの送り先を教えるためには、その情報をエンコードする特別な装置が必要です。
この装置を手に持って右クリックすると、GUIを開くことができます。

<ItemImage id="advanced_ae:adv_pattern_encoder" scale="4"></ItemImage>

エンコード済みの加工パターンは左側のスロットに挿入できます。
挿入されたパターンはデコードされ、すべての原材料が一覧として表示されます。

![PEGui1](../pic/ape_pattern.png)

各行には、材料を送信できるすべてのブロック面を表すボタン群が配置されています。
選択を「A」ボタンのままにすると、材料はパターンプロバイダーに直接接続されている面に送られます。
特定の面を選択した場合、その面に強制的にアイテムが搬入されます。
なお、発展型パターンは<ItemLink id="advanced_ae:adv_pattern_provider" />によってのみ正しくデコードでき、
他の種類のパターンプロバイダーで使用した場合は、通常のパターンとして振る舞います。
また、指定された面に単一のアイテムでも挿入できない場合、方向指定による搬入は行われず、
標準のパターンプロバイダーの挙動が適用されます。
