---
navigation:
  title: "Little Big Redstone"
  position: 0
---

# Little Big Redstone

<MarginFloatingImage src="assets/logo.png" left="0" right="10" />

Little Big Redstoneは、[ロジック](logic/introduction.md)を中に置ける[マイクロチップ](microchips.md)のブロックを追加します。複雑なロジックの仕組みを、1つのブロックにまとめられます。

これには、[NOT](logic/not_gate.md)・[AND](logic/and_gate.md)・[OR](logic/or_gate.md)などのふつうのロジックゲートが含まれます。[シーケンサー](logic/sequencer.md)や[パルス調整器](logic/pulse_throttler.md)のように、信号を遅らせたり、短くしたり、長くしたりするのに使えるロジックの部品もあります。

マイクロチップでの作業を楽にする道具もあります。マイクロチップで使うアイテムをしまっておける[ロジックアレイ](logic_arrays.md)や、回路をコピーして貼り付けられる[フロッピーディスク](floppy_disks.md)です。

どのアイテムも全部の染料の色があるので、自分らしく飾ったり、整理したりできます！
