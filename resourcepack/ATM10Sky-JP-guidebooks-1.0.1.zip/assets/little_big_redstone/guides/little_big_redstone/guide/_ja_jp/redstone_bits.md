---
navigation:
  title: "レッドストーンビット"
  icon: "redstone_bit"
  position: 2
item_ids:
  - little_big_redstone:redstone_bit
---

# レッドストーンビット

<FloatingColumn align="right">
	<PaddedBox left="5">
		<RecipeFor id="redstone_bit" />
	</PaddedBox>
</FloatingColumn>

<FloatingColumn>
	<ItemImage id="redstone_bit" scale="2" />
</FloatingColumn>

レッドストーンビットは、ポートどうしをつなぐ配線を作るのに使います。ポートとは、[ロジック](logic/introduction.md)の横に出ている三角の出っぱりのことです。出力のポートはいつもロジックの右側に、入力のポートはいつもロジックの左側にあります。

1つの入力のポートにつなげる配線は、ちょうど1本です。出力のポートからは、配線を何本でも出せます。何本もの配線を1つの入力のポートにまとめたいときは、[ORゲート](logic/or_gate.md)を使います。

レッドストーンビットは、ふつうのレッドストーンダストと同じように、0〜15の信号の強さを持ちます。もちろん、信号の強さが0なら配線はオフで、1以上はオンとみなされます。

### 配線の使い方

出力のポートを左クリックし、次につなげたい入力のポートを左クリックすると、配線ができます。持っている配線は、右クリックで捨てられます。置いたあとの配線も、左クリックで拾えます。

配線1本につきレッドストーンビットをちょうど1つ使い、ビットは配線を入力のポートにつないだときにだけ消費されます。
