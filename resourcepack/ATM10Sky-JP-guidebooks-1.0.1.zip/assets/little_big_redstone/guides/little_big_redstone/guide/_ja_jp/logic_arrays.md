---
navigation:
  title: "ロジックアレイ"
  icon: "red_logic_array"
  position: 3
item_ids:
  - little_big_redstone:white_logic_array
  - little_big_redstone:light_gray_logic_array
  - little_big_redstone:gray_logic_array
  - little_big_redstone:black_logic_array
  - little_big_redstone:brown_logic_array
  - little_big_redstone:red_logic_array
  - little_big_redstone:orange_logic_array
  - little_big_redstone:yellow_logic_array
  - little_big_redstone:lime_logic_array
  - little_big_redstone:green_logic_array
  - little_big_redstone:cyan_logic_array
  - little_big_redstone:light_blue_logic_array
  - little_big_redstone:blue_logic_array
  - little_big_redstone:purple_logic_array
  - little_big_redstone:magenta_logic_array
  - little_big_redstone:pink_logic_array
---

# ロジックアレイ

<FloatingColumn align="right">
	<PaddedBox left="5">
		<RecipeFor id="red_logic_array" />
	</PaddedBox>
</FloatingColumn>

<FloatingColumn>
	<PaddedBox left="5" right="10" bottom="0">
		<Row gap="1">
			<ItemImage id="red_logic_array" />
			<ItemImage id="orange_logic_array" />
			<ItemImage id="yellow_logic_array" />
			<ItemImage id="lime_logic_array" />
		</Row>
		<Row gap="1">
			<ItemImage id="green_logic_array" />
			<ItemImage id="cyan_logic_array" />
			<ItemImage id="light_blue_logic_array" />
			<ItemImage id="blue_logic_array" />
		</Row>
		<Row gap="1">
			<ItemImage id="purple_logic_array" />
			<ItemImage id="magenta_logic_array" />
			<ItemImage id="pink_logic_array" />
			<ItemImage id="brown_logic_array" />
		</Row>
		<Row gap="1">
			<ItemImage id="white_logic_array" />
			<ItemImage id="light_gray_logic_array" />
			<ItemImage id="gray_logic_array" />
			<ItemImage id="black_logic_array" />
		</Row>
	</PaddedBox>
</FloatingColumn>

ロジックアレイには、[ロジック](logic/introduction.md)・[レッドストーンビット](redstone_bits.md)・[付箋](sticky_notes.md)を入れられます。インベントリの場所を節約でき、回路を作るときにすぐ取り出せます。

### インベントリ

ロジックアレイには28個の枠があります。ロジックアレイを手に持って**<KeyBind id="key.use" />**を押すと、インベントリが開きます。[マイクロチップ](microchips.md)のメニューを開いているあいだは、インベントリにあるどのロジックアレイの中身も見られます。標準では、インベントリの最初のロジックアレイが選ばれて表示されます。マイクロチップのメニューでは、いつでもロジックアレイのどれかを左クリックすると、それを選べます。こうして、ロジックアレイを何個も持ち、回路を作りながらそのすべてを使えます。

下は、ロジックアレイのメニューがどう見えるかの2つの例です。左はロジックアレイだけを開いたとき、右はマイクロチップの中でロジックアレイを開いたときです。

<FloatingImage src="assets/logic_array_menu.png" />

<FloatingImage src="assets/logic_array_in_microchip_menu.png" />
