---
navigation:
  title: "入出力ポート"
  icon: "io"
  parent: little_big_redstone:logic.md
  position: 10
categories:
  - logic
item_ids:
  - little_big_redstone:io
---

# 入出力ポート

<FloatingColumn width="100" align="right">
	### アナログ
	入出力ポートは、入力の信号と同じ値の出力の信号を出します。
</FloatingColumn>

<RecipeFor id="io" />

入出力ポートは、回路にレッドストーンの信号を入力したり、回路から出力したりするためのものです。回路に入出力ポートを置くと、マイクロチップのブロックの面に、レッドストーンの信号を受けたり出したりする、レッドストーンの面が見えるようになります。

<br />

それぞれの入出力ポートには、つながる向きがあります。<Color color="#4CFF00">北</Color>・<Color color="#0094FF">南</Color>・<Color color="#FF0000">東</Color>・<Color color="#FF6A00">西</Color>・<Color color="#FFFFFF">上</Color>・<Color color="#FFD800">下</Color>です。しゃがんでマイクロチップを見ると、その面に向きの色が見えます。

**メモ:** それぞれの向きは、入力か出力のどちらか一方にしかなれず、両方にはなれません。同じ面で、片方が入力、もう片方が出力になるように入出力ポートを回路に置くと、どちらのポートも動かず、警告の印が出ます。

<br />

入出力ポートの信号の強さも設定できます。ポートが入力のモードのときは、入力されたレッドストーンの信号がその強さ以上でないと、ポートはオンの出力を出しません。ポートが出力のモードで、入力のポートにオンの信号が来ると、出すレッドストーンの信号は設定した信号の強さになります。

<Row>
	<Column>
		<MicrochipScene color="red" marginWidth="16" includeToolbar={true}>
			<Logic name="input" x="0" y="0" type="io" />
			<Logic name="output" x="32" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

			<Wire from="input" fromPort="0" to="output" toPort="0" />
		</MicrochipScene>
	</Column>
	
	<Column>
		<MicrochipScene color="red" marginWidth="16" includeToolbar={true}>
			<Logic name="input" x="0" y="0" type="io" hide={true} />
			<Logic name="output" x="32" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" />
		
			<Wire from="input" fromPort="0" to="output" toPort="0" />
		</MicrochipScene>
	</Column>
</Row>
