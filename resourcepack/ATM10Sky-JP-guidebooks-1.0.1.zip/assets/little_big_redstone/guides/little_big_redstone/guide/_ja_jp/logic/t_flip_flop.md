---
navigation:
  title: "Tフリップフロップ"
  icon: "t_flip_flop"
  parent: little_big_redstone:logic.md
  position: 25
categories:
  - logic
item_ids:
  - little_big_redstone:t_flip_flop
---

# Tフリップフロップ

<FloatingColumn width="100" align="right">
	### アナログ
	Tフリップフロップは、自分をオンにした入力の信号と同じ値の出力の信号を出します。
</FloatingColumn>

<Row>
	<Column>
		<RecipeFor id="t_flip_flop" />
	</Column>

	<Column>
		<GameScene zoom="1.48" padding="3" interactive={true}>
			<ImportStructure src="../assets/structures/t_flip_flop.snbt" />
			<IsometricCamera yaw="150" pitch="30" />
		</GameScene>
	</Column>
</Row>

Tフリップフロップは、新しいオンの入力の信号を受けるたびに、出力の状態を入れ替えるだけのロジックの部品です。

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="1" x="0" y="0" type="io" hide={true} />
	<Logic name="2" x="32" y="0" type="t_flip_flop" />
	<Logic name="3" x="64" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="1" fromPort="0" to="2" toPort="0" />
	<Wire from="2" fromPort="0" to="3" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="0" />
</MicrochipScene>
