---
navigation:
  title: "コンパレーター"
  icon: "comparator"
  parent: little_big_redstone:logic.md
  position: 23
categories:
  - logic
item_ids:
  - little_big_redstone:comparator
---

# コンパレーター

<FloatingColumn width="100" align="right">
	### アナログ
	コンパレーターは、比べる相手の値と同じ出力の信号を出します。これは、設定で決めた一定の値か、コンパレーターを「通す」にしたときは、最初の入力の値です。
</FloatingColumn>

<RecipeFor id="comparator" />

コンパレーターは、1〜10個の入力（B₁〜B₁₀）の信号の強さを、別の信号の強さ（A）と比べられるロジックの部品です。コンパレーターのモードの設定で、出力がオンになるのに、比較に合う必要があるのが入力のすべてか、1つだけでよいかが決まります。出力がオンのとき、出力の信号の強さは、出力の上書きの設定の信号の強さになります。出力の上書きの設定を「通す」にすると、出力の信号は入力Aと等しくなります。

信号の強さを「通す」にすると、コンパレーターに入力A用の入力のポートを付けられます。かわりに、比較に使う一定の信号を設定することもでき、その場合は入力A用の入力のポートはありません。

信号の強さを比べるほかのロジックの部品と同じように、コンパレーターでは、値が入力A以上・入力Aと等しい・入力A以下のどれである必要があるかを設定できます。

<Row>
	<Column>
		<MicrochipScene color="red" includeToolbar={true}>
			<Logic name="a" x="0" y="4" type="io" data="{config:{direction:'east'}}" hide={true} />
			<Logic name="b" x="16" y="12" type="io" data="{config:{direction:'west'}}" hide={true} />
			<Logic name="comparator" x="48" y="8" type="comparator" />
			<Logic name="output" x="80" y="8" type="io" data="{config:{input:false,signal_strength:15}}" hide={true} />

			<Wire from="a" fromPort="0" to="comparator" toPort="0" />
			<Wire from="b" fromPort="0" to="comparator" toPort="1" />
			<Wire from="comparator" fromPort="0" to="output" toPort="0" />

			<RedstoneSignal step="0" direction="east" strength="0" />
			<RedstoneSignal step="0" direction="west" strength="0" />

			<RedstoneSignal step="1" direction="east" strength="0" />
			<RedstoneSignal step="1" direction="west" strength="15" />

			<RedstoneSignal step="2" direction="east" strength="15" />
			<RedstoneSignal step="2" direction="west" strength="0" />

			<RedstoneSignal step="3" direction="east" strength="15" />
			<RedstoneSignal step="3" direction="west" strength="15" />
		</MicrochipScene>
	</Column>

	<Column>
		<MicrochipScene color="red" includeToolbar={true}>
			<Logic name="a" x="0" y="0" type="io" data="{config:{direction:'east'}}" hide={true} />
			<Logic name="comparator" x="32" y="0" type="comparator" data="{config:{signal_strength:15}}" />
			<Logic name="output" x="64" y="0" type="io" data="{config:{input:false,signal_strength:15}}" hide={true} />

			<Wire from="a" fromPort="0" to="comparator" toPort="0" />
			<Wire from="comparator" fromPort="0" to="output" toPort="0" />

			<RedstoneSignal step="0" direction="east" strength="0" />

			<RedstoneSignal step="1" direction="east" strength="10" />

			<RedstoneSignal step="2" direction="east" strength="15" />
		</MicrochipScene>
	</Column>

	<Column>
		<MicrochipScene color="red" includeToolbar={true}>
			<Logic name="a" x="0" y="-5" type="io" data="{config:{direction:'north'}}" hide={true} />
			<Logic name="b" x="0" y="0" type="io" data="{config:{direction:'south'}}" hide={true} />
			<Logic name="c" x="0" y="5" type="io" data="{config:{direction:'east'}}" hide={true} />
			<Logic name="comparator" x="32" y="0" type="comparator" data="{config:{signal_strength:15,inputs:3}}" />
			<Logic name="output" x="64" y="0" type="io" data="{config:{input:false,signal_strength:15}}" hide={true} />

			<Wire from="a" fromPort="0" to="comparator" toPort="0" />
			<Wire from="b" fromPort="0" to="comparator" toPort="1" />
			<Wire from="c" fromPort="0" to="comparator" toPort="2" />
			<Wire from="comparator" fromPort="0" to="output" toPort="0" />

			<RedstoneSignal step="0" direction="north" strength="10" />
			<RedstoneSignal step="0" direction="south" strength="0" />
			<RedstoneSignal step="0" direction="east" strength="0" />

			<RedstoneSignal step="1" direction="north" strength="10" />
			<RedstoneSignal step="1" direction="south" strength="0" />
			<RedstoneSignal step="1" direction="east" strength="10" />

			<RedstoneSignal step="2" direction="north" strength="10" />
			<RedstoneSignal step="2" direction="south" strength="15" />
			<RedstoneSignal step="2" direction="east" strength="15" />

			<RedstoneSignal step="3" direction="north" strength="15" />
			<RedstoneSignal step="3" direction="south" strength="15" />
			<RedstoneSignal step="3" direction="east" strength="15" />
		</MicrochipScene>
	</Column>
</Row>