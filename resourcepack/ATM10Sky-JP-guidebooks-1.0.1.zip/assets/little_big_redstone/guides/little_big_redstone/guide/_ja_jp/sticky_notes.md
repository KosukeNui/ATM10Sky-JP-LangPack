---
navigation:
  title: "付箋"
  icon: "red_sticky_note"
  position: 5
item_ids:
  - little_big_redstone:white_sticky_note
  - little_big_redstone:light_gray_sticky_note
  - little_big_redstone:gray_sticky_note
  - little_big_redstone:black_sticky_note
  - little_big_redstone:brown_sticky_note
  - little_big_redstone:red_sticky_note
  - little_big_redstone:orange_sticky_note
  - little_big_redstone:yellow_sticky_note
  - little_big_redstone:lime_sticky_note
  - little_big_redstone:green_sticky_note
  - little_big_redstone:cyan_sticky_note
  - little_big_redstone:light_blue_sticky_note
  - little_big_redstone:blue_sticky_note
  - little_big_redstone:purple_sticky_note
  - little_big_redstone:magenta_sticky_note
  - little_big_redstone:pink_sticky_note
---

# 付箋

<FloatingColumn align="right">
	<PaddedBox left="5">
		<RecipeFor id="red_sticky_note" />
	</PaddedBox>
</FloatingColumn>

<FloatingColumn>
	<PaddedBox left="5" right="10" bottom="5">
		<Row gap="1">
			<ItemImage id="red_sticky_note" />
			<ItemImage id="orange_sticky_note" />
			<ItemImage id="yellow_sticky_note" />
			<ItemImage id="lime_sticky_note" />
		</Row>
		<Row gap="1">
			<ItemImage id="green_sticky_note" />
			<ItemImage id="cyan_sticky_note" />
			<ItemImage id="light_blue_sticky_note" />
			<ItemImage id="blue_sticky_note" />
		</Row>
		<Row gap="1">
			<ItemImage id="purple_sticky_note" />
			<ItemImage id="magenta_sticky_note" />
			<ItemImage id="pink_sticky_note" />
			<ItemImage id="brown_sticky_note" />
		</Row>
		<Row gap="1">
			<ItemImage id="white_sticky_note" />
			<ItemImage id="light_gray_sticky_note" />
			<ItemImage id="gray_sticky_note" />
			<ItemImage id="black_sticky_note" />
		</Row>

		<PaddedBox left="2" top="10">
			<GameScene zoom="3.3" padding="0" background="transparent">
				<Entity id="little_big_redstone:sticky_note" x="0.75" y="0.75" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:' ',TextColor:15,Color:14,Facing:0,AttachedFace:2,Quadrant:0}" />
				<Entity id="little_big_redstone:sticky_note" x="0.25" y="0.75" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:1,Facing:0,AttachedFace:2,Quadrant:1}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.75" y="0.75" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:4,Facing:0,AttachedFace:2,Quadrant:0}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.25" y="0.75" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:5,Facing:0,AttachedFace:2,Quadrant:1}" />

				<Entity id="little_big_redstone:sticky_note" x="0.75" y="0.25" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:13,Facing:0,AttachedFace:2,Quadrant:2}" />
				<Entity id="little_big_redstone:sticky_note" x="0.25" y="0.25" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:' ',TextColor:15,Color:9,Facing:0,AttachedFace:2,Quadrant:3}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.75" y="0.25" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:3,Facing:0,AttachedFace:2,Quadrant:2}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.25" y="0.25" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:11,Facing:0,AttachedFace:2,Quadrant:3}" />
	
				<Entity id="little_big_redstone:sticky_note" x="0.75" y="-0.75" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:10,Facing:0,AttachedFace:2,Quadrant:0}" />
				<Entity id="little_big_redstone:sticky_note" x="0.25" y="-0.75" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:2,Facing:0,AttachedFace:2,Quadrant:1}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.75" y="-0.75" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:' ',TextColor:15,Color:6,Facing:0,AttachedFace:2,Quadrant:0}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.25" y="-0.75" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:12,Facing:0,AttachedFace:2,Quadrant:1}" />
	
				<Entity id="little_big_redstone:sticky_note" x="0.75" y="-0.25" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:0,Facing:0,AttachedFace:2,Quadrant:2}" />
				<Entity id="little_big_redstone:sticky_note" x="0.25" y="-0.25" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:8,Facing:0,AttachedFace:2,Quadrant:3}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.75" y="-0.25" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:'',Color:7,Facing:0,AttachedFace:2,Quadrant:2}" />
				<Entity id="little_big_redstone:sticky_note" x="-0.25" y="-0.25" z="0.96875" rotationY="180" rotationX="0" data="{StickyNote:' ',TextColor:0,Color:15,Facing:0,AttachedFace:2,Quadrant:3}" />
	
				<IsometricCamera yaw="180" pitch="0" />
			</GameScene>
		</PaddedBox>
	</PaddedBox>
</FloatingColumn>

付箋は、額縁と同じようにワールドに置けるアイテムです。ブロックのそれぞれの面に、色と向きを自由に組み合わせて、4枚の付箋を置けます。

さらに付箋は、[ロジック](logic/introduction.md)を置くのと同じように、[マイクロチップ](microchips.md)の中にも置けます。こうして付箋を使うと、ロジックをもっと整理できます。マイクロチップの中に置いた付箋は、右クリックで編集できます。

### 読む・編集する

付箋の文字を見るには、付箋に**<KeyBind id="key.use" />**を使います。付箋を開いたら、編集のボタンを押して文字を編集できます。かわりに、付箋に**<KeyBind id="key.sneak" />**と**<KeyBind id="key.use" />**を押すと、編集のメニューが直接開きます。付箋は、壊して置き直しても、文字と色が残ります。

ワールドの付箋に文字の線が出るのは、文字が書かれているときだけです。

付箋は、看板と同じようにハニカムで封印できます。封印した付箋は、もう編集できません。付箋とハニカムをクラフトするか、ハニカムを持ってワールドに置いた付箋に**<KeyBind id="key.sneak" />**と**<KeyBind id="key.use" />**を使うと封印できます。

### マークダウン

付箋に書く文字は、基本的なマークダウンの機能に対応しています:

\**斜体*\*、\*\***太字**\*\*、\_\_<Underlined>下線</Underlined>\_\_、\~\~~取り消し線~\~\~

ロジックの部品の記号は、置き換えの書き方で付箋に書けます。出したいロジックの部品のIDを、小なりと大なりの記号で囲んで書くだけです。たとえば: \<io\> \<not_gate\> \<and_gate\>

行の先頭にハイフン（\-）かアスタリスク（\*）と空白を書くと、箇条書きも作れます。行の先頭の空白はいくつでもよく、字下げした項目を作れます。さらに、箇条書きの記号のあとの空白に続けて\[ \]か\[x\]を書くと、チェックボックスを付けられます。たとえば:

\- ふつうの項目。

\- \[ \] チェックしていないボックスの項目。

\- \[x\] チェックしたボックスの項目。

### 色付け

付箋の文字は、染料を持って**<KeyBind id="key.sneak" />**と**<KeyBind id="key.use" />**を押すと色を付けられます。

同じように、水入りバケツか雪玉を使うと、ロジックの部品の色を消せます。雪玉は消費されますが、水入りバケツは消費されません。

文字の色は、ワールドでも、見る・編集するメニューでも出ます。

### アイテムの表示

ワールドで**<KeyBind id="key.use" />**を使うと、付箋にアイテムを置けます。付箋には、文字の線のかわりにアイテムが出ます。アイテムは付箋の文字の色に染まって出ます。ただし、文字の色がその色の付箋の標準の色なら、染まりません。

### 付箋ボード

付箋ボードは、ワールドの付箋を見たときに画面のどこに出すかを動かしたり、作った付箋を画面にピン留めしたりできるメニューです！ 「付箋ボードを開く」のキー（**<KeyBind id="key.little_big_redstone.open_note_board" />**）で付箋ボードを開きます。インベントリにある付箋を、メニューの好きな場所に置けます。付箋ボードにピン留めした付箋も、**右ボタン**で編集できます。カーソルに持った付箋は、スクロールホイールで大きさを変えられます。付箋ボードの付箋は、ワールドごと・プレイヤーごとに保存されます。死んでも、付箋ボードから付箋は消えません。
