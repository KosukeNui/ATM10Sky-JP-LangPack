---
navigation:
  title: "フロッピーディスク"
  icon: "red_floppy_disk"
  position: 4
item_ids:
  - little_big_redstone:white_floppy_disk
  - little_big_redstone:light_gray_floppy_disk
  - little_big_redstone:gray_floppy_disk
  - little_big_redstone:black_floppy_disk
  - little_big_redstone:brown_floppy_disk
  - little_big_redstone:red_floppy_disk
  - little_big_redstone:orange_floppy_disk
  - little_big_redstone:yellow_floppy_disk
  - little_big_redstone:lime_floppy_disk
  - little_big_redstone:green_floppy_disk
  - little_big_redstone:cyan_floppy_disk
  - little_big_redstone:light_blue_floppy_disk
  - little_big_redstone:blue_floppy_disk
  - little_big_redstone:purple_floppy_disk
  - little_big_redstone:magenta_floppy_disk
  - little_big_redstone:pink_floppy_disk
---

# フロッピーディスク

<FloatingColumn align="right">
	<PaddedBox left="5">
		<RecipeFor id="red_floppy_disk" />
	</PaddedBox>
</FloatingColumn>

<FloatingColumn>
	<PaddedBox left="5" right="10" bottom="0">
		<Row gap="1">
			<ItemImage id="red_floppy_disk" />
			<ItemImage id="orange_floppy_disk" />
			<ItemImage id="yellow_floppy_disk" />
			<ItemImage id="lime_floppy_disk" />
		</Row>
		<Row gap="1">
			<ItemImage id="green_floppy_disk" />
			<ItemImage id="cyan_floppy_disk" />
			<ItemImage id="light_blue_floppy_disk" />
			<ItemImage id="blue_floppy_disk" />
		</Row>
		<Row gap="1">
			<ItemImage id="purple_floppy_disk" />
			<ItemImage id="magenta_floppy_disk" />
			<ItemImage id="pink_floppy_disk" />
			<ItemImage id="brown_floppy_disk" />
		</Row>
		<Row gap="1">
			<ItemImage id="white_floppy_disk" />
			<ItemImage id="light_gray_floppy_disk" />
			<ItemImage id="gray_floppy_disk" />
			<ItemImage id="black_floppy_disk" />
		</Row>
	</PaddedBox>
</FloatingColumn>

フロッピーディスクを使うと、[マイクロチップ](microchips.md)のプログラムを保存して、かんたんに別のマイクロチップにインストールできます。

フロッピーディスクを持ってマイクロチップに**<KeyBind id="key.sneak" />**＋**<KeyBind id="key.use" />**を押すと、マイクロチップのプログラムがフロッピーディスクに保存されます。

フロッピーディスクにプログラムを保存したら、必要なロジックの部品とレッドストーンビットを持っていれば、マイクロチップに**<KeyBind id="key.use" />**を押してインストールできます。フロッピーディスクをオフハンドに持ってマイクロチップを置いたときも、同じことができます。プログラムをインストールするとき、[ロジックアレイ](logic_arrays.md)の中のアイテムも、インベントリのアイテムとして数えられます。フロッピーディスクを持ってマイクロチップを見ると、プログラムのインストールに必要なアイテムがホットバーの上に出ます。

プログラムは、自分のパソコンに保存したり、そこから読み込んだりもできます！ フロッピーディスクを持って（マイクロチップを見ていない状態で）**<KeyBind id="key.use" />**を押すと、そのためのメニューが開きます。「保存」のボタンは、今保存しているプログラムを、「プログラムの名前」の入力欄に書いた名前のファイルに保存します。同じように、「読み込む」のボタンは、書いた名前のファイルからプログラムを読み込みます。その名前のファイルがなければ、「読み込む」のボタンは押せません。保存したプログラムは、ゲームのフォルダの中の**/little_big_redstone/microchips**フォルダに入ります。これらのファイルは、どのワールドやサーバーからでも使えます。
