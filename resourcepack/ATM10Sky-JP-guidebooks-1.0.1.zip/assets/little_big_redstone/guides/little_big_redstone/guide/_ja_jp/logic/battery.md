---
navigation:
  title: "バッテリー"
  icon: "battery"
  parent: little_big_redstone:logic.md
  position: 13
categories:
  - logic
item_ids:
  - little_big_redstone:battery
---

# バッテリー

<FloatingColumn width="100" align="right">
	### アナログ
	バッテリーの出力の信号は、設定した信号の強さになります。信号は0〜15の範囲を超えません。
</FloatingColumn>

<Row>
	<Column>
		<RecipeFor id="battery" />
	</Column>

	<Column>
		<GameScene zoom="1.48" padding="3" interactive={true}>
			<ImportStructure src="../assets/structures/battery.snbt" />
			<IsometricCamera yaw="150" pitch="30" />
		</GameScene>
	</Column>
</Row>

バッテリーは、とてもかんたんなロジックの部品です。出力の信号の強さは、いつも設定した信号の強さの値になります。

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="battery" x="0" y="0" type="battery" />
	<Logic name="output" x="32" y="0" type="io" data="{config:{input:false,signal_strength:15}}" hide={true} />

	<Wire from="battery" fromPort="0" to="output" toPort="0" />
</MicrochipScene>
