---
navigation:
  title: "タグ"
  icon: "tag"
  parent: little_big_redstone:logic.md
  position: 12
categories:
  - logic
item_ids:
  - little_big_redstone:tag
---

# タグ

<FloatingColumn width="100" align="right">
	### アナログ
	タグは、入力の信号と同じ値の出力の信号を出します。入力がいくつもあるとき（基準が1より大きいときなど）は、いちばん強い信号の値が使われます。
</FloatingColumn>

<RecipeFor id="tag" />

タグを使うと、回路のあいだで信号を無線で送れます。タグにはセンサーとエミッターの2つのモードがあります。センサーは信号を受け取るもので、エミッターは信号を送るものです。

<br />

それぞれのタグにはラベルを設定できます。センサーがエミッターを感知するには、両方が同じラベルを持っている必要があります。ラベルは**大文字と小文字を区別します**。ラベルは必須ではなく、空のままにすると、同じくラベルが空のほかのタグとだけ合います。

センサーには基準の設定があり、オンの出力を出すのに、いくつのエミッターを感知する必要があるかを決めます。たとえば、基準が2でラベルが「something」のセンサーなら、センサーがオンの出力を出すには、同じく「something」のラベルを持ち、オンになっているエミッターが2つ必要です。

センサーは、同じ回路の中のエミッターも感知できることに気をつけてください。

<br />

センサーは、全体にするかどうかも選べます。つまり、マルチプレイのサーバーで、ほかの人が置いたエミッターも感知するかどうかです。標準では、センサーは全体ではありません。つまり、自分のエミッターだけを感知します。

<br />

下は、タグのエミッターとセンサーが同じラベルを持っている例です。ラベルが同じで、センサーの基準が1だけなので、エミッターがオンのとき、センサーもオンになります。

<Row>
	<Column>
		<MicrochipScene color="red" marginWidth="16" includeToolbar={true}>
			<Logic name="input1" x="0" y="0" type="io" hide={true} />
			<Logic name="output1" x="32" y="0" type="tag" data="{config:{input:false,label:'something'}}" />

			<Logic name="tag2" x="64" y="0" type="tag" data="{config:{label:'something'}}" />
			<Logic name="input2" x="64" y="0" type="io" data="{config:{direction:'south'}}" hide={true} />
			<Logic name="output2" x="96" y="0" type="io" data="{config:{input:false,direction:'east',signal_strength:15}}" hide={true} />

			<Wire from="input1" fromPort="0" to="output1" toPort="0" />
			<Wire from="input2" fromPort="0" to="output2" toPort="0" />

			<RedstoneSignal step="0" direction="north" strength="15" />
			<RedstoneSignal step="0" direction="south" strength="15" />
			<RedstoneSignal step="1" direction="north" strength="0" />
			<RedstoneSignal step="1" direction="south" strength="0" />
		</MicrochipScene>
	</Column>
</Row>

下では、2つのタグのラベルが違うことに注目してください。そのため、センサーはエミッターを感知しません。

<Row>
	<Column>
		<MicrochipScene color="red" marginWidth="16" includeToolbar={true}>
			<Logic name="input1" x="0" y="0" type="io" hide={true} />
			<Logic name="output1" x="32" y="0" type="tag" data="{config:{input:false,label:'something'}}" />

			<Logic name="input2" x="64" y="0" type="tag" data="{config:{label:'something_else'}}" />
			<Logic name="output2" x="96" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

			<Wire from="input1" fromPort="0" to="output1" toPort="0" />
			<Wire from="input2" fromPort="0" to="output2" toPort="0" />

			<RedstoneSignal step="0" direction="north" strength="15" />
			<RedstoneSignal step="1" direction="north" strength="0" />
		</MicrochipScene>
	</Column>
</Row>