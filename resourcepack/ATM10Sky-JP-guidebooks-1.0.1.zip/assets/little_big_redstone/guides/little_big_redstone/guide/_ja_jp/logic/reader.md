---
navigation:
  title: "読み取り機"
  icon: "reader"
  parent: little_big_redstone:logic.md
  position: 11
categories:
  - logic
item_ids:
  - little_big_redstone:reader
---

# 読み取り機

<FloatingColumn width="100" align="right">
	### アナログ
	コンパレーターのモードのとき、読み取り機は、ブロックがコンパレーターに出すアナログの信号の強さと同じ出力の値を出します。それ以外のモードでは、読み取り機が出す出力の値は、0（オフ）か1（オン）だけです。
</FloatingColumn>

<RecipeFor id="reader" />

読み取り機は、回路の中に入力を持たないロジックの部品です。かわりに、設定した向きでマイクロチップのすぐ隣にある入れ物の、たまり具合をもとに信号を出します。

読み取り機に使える入れ物は、アイテムの入れ物（チェスト・樽・かまどなど）、液体の入れ物（MODの液体タンク）、エネルギーの入れ物（バッテリーなどのMODのFEの入れ物）です。標準ではアイテムのたまり具合を読み取りますが、ロジックの設定のメニューで変えられます。

読み取り機では、オンの出力を出すのに必要な、入れ物の中身の量の基準を設定できます。基準は、割合でも一定の値でもかまいません。割合にするには、値の最後に%を付けるだけです。

下は、チェストが50%以上たまったときに、読み取り機を使ってレッドストーンランプを点ける例です。

<PaddedBox left="5" top="5">
	<Row>
		<Column>
			<PaddedBox top="4">
				<GameScene zoom="2" padding="0">
					<Block id="minecraft:chest" />
					<BlockAnnotation>
						チェストは50%以上たまっています
					</BlockAnnotation>
					<Block id="red_microchip" x="-1" />
					<Block id="minecraft:redstone_lamp" x="-2" p:lit="true" />
					<IsometricCamera yaw="200" pitch="30" />
				</GameScene>
			</PaddedBox>
		</Column>
	
		<Column>
			<MicrochipScene color="red" padding="0" marginWidth="16">
				<Logic name="reader" x="0" y="0" type="reader" data="{config:{direction:'west'}}" />
				<Logic name="output" x="32" y="0" type="io" data="{config:{direction:'east',input:false,signal_strength:15}}" />
	
				<Wire from="reader" fromPort="0" to="output" toPort="0" powered="1" />
			</MicrochipScene>
		</Column>
	</Row>
	
	<Row>
		<Column>
			<PaddedBox top="4">
				<GameScene zoom="2" padding="0">
					<Block id="minecraft:chest" />
					<BlockAnnotation>
						チェストのたまり具合は50%未満です
					</BlockAnnotation>
					<Block id="red_microchip" x="-1" />
					<Block id="minecraft:redstone_lamp" x="-2" p:lit="false" />
					<IsometricCamera yaw="200" pitch="30" />
				</GameScene>
			</PaddedBox>
		</Column>
	
		<Column>
			<MicrochipScene color="red" padding="0" marginWidth="16">
				<Logic name="reader" x="0" y="0" type="reader" data="{config:{direction:'west'}}" />
				<Logic name="output" x="32" y="0" type="io" data="{config:{direction:'east',input:false,signal_strength:15}}" />
	
				<Wire from="reader" fromPort="0" to="output" toPort="0" />
			</MicrochipScene>
		</Column>
	</Row>
</PaddedBox>