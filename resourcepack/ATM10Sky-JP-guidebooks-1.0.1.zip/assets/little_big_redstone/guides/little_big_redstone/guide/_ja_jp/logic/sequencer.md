---
navigation:
  title: "シーケンサー"
  icon: "sequencer"
  parent: little_big_redstone:logic.md
  position: 19
categories:
  - logic
item_ids:
  - little_big_redstone:sequencer
---

# シーケンサー

<FloatingColumn width="100" align="right">
	### アナログ
	シーケンサーは、入力の信号と同じ値の出力の信号を出します。シーケンサーでは、出力がオンになるのに、入力がいつもオンである必要はありません。その場合は、オンの出力のもとになったオンの入力の値が、出力に使われます。
</FloatingColumn>

<Row>
	<Column>
		<RecipeFor id="sequencer" />
	</Column>

	<Column>
		<GameScene zoom="1.48" padding="3" interactive={true}>
			<ImportStructure src="../assets/structures/sequencer.snbt" />
			<BoxAnnotation min="2 1 0" max="3 1.5 1" color="#FFFFFF">
				シーケンサーはリピーターよりずっと自由に使えますが、考え方は似ています。
			</BoxAnnotation>
			<IsometricCamera yaw="150" pitch="30" />
		</GameScene>
	</Column>
</Row>

> **メモ:** Minecraftでは、現実の1秒は20ティックです。

シーケンサーは、信号を細かく調整して遅らせられるロジックの部品です。

使えるモードは、弱・強・カウンターの3つです（詳しくは下の節を見てください）。シーケンサーの中には、0から設定した遅延（標準は20）までを数えるカウンターがあります。選んだモードによって、カウンターの増え方・減り方が変わります。シーケンサーのカウンターが最大のとき出力はオン、それ以外はオフです。

シーケンサーは、中のカウンターが最大の値に達したら0にリセットするように設定できます。そのときは、ちょうど1ティックだけオンの信号を出します。

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="sequencer" x="32" y="0" type="sequencer" data="{config:{delay:30,auto_reset:true}}" />
	<Logic name="output" x="80" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal direction="north" strength="15" />
</MicrochipScene>

さらに、シーケンサーに2つ目の入力のポートを付けるように設定できます。この2つ目の入力のポートがオンのときはいつも、シーケンサーの中のカウンターが0にリセットされます。

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input1" x="0" y="12" type="io" data="{config:{direction:'east'}}" hide={true} />
	<Logic name="input2" x="0" y="20" type="io" data="{config:{direction:'west'}}" hide={true} />
	<Logic name="sequencer" x="32" y="16" type="sequencer" data="{config:{delay:50,reset_port:true}}" />
	<Logic name="output" x="80" y="16" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input1" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="input2" fromPort="0" to="sequencer" toPort="1" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="east" strength="15" />
	<RedstoneSignal step="1" direction="east" strength="0" />
	<RedstoneSignal step="2" direction="east" strength="0" />
	<RedstoneSignal step="3" direction="west" strength="15" />
	<RedstoneSignal step="4" direction="west" strength="0" />
</MicrochipScene>

<br />

### 弱のモード

シーケンサーの1つ目の入力のポートにオンの信号が来たら、信号の長さに関係なく、シーケンサーは設定した遅延に達するまで数を増やします。信号を決まった時間だけ遅らせたいときは、このモードを使います。

下は、100ティック（5秒）遅らせ、終わったら自動でリセットするように設定したシーケンサーの例です。入力の信号は短めですが、入力がオンのままかどうかに関係なく、シーケンサーは数を増やし続けます。

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="sequencer" x="32" y="0" type="sequencer" data="{config:{delay:100,auto_reset:true}}" />
	<Logic name="output" x="80" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="0" />
	<RedstoneSignal step="2" direction="north" strength="0" />
	<RedstoneSignal step="3" direction="north" strength="0" />
</MicrochipScene>

<br />

### 強のモード

シーケンサーの1つ目の入力のポートにオンの信号が来ているかぎり、シーケンサーは数を増やします。しかし、信号が止まると、シーケンサーは数を減らします。

下は、100ティック（5秒）遅らせるように設定したシーケンサーの例です。

こちらは、シーケンサーがオンの状態に達するのに十分な長さのオンの信号を受け、そのあと同じ長さだけオフになるので、元の状態に戻ります。

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="sequencer" x="32" y="0" type="sequencer" data="{config:{delay:100,mode:'strong'}}" />
	<Logic name="output" x="80" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="15" />
	<RedstoneSignal step="2" direction="north" strength="15" />
	<RedstoneSignal step="3" direction="north" strength="15" />
	<RedstoneSignal step="4" direction="north" strength="0" />
	<RedstoneSignal step="5" direction="north" strength="0" />
	<RedstoneSignal step="6" direction="north" strength="0" />
	<RedstoneSignal step="7" direction="north" strength="0" />
</MicrochipScene>

こちらは、シーケンサーがだいたい半分まで進む長さしかオンの信号を受けません。そのあと入力の信号がオフになり、元の状態まで数を減らします。そのため、終わりの状態に達することはなく、出力はいつもオフです。

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="sequencer" x="32" y="0" type="sequencer" data="{config:{delay:100,mode:'strong'}}" />
	<Logic name="output" x="80" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="15" />
	<RedstoneSignal step="2" direction="north" strength="0" />
	<RedstoneSignal step="3" direction="north" strength="0" />
</MicrochipScene>

<br />

### カウンターのモード

シーケンサーの1つ目の入力のポートにオンの信号が来ているかぎり、シーケンサーは数を増やします。このモードでシーケンサーの数が下がるのは、自動リセットの設定かリセットのポートでリセットされたときだけです。

下は、100ティック（5秒）遅らせ、終わったら自動でリセットするように設定したシーケンサーの例です。入力はひんぱんにオン・オフしますが、入力がオフのときもシーケンサーは数を減らしません。

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="sequencer" x="32" y="0" type="sequencer" data="{config:{delay:100,mode:'counter',auto_reset:true}}" />
	<Logic name="output" x="80" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="0" />
</MicrochipScene>

下は、5ティック遅らせ、終わったら自動でリセットするように設定したシーケンサーの例です。入力の信号が1ティックより長くならないように、入力を[パルス調整器](pulse_throttler.md)で調整しています。こうすると、シーケンサーは、別々のオンの入力を5回受けたときにだけ、1ティックの出力の信号を出します。

<MicrochipScene color="red" includeToolbar={true}>
	<Logic name="input" x="0" y="0" type="io" hide={true} />
	<Logic name="pulse_throttler" x="32" y="0" type="pulse_throttler" />
	<Logic name="sequencer" x="64" y="0" type="sequencer" data="{config:{delay:5,mode:'counter',auto_reset:true}}" />
	<Logic name="output" x="112" y="0" type="io" data="{config:{input:false,direction:'south',signal_strength:15}}" hide={true} />

	<Wire from="input" fromPort="0" to="pulse_throttler" toPort="0" />
	<Wire from="pulse_throttler" fromPort="0" to="sequencer" toPort="0" />
	<Wire from="sequencer" fromPort="0" to="output" toPort="0" />

	<RedstoneSignal step="0" direction="north" strength="15" />
	<RedstoneSignal step="1" direction="north" strength="0" />
</MicrochipScene>