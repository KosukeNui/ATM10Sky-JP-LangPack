---
navigation:
  title: "計算機"
  icon: "calculator"
  parent: little_big_redstone:logic.md
  position: 24
categories:
  - logic
item_ids:
  - little_big_redstone:calculator
---

# 計算機

<FloatingColumn width="100" align="right">
	### アナログ
	計算機の出力の信号は、すべての入力を計算した合計の値になります。信号は0〜15の範囲を超えません。
</FloatingColumn>

<RecipeFor id="calculator" />

計算機は、2〜10個の入力を受けられます。入力の信号は、選んだモードによって足されるか引かれます。出力の信号は、入力を計算した合計の結果になります。

<Row>
	<Column>
		<MicrochipScene color="red" includeToolbar={true}>
			<Logic name="a" x="0" y="4" type="io" data="{config:{direction:'east'}}" hide={true} />
			<Logic name="b" x="16" y="12" type="io" data="{config:{direction:'west'}}" hide={true} />
			<Logic name="calculator" x="48" y="8" type="calculator" />
			<Logic name="output" x="80" y="8" type="io" data="{config:{input:false,signal_strength:15}}" hide={true} />

			<Wire from="a" fromPort="0" to="calculator" toPort="0" />
			<Wire from="b" fromPort="0" to="calculator" toPort="1" />
			<Wire from="calculator" fromPort="0" to="output" toPort="0" />

			<RedstoneSignal step="0" direction="east" strength="0" />
			<RedstoneSignal step="0" direction="west" strength="0" />

			<RedstoneSignal step="1" direction="east" strength="1" />
			<RedstoneSignal step="1" direction="west" strength="1" />

			<RedstoneSignal step="2" direction="east" strength="0" />
			<RedstoneSignal step="2" direction="west" strength="0" />

			<RedstoneSignal step="3" direction="east" strength="10" />
			<RedstoneSignal step="3" direction="west" strength="5" />
		</MicrochipScene>
	</Column>

	<Column>
		<MicrochipScene color="red" includeToolbar={true}>
			<Logic name="a" x="0" y="4" type="io" data="{config:{direction:'east'}}" hide={true} />
			<Logic name="b" x="16" y="12" type="io" data="{config:{direction:'west'}}" hide={true} />
			<Logic name="calculator" x="48" y="8" type="calculator" data="{config:{mode:'subtraction'}}" />
			<Logic name="output" x="80" y="8" type="io" data="{config:{input:false,signal_strength:15}}" hide={true} />

			<Wire from="a" fromPort="0" to="calculator" toPort="0" />
			<Wire from="b" fromPort="0" to="calculator" toPort="1" />
			<Wire from="calculator" fromPort="0" to="output" toPort="0" />

			<RedstoneSignal step="0" direction="east" strength="0" />
			<RedstoneSignal step="0" direction="west" strength="0" />

			<RedstoneSignal step="1" direction="east" strength="2" />
			<RedstoneSignal step="1" direction="west" strength="1" />

			<RedstoneSignal step="2" direction="east" strength="0" />
			<RedstoneSignal step="2" direction="west" strength="0" />

			<RedstoneSignal step="3" direction="east" strength="10" />
			<RedstoneSignal step="3" direction="west" strength="5" />
		</MicrochipScene>
	</Column>
</Row>

入力の順番も計算に使われることに気をつけてください。つまり、引き算のモードで、1つ目に小さい値、2つ目に大きい値が来ると、出力は0になります。信号はマイナスになれないからです。たとえば、引き算のモードの計算機で、入力Aが5、入力Bが10なら、計算した値は-5です。しかし、出力の信号は0になり、オフになります。