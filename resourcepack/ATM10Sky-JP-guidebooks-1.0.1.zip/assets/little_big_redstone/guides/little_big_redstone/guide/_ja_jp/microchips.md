---
navigation:
  title: "マイクロチップ"
  icon: "red_microchip"
  position: 1
item_ids:
  - little_big_redstone:white_microchip
  - little_big_redstone:light_gray_microchip
  - little_big_redstone:gray_microchip
  - little_big_redstone:black_microchip
  - little_big_redstone:brown_microchip
  - little_big_redstone:red_microchip
  - little_big_redstone:orange_microchip
  - little_big_redstone:yellow_microchip
  - little_big_redstone:lime_microchip
  - little_big_redstone:green_microchip
  - little_big_redstone:cyan_microchip
  - little_big_redstone:light_blue_microchip
  - little_big_redstone:blue_microchip
  - little_big_redstone:purple_microchip
  - little_big_redstone:magenta_microchip
  - little_big_redstone:pink_microchip
---

# マイクロチップ

<FloatingColumn align="right">
	<PaddedBox left="5">
		<RecipeFor id="red_microchip" />
	</PaddedBox>
</FloatingColumn>

<FloatingColumn>
	<PaddedBox left="5" right="10" bottom="5">
		<GameScene zoom="1.5" padding="0" background="transparent">
			<ImportStructure src="assets/structures/microchips.snbt" />
			<IsometricCamera yaw="135" pitch="30" />
		</GameScene>
	</PaddedBox>
</FloatingColumn>

マイクロチップは、中に[ロジック](logic/introduction.md)を置いて、複雑な仕組みを作れるブロックです。ロジックどうしのあいだに[配線](redstone_bits.md)を置くと、信号を1つのロジックの部品から別の部品へ運べます。

マイクロチップのメニューでは、スクロールホイールで拡大・縮小できます。左クリックを押したままドラッグすると、回路の見える範囲が動きます。

### 向き

ワールドから入力を受けたり、ワールドに出力したりするロジックの部品を使うときは、その部品が使う向きを設定する必要があります。マイクロチップは方角を使います。つまり、<Color color="#4CFF00">北</Color>・<Color color="#0094FF">南</Color>・<Color color="#FF0000">東</Color>・<Color color="#FF6A00">西</Color>と、<Color color="#FFFFFF">上</Color>・<Color color="#FFD800">下</Color>です。**<KeyBind id="key.sneak" />**を押しながらマイクロチップを見ると、その面に向きの色が見えます。

### 色付け

マイクロチップは、ふつうの16色の染料のどれでも染められ、メニューもその色になります。ロジックの部品はマイクロチップとは別に染められますが、標準では、置いたマイクロチップの色を受け継ぎます。ロジックの部品を染めるには、ふつうと同じようにクラフトの枠で染めるか、メニューの中のロジックに染料を持って右クリックします。

同じように、水入りバケツか雪玉を使うと、ロジックの部品の色を消せます。雪玉は消費されますが、水入りバケツは消費されません。
