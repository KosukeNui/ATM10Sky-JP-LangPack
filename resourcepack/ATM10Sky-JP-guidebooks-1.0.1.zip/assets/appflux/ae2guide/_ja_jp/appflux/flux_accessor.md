---
navigation:
  parent: appflux/appflux-index.md
  title: フラックスアクセッサー
  icon: appflux:flux_accessor
categories:
- flux accessor
item_ids:
- appflux:flux_accessor
- appflux:part_flux_accessor
---

# フラックスアクセッサー

<Row>
<BlockImage id="appflux:flux_accessor" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/flux_accessor.snbt"></ImportStructure>
</GameScene>
</Row>

フラックスアクセッサーは、MEネットワークに保存されているエネルギーを入出力できます。  
デフォルトでは入出力制限はありませんが、これはAppfluxの設定で変更できます。

高速モードと通常モードの2つがあります。  
高速モードでは、毎ティックごとにエネルギーを出力するため、多用するとラグが発生する可能性があります。  
通常モードでは、対象に保存されているエネルギー量に応じて出力を行うため、ラグの問題は発生しません。

* 注意：ここで言及している「エネルギー」とは、[FEストレージセル](./flux_cells.md)に保存されているFEのことであり、  
[エネルギーセル](ae2:items-blocks-machines/energy_cells.md)に保存されているエネルギーではありません。
