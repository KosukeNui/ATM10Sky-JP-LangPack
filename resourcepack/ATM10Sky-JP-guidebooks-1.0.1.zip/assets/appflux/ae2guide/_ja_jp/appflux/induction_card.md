---
navigation:
  parent: appflux/appflux-index.md
  title: 誘導カード
  icon: appflux:induction_card
categories:
- flux accessor
item_ids:
- appflux:induction_card
---

# 誘導カード

<Row>
<ItemImage id="appflux:induction_card" scale="4"></ItemImage>
</Row>

誘導カードは、<ItemLink id="ae2:pattern_provider" />または<ItemLink id="ae2:interface" />を
<ItemLink id="appflux:flux_accessor" />に変換し、エネルギーの入出力を可能にします。
