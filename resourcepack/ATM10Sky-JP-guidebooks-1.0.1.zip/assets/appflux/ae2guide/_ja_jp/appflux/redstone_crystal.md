---
navigation:
  parent: appflux/appflux-index.md
  title: レッドストーンの水晶
  icon: appflux:redstone_crystal
categories:
- flux materials
item_ids:
- appflux:redstone_crystal
- appflux:charged_redstone
- appflux:charged_redstone_block
---

# レッドストーンの水晶

<Row>
<ItemImage id="appflux:redstone_crystal" scale="4"></ItemImage>
<ItemImage id="appflux:charged_redstone" scale="4"></ItemImage>
</Row>
<Row>
<BlockImage id="appflux:charged_redstone_block" scale="4"></BlockImage>
</Row>

*"Pow ah!!"*

レッドストーンはエネルギーを保存するための優れた媒体ですが、そのままではもろく、セルに格納することはできません。

フルーシュクリスタルとグロウストーンを組み合わせることで、レッドストーンブロックはレッドストーンの水晶へと結晶化されます。  
これらは、非常に少ないスペースで大量のエネルギーを保存できます。
