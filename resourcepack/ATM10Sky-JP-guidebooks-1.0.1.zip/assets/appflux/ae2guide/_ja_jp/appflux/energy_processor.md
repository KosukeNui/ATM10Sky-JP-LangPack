---
navigation:
  parent: appflux/appflux-index.md
  title: エネルギープロセッサ
  icon: appflux:energy_processor
categories:
- flux materials
item_ids:
- appflux:energy_processor
- appflux:printed_energy_processor
- appflux:energy_processor_press
---

# エネルギープロセッサ

<Row>
<ItemImage id="appflux:energy_processor" scale="4"></ItemImage>
<ItemImage id="appflux:energy_processor_press" scale="4"></ItemImage>
<ItemImage id="appflux:printed_energy_processor" scale="4"></ItemImage>
</Row>

エネルギープロセッサは、MEシステム内のエネルギーの流れを管理するために使用されます。  
すべてのエネルギーデバイスは、エネルギーを経路指定するためにエネルギープロセッサを必要とします。
