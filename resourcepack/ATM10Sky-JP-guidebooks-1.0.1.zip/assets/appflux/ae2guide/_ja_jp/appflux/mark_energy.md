---
navigation:
  parent: appflux/appflux-index.md
  title: FEのマーキング
categories:
- flux tricks
---

# 設定スロットでFEをマーキングする方法

<ItemLink id="ae2:export_bus"/>を使用してエネルギーを出力したい場合、その設定スロットでFEをマーキングする必要があります。

エネルギーコンテナを持った状態でスロットを右クリックすると、FEがマーキングされます。

![FE_MARK](../pic/fe_mark.png)
