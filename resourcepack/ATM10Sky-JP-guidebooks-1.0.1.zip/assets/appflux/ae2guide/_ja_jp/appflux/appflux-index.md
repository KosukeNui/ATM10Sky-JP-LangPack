---
navigation:
    title: Applied Flux
    position: 70
---

# エネルギーをセルに保存しよう！

Applied Fluxを使用すると、AEで電力システムを管理できます。

## フラックスセル
<CategoryIndex category="flux cells"></CategoryIndex>

## 素材
<CategoryIndex category="flux materials"></CategoryIndex>

## フラックスアクセッサー
<CategoryIndex category="flux accessor"></CategoryIndex>

## 小技
<CategoryIndex category="flux tricks"></CategoryIndex>
