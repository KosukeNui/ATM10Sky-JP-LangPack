---
navigation:
  parent: appflux/appflux-index.md
  title: ターミナルの操作
categories:
- flux tricks
---

# ターミナルの操作

ターミナルでは、保存されているエネルギーが*緑色の流体*として表示されます。

![FE_GUI](../pic/fe_terminal.png)

これは実際の流体ではなく、バケツを使って汲み取ることはできません。

バッテリーや電動ツールなどのエネルギーコンテナを使用して、エネルギーを注入／取り出すことができます。

![FE_GUI2](../pic/fe_terminal2.png)
