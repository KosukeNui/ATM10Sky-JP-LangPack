---
navigation:
  parent: appflux/appflux-index.md
  title: ポータブルフラックスセル
  icon: appflux:fe_1k_portable_cell
categories:
- flux cells
item_ids:
- appflux:fe_1k_portable_cell
- appflux:fe_4k_portable_cell
- appflux:fe_16k_portable_cell
- appflux:fe_64k_portable_cell
- appflux:fe_256k_portable_cell
- appflux:fe_1m_portable_cell
- appflux:fe_4m_portable_cell
- appflux:fe_16m_portable_cell
- appflux:fe_64m_portable_cell
- appflux:fe_256m_portable_cell
---

# ポータブルフラックスセル

<Column>
  <Row>
    <ItemImage id="appflux:fe_1k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_4k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_16k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_64k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_256k_portable_cell" scale="4" />
  </Row>
  <Row>
    <ItemImage id="appflux:fe_1m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_4m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_16m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_64m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_256m_portable_cell" scale="4" />
  </Row>
</Column>

ポータブルFEセルは、通常の[FEセル](./flux_cells.md)と比べて容量が4分の1しかありません。

ただし、ポータブルFEセルには<ItemLink id="appflux:induction_card"/>を取り付けることができ、インベントリ内のアイテムを自動的に充電します。
