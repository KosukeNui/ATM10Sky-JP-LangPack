---
navigation:
  title: エネルギー貯蔵
  icon: greater_energy_card
  parent: index.md
  position: 030
categories:
  - megacells
item_ids:
  - mega_energy_cell
  - greater_energy_card
---

# MEGA Cells：エネルギー

MEGAがより大容量の[エネルギー](ae2:ae2-mechanics/energy.md)ストレージを提供しないはずがありません。  
その要素も、ここでしっかりと用意されています。

## 超高密度エネルギーセル

<BlockImage id="mega_energy_cell" scale="4" />

*超高密度エネルギーセル*は、<ItemLink id="ae2:dense_energy_cell" />の8倍、  
通常の<ItemLink id="ae2:energy_cell" />の64倍のエネルギーを保存できます。  
1セルあたり最大12.8*百万*AEを保存可能です。

特に大規模な[空間IO](ae2:ae2-mechanics/spatial-io.md)構成や、  
巨大なエネルギーバッファを必要とする転送処理に最適で、  
よりコンパクトなブロックスペースでそれを実現できます。

<RecipeFor id="mega_energy_cell" />

## 上位エネルギーカード

<ItemImage id="greater_energy_card" scale="3" />

さらに、超高密度エネルギーセルを使用することで、  
<ItemLink id="ae2:energy_card" />を強化した上位版をクラフトできます。

このカードは、ポータブルストレージセルや  
[ワイヤレス端末](ae2:items-blocks-machines/wireless_terminals.md)などの  
無線インフラに対して、さらに大きなエネルギーバッファを提供します。

AE2標準の対応デバイスは通常のエネルギーカードと同様に使用できますが、  
より要求の厳しい[MEGAポータブルセル](storage.md#portable-cells)では、  
バッテリー容量を拡張するために**上位エネルギーカードのみ**が使用可能です。

<RecipeFor id="greater_energy_card" />
