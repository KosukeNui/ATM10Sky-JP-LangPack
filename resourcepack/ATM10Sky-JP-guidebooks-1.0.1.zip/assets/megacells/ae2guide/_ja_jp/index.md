---
navigation:
  title: "アドオン：MEGA Cells"
  position: 80
item_ids:
  - accumulation_processor
  - accumulation_processor_press
  - printed_accumulation_processor
  - sky_steel_ingot
  - sky_steel_block
---

# MEGA Cells

![MEGA Cells ロゴ](assets/logo.png)

## はじめに

**MEGA Cells**は、Applied Energistics 2向けのアドオンです。  
**1M**から最大**256M**までの大容量ストレージティアを提供するほか、  
より特化したストレージセルや、それらに関連する追加ツールも備えています。

## 導入手順

<Row>
  <ItemImage id="sky_steel_ingot" scale="4" />
  <ItemImage id="accumulation_processor" scale="4" />
</Row>

ストレージ容量をさらに拡張するには、新しい素材が必要になります。  
MEGAインフラの構築準備として、まず大量の<ItemLink id="ae2:sky_stone_block" />を集めてください。

これらは、鉄と<ItemLink id="ae2:charged_certus_quartz_crystal" />とともに加工することで、  
**スカイスチール**合金インゴットへと変換されます。  
ただし、金属加工には水では不十分なため、  
より高温の流体を使用して溶解・変換を行う必要があります。

<Row>
  <Recipe id="transform/sky_steel_ingot" />
</Row>

スカイスチールを入手したら、  
それを用いて**集積プロセッサ**と呼ばれる新しいプロセッサを作成できます。

このプロセッサは、標準的な大容量セルから各種特殊ツールに至るまで、  
ほぼすべてのMEGAデバイスの中核を担う存在です。

<Row>
  <RecipeFor id="accumulation_processor_press" />
  <RecipeFor id="printed_accumulation_processor" />
  <RecipeFor id="accumulation_processor" />
</Row>

ここから先は、「*MEGA Corp.*」の製品群をさらに展開し、  
MEストレージおよびインフラの潜在能力を最大限に引き出していくことができます。

## さらに詳しく

<SubPages />
