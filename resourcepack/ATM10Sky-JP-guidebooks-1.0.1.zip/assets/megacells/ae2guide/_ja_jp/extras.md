---
navigation:
  title: その他の機能
  icon: mega_interface
  parent: index.md
  position: 060
categories:
  - megacells
item_ids:
  - mega_interface
  - cell_dock
  - portable_cell_workbench
---

# MEGA Cells：その他の機能

アドオンの主要な要素を一通り紹介したところで、  
ここではMEGAが提供する、補足的な機能や小規模な追加要素を紹介します。  
完成度の向上と、ちょっとした実験用途のための要素です。

## MEGAインターフェース

<Row>
  <BlockImage id="mega_interface" scale="4" />
  <GameScene zoom="4" background="transparent">
    <ImportStructure src="assets/assemblies/cable_mega_interface.snbt" />
  </GameScene>
</Row>

**MEGAインターフェース**は、<ItemLink id="megacells:mega_pattern_provider" />を補完する存在であり、  
<ItemLink id="ae2:interface" />の容量を倍増させたバージョンです。  
スロット数、入出力、スループット、在庫保持能力のすべてが2倍になります。

<RecipeFor id="mega_interface" />
<RecipeFor id="cable_mega_interface" />

## ポータブルセル作業台

<ItemImage id="portable_cell_workbench" scale="4" />

**ポータブルセル作業台**は、このアドオンの他の要素とはやや異なり、  
<ItemLink id="ae2:cell_workbench" />を…*小型化*したものです。  

手のひらに収まるほど小さいにもかかわらず、  
通常どおりあらゆるストレージセルの設定を行うことができます。

どうやって作業台丸ごとが中に入っているのか、不思議になるところです。

<RecipeFor id="portable_cell_workbench" />

## セルドック

<GameScene zoom="8" background="transparent">
  <ImportStructure src="assets/assemblies/cell_dock.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

最後に紹介するのは、再び「大型」ではなく「小型」な要素です。  
そのため、「MEGA」アイテムと呼ぶには少し異質かもしれません。

**MEセルドック**は、<ItemLink id="ae2:chest" />をよりコンパクトにしたような存在で、  
内部に1つのストレージセルを保持できます。  

内蔵ターミナルなどの追加機能はありませんが、  
省スペースなストレージ提供手段として十分に有用です。  

特に、これは「フラット」な[ケーブルパーツ](ae2:ae2-mechanics/cable-subparts.md)であるため、  
1ブロック内の同一ケーブルに複数のセルドックを設置できます。  
一時的なバッファが必要なコンパクトなサブネットワークなどで役立つでしょう。

<RecipeFor id="cell_dock" />

## 「クラシックセルカラー」

視覚的なオプションとして、MEGAには以下のリソースパックが同梱されています。  
必要に応じて有効化できます。

![Classic Cell Colours resource pack](assets/diagrams/cell_colours_pack.png)

Minecraft 1.21以前のAE2および各種アドオンでは、  
ストレージセルは5段階のカラースキームに従っていました。  
1kセルの赤茶色から始まり、黄色、緑、青を経て、256kでは薄い紫へと変化します。  

MEGAも同様に、1Mの濃い赤から256Mの深い紫へと移行する配色を採用していました。

![Old cell textures](assets/diagrams/cell_colours_old.png)

AE2 1.20.x以降のテクスチャ刷新では、  
より広いカラーパレットが採用され、  
AE2は青から緑へ、MEGAは黄色から赤、ピンクへと変化する配色になりました。

これはこれで魅力的ですが、  
従来の配色を好むユーザーのために、  
旧来のカラースキームも選択肢として用意されています。

![AE2 cell colours](assets/diagrams/cell_colours_ae2.png)
![MEGA cell colours](assets/diagrams/cell_colours_mega.png)
