---
navigation:
  title: MEGAストレージ
  icon: item_storage_cell_256m
  parent: index.md
  position: 010
categories:
  - megacells
item_ids:
  - cell_component_1m
  - cell_component_4m
  - cell_component_16m
  - cell_component_64m
  - cell_component_256m
  - mega_item_cell_housing
  - mega_fluid_cell_housing
  - mega_chemical_cell_housing
  - mega_source_cell_housing
  - mega_mana_cell_housing
  - mega_experience_cell_housing
  - item_storage_cell_1m
  - item_storage_cell_4m
  - item_storage_cell_16m
  - item_storage_cell_64m
  - item_storage_cell_256m
  - fluid_storage_cell_1m
  - fluid_storage_cell_4m
  - fluid_storage_cell_16m
  - fluid_storage_cell_64m
  - fluid_storage_cell_256m
  - chemical_storage_cell_1m
  - chemical_storage_cell_4m
  - chemical_storage_cell_16m
  - chemical_storage_cell_64m
  - chemical_storage_cell_256m
  - source_storage_cell_1m
  - source_storage_cell_4m
  - source_storage_cell_16m
  - source_storage_cell_64m
  - source_storage_cell_256m
  - mana_storage_cell_1m
  - mana_storage_cell_4m
  - mana_storage_cell_16m
  - mana_storage_cell_64m
  - mana_storage_cell_256m
  - experience_storage_cell_1m
  - experience_storage_cell_4m
  - experience_storage_cell_16m
  - experience_storage_cell_64m
  - experience_storage_cell_256m
  - portable_item_cell_1m
  - portable_item_cell_4m
  - portable_item_cell_16m
  - portable_item_cell_64m
  - portable_item_cell_256m
  - portable_fluid_cell_1m
  - portable_fluid_cell_4m
  - portable_fluid_cell_16m
  - portable_fluid_cell_64m
  - portable_fluid_cell_256m
  - portable_chemical_cell_1m
  - portable_chemical_cell_4m
  - portable_chemical_cell_16m
  - portable_chemical_cell_64m
  - portable_chemical_cell_256m
  - portable_source_cell_1m
  - portable_source_cell_4m
  - portable_source_cell_16m
  - portable_source_cell_64m
  - portable_source_cell_256m
  - portable_mana_cell_1m
  - portable_mana_cell_4m
  - portable_mana_cell_16m
  - portable_mana_cell_64m
  - portable_mana_cell_256m
  - portable_experience_cell_1m
  - portable_experience_cell_4m
  - portable_experience_cell_16m
  - portable_experience_cell_64m
  - portable_experience_cell_256m
  - sky_bronze_ingot
  - sky_bronze_block
  - sky_osmium_ingot
  - sky_osmium_block
---

# MEGA Cells：ストレージ

<GameScene zoom="8" background="transparent">
  <ImportStructure src="assets/assemblies/drive_cells.snbt" />
  <IsometricCamera yaw="195" pitch="10" />
</GameScene>

## MEGA [ストレージセル](ae2:items-blocks-machines/storage_cells.md)

<Row>
  <ItemImage id="mega_item_cell_housing" scale="4" />
  <ItemImage id="item_storage_cell_1m" scale="4" />
  <ItemImage id="item_storage_cell_4m" scale="4" />
  <ItemImage id="item_storage_cell_16m" scale="4" />
  <ItemImage id="item_storage_cell_64m" scale="4" />
  <ItemImage id="item_storage_cell_256m" scale="4" />
</Row>

前述のとおり、<ItemLink id="megacells:accumulation_processor" />は、  
あらゆるMEGAインフラを構築するための第一歩となる存在であり、  
これには専用の上位ストレージセルティアも含まれます。  

このプロセッサを使用することで、<ItemLink id="ae2:cell_component_256k" />は  
**1M**（「1024k」に相当）から始まり、最上位の**256M**まで、  
*256kの1000倍以上*という容量へと、さらに拡張することができます。

<RecipeFor id="cell_component_1m" />
<RecipeFor id="cell_component_4m" />
<RecipeFor id="cell_component_16m" />
<RecipeFor id="cell_component_64m" />
<RecipeFor id="cell_component_256m" />

もちろん、より高性能なストレージには、  
それに見合った高性能なハウジングも必要になります。  
そこで、追加のスカイスチールを使用して、  
Mティアコンポーネント向けのアイテムセルハウジングをクラフトします。

<Row>
  <RecipeFor id="mega_item_cell_housing" />
  <Recipe id="cells/standard/item_storage_cell_1m" />
  <Recipe id="cells/standard/item_storage_cell_1m_with_housing" />
</Row>

流体やそれ以外の要素についても、専用のハウジングが用意されています。  
スカイストーンは非常に高い適応性を持ち、  
銅と合金化することで**スカイブロンズ**を生成し、  
それを用いて流体セル用ハウジングを作成できます。  

このガイドに記載されていない要素であっても、  
MEGAが対応する専用セルとハウジングを提供している可能性があります。

<Row>
  <ItemImage id="sky_bronze_ingot" scale="4" />
  <ItemImage id="mega_fluid_cell_housing" scale="4" />
  <ItemImage id="fluid_storage_cell_1m" scale="4" />
  <ItemImage id="fluid_storage_cell_4m" scale="4" />
  <ItemImage id="fluid_storage_cell_16m" scale="4" />
  <ItemImage id="fluid_storage_cell_64m" scale="4" />
  <ItemImage id="fluid_storage_cell_256m" scale="4" />
</Row>

<Row>
  <Recipe id="transform/sky_bronze_ingot" />
  <RecipeFor id="mega_fluid_cell_housing" />
</Row>

## MEGA [ポータブルセル](ae2:items-blocks-machines/storage_cells.md#portable-item-storage)

MEGAは、AE2と同様に、すべてのセルにポータブル版も提供しています。  
ただし、これらは容量が大幅に増加しているため、  
より多くのエネルギーを消費する点に注意してください。  

そのため、これらのセルは通常の<ItemLink id="ae2:energy_cell" />ではなく、  
<ItemLink id="ae2:dense_energy_cell" />を使用してクラフトされます。

また、これらのポータブルセルは、  
通常のMEポータブルセルと同様に  
すべての[アップグレード](ae2:items-blocks-machines/upgrade_cards.md)に対応していますが、  
バッテリー容量と消費電力の増大により、  
<ItemLink id="ae2:energy_card" />では性能が不足します。  

この用途では、<ItemLink id="megacells:greater_energy_card" />のみが使用可能です。

<Row>
  <RecipeFor id="portable_item_cell_1m" />
</Row>
