---
navigation:
  title: 放射性化学物質セル（AppMek専用）
  icon: radioactive_chemical_cell
  parent: index.md
  position: 050
categories:
  - megacells
item_ids:
  - radioactive_cell_component
  - radioactive_chemical_cell
---

# MEGA Cells：放射性化学物質セル

MEGAは、より広範なアドオン間連携の一環として、  
*Mekanism*および***Applied Mekanistics***アドオンを併用しているプレイヤー向けに、  
2つ目の特殊セルを提供しています。  
これらのいずれも使用していない場合、以下のレシピがエラー表示になっているかもしれませんが、  
その場合はこのページを無視しても問題ありません。このセルは存在しないものとして扱ってください。

## 放射性化学物質セル

<Row>
  <ItemImage id="radioactive_cell_component" scale="3" />
  <ItemImage id="radioactive_chemical_cell" scale="3" />
</Row>

**MEGA放射性化学物質セル**は、その名のとおり、  
*Applied Mekanistics*（およびMEGAによるその統合機能）が提供する  
通常の化学ストレージセルを補完する存在です。  
このセルは、*Mekanism*の「化学物質」を保存するために使用されます。

通常の化学セルを使用している場合、1つの制約に気づいているかもしれません。  
それは、*放射性*の化学物質を一切保存できないという点です。  
Mekanismにおいて放射性に該当する主な物質は、  
*核廃棄物*、*ポロニウム*、*プルトニウム*です。

放射性化学物質セルは、その名のとおり、  
上記の放射性化学物質**のみ**を保存できます。

<Row>
  <RecipeFor id="radioactive_cell_component" />
  <RecipeFor id="radioactive_chemical_cell" />
</Row>

放射性化学物質セルは、<ItemLink id="megacells:bulk_item_cell" />といくつかの点で共通しています。  
保存できるのは1種類の放射性化学物質のみであり、  
使用する前にパーティション（フィルター設定）を行う必要があります。

ただし、類似点はそこまでです。  
放射性化学物質セルは無限容量ではなく、  
最大で*256[バイト](ae2:ae2-mechanics/bytes-and-types.md)*分の化学物質しか保存できません。

とはいえ、これは*2048バケツ分*、  
つまり放射性化学物質4本分の核廃棄物バレルに相当する量を、  
セル1つ分のスペースに収められることを意味します。

![Radioactive Cell with polonium](assets/diagrams/radioactive_cell.png)

このような揮発性物質を封じ込めて保存するため、  
放射性化学物質セルは（どういうわけか）  
安定状態を維持するために、はるかに多くのエネルギーを必要とします。

<ItemLink id="ae2:item_storage_cell_1k" />が0.5AE/t、  
<ItemLink id="ae2:item_storage_cell_256k" />が2.5AE/t、  
<ItemLink id="megacells:item_storage_cell_256m" />が5AE/tであるのに対し、  
放射性化学物質セルは、接続されたMEチェスト／ドライブ内で  
**250AE/t**もの電力を消費します。

最後に、Mekanismプレイヤーが本来想定されている形で  
核廃棄物を適切に管理し続けるよう促すため、  
放射性化学物質セルは***使用済み**核廃棄物*を  
明示的に保存不可としています。

*デフォルト設定*では、原子炉管理を簡単に放棄することはできません。  
ただし、楽をしたいプレイヤー向けに、この挙動は設定で変更可能です。  
**どのように**変更するかについては、読者への課題とします。
