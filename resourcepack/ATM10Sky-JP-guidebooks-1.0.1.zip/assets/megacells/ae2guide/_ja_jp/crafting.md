---
navigation:
  title: MEGA自動クラフト
  icon: 256m_crafting_storage
  parent: index.md
  position: 020
categories:
  - megacells
item_ids:
  - mega_crafting_unit
  - 1m_crafting_storage
  - 4m_crafting_storage
  - 16m_crafting_storage
  - 64m_crafting_storage
  - 256m_crafting_storage
  - mega_crafting_accelerator
  - mega_crafting_monitor
  - mega_pattern_provider
  - cable_mega_pattern_provider
---

# MEGA Cells：自動クラフト

<GameScene zoom="6" background="transparent">
  <ImportStructure src="assets/assemblies/crafting_cpu.snbt" />
  <IsometricCamera yaw="195" pitch="10" />
</GameScene>

## MEGA [クラフトCPU](ae2:items-blocks-machines/crafting_cpu_multiblock.md)

<Row>
  <BlockImage id="mega_crafting_unit" scale="4" />
  <BlockImage id="1m_crafting_storage" scale="4" />
  <BlockImage id="4m_crafting_storage" scale="4" />
  <BlockImage id="16m_crafting_storage" scale="4" />
  <BlockImage id="64m_crafting_storage" scale="4" />
  <BlockImage id="256m_crafting_storage" scale="4" />
</Row>

ストレージセルと同様に、MEGAではクラフトCPU向けにも、より大容量のストレージティアが提供されています。  
これらは、増大した処理能力に対応するため、専用の<ItemLink id="ae2:crafting_unit" />を必要としますが、  
より多くのメモリを備えており、最大規模のクラフトジョブであっても問題なく処理できます。  
また、黒を基調とした外観も特徴です。

<RecipeFor id="mega_crafting_unit" />
<RecipeFor id="1m_crafting_storage" />
<RecipeFor id="4m_crafting_storage" />
<RecipeFor id="16m_crafting_storage" />
<RecipeFor id="64m_crafting_storage" />
<RecipeFor id="256m_crafting_storage" />

追加要素として、MEGAには<ItemLink id="ae2:crafting_accelerator" />に相当する独自の加速器も用意されています。  
このMEGA版は、1ブロックあたり*4つ*の**並列処理スレッド**を提供するという利点があります。

<BlockImage id="mega_crafting_accelerator" scale="4" />
<RecipeFor id="mega_crafting_accelerator" />

さらに、<ItemLink id="ae2:crafting_monitor" />に相当するMEGA版クラフトモニターも存在します。  
機能自体は通常のモニターと変わりませんが、前述のユニットと組み合わせることで、  
CPUマルチブロック全体の外観を統一したい場合に適しています。

<BlockImage id="mega_crafting_monitor" scale="4" />
<RecipeFor id="mega_crafting_monitor" />

## MEGAパターンプロバイダー

<Row>
  <BlockImage id="mega_pattern_provider" scale="4" />
  <GameScene zoom="4" background="transparent">
    <ImportStructure src="assets/assemblies/cable_mega_pattern_provider.snbt" />
  </GameScene>
</Row>

**MEGAパターンプロバイダー**は、<ItemLink id="ae2:pattern_provider" />の拡張版として機能します。  
パターン保持数が倍増しており、合計18個のパターンを格納・処理できます。

ただし、保持できるのは
[**処理パターン**](ae2:items-blocks-machines/patterns.md)
のみであり、<ItemLink id="ae2:molecular_assembler" />とは直接連携できません。

<Row>
  <RecipeFor id="mega_pattern_provider" />
  <RecipeFor id="cable_mega_pattern_provider" />
</Row>
