---
navigation:
  title: "電動ビーコン"
  icon: "electric_beacon"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:electric_beacon
---

# 電動ビーコン

<RecipeFor id="extended_industrialization:electric_beacon" />

電動ビーコンはポーションを消費し、効果1つにつき256 EU/tのコストで、近くのすべてのプレイヤーにその効果を与えます。
ビーコンの中でポーションがもつ時間は、そのポーションのいちばん短い効果の時間の半分です。ほとんどの場合、
ポーションの効果は1つだけです。たとえば、8分の移動速度上昇のポーションをビーコンに使うと、合計4分間、
256 EU/tのコストで範囲に効果を与えます。同じように、40秒のタートルマスターのポーションは20秒しかもたず、
効果が2つ（移動速度低下と耐性）あるので512 EU/tかかります。ポーションはビーコンに消費されるので、
[醸造機](brewery.md)を使って何らかの自動化の循環を作り、ビーコンをずっと動かし続けるのがおすすめです。

ビーコンの範囲は通常のビーコンより広く、その下にある層の数（鋼鉄の外装を除く）で決まります。

| 層の数 | 範囲 |
|--------|-------|
| 1      | 30    |
| 2      | 50    |
| 3      | 70    |
| 4      | 90    |

<GameScene zoom="1.5" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:electric_beacon" />
    <MultiblockShape controller="extended_industrialization:electric_beacon" useBigShape={true} x="-9" y="2" z="-9" />
</GameScene>
