---
navigation:
  title: "農業機"
  icon: "steam_farmer"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:steam_farmer
  - extended_industrialization:electric_farmer
---

# 農業機

<Row>
	<RecipeFor id="extended_industrialization:steam_farmer" />
	<RecipeFor id="extended_industrialization:electric_farmer" />
</Row>

農業機はレシピを処理する普通の機械ではなく、土を耕して湿らせ、植え付け、肥料を与え、作物・植物・木を収穫します。
農業機が動くのに、これらの作業をすべて使う必要はありません。むしろ、ある作業を避けたいこともあるでしょう。
たとえば木を扱うときは、農業機に土を耕したり湿らせたりしてほしくないはずです。

農業機は、十分なエネルギーがないと動きません。蒸気農業機は32 EU/tの蒸気を、電動農業機は64 EU/tを必要とします。

農業機のマルチブロックの一部として必要な土は、`#extended_industrialization:farmer_dirt`のタグを持つどのブロックにも置き換えられます。

## 作業

### 土を耕す

マルチブロックの形の設定で有効にすると、マルチブロックの一部である土のブロックが、クワを使ったときと同じように耕地に変わります。

### 土を湿らせる

搬入ハッチから農業機に水を供給すると、近くに水を置かなくても、すべての耕地が湿った状態に保たれます。

### 植え付け

搬入ハッチから農業機に植えられるアイテムを供給すると、作業範囲の適したブロックに植えます。
植えられるのは、`#extended_industrialization:farmer_plantable`のアイテムタグを持つアイテムだけです。

### 肥料を与える

肥料を与えるのは電動農業機だけです。搬入ハッチから使える液体肥料（EMIに表示されるもの）を供給すると、
作業範囲の植物に骨粉のような効果を与えます。この骨粉のような効果は、サボテンやサトウキビなど、
ふつうは骨粉を使えない植物にも効きます。

### 収穫

完全に育った植物（育ちきった小麦や、苗木が育ってできた木など）があり、搬出ハッチに十分な空きがあれば、
それを壊して保管します。

`#extended_industrialization:farmer_voidable`のタグを持つアイテムは搬出ハッチに保管される優先度が低く、
収穫したブロックから落ちるときに空きがなければ、代わりに捨てられます。<ItemLink id="minecraft:stick" />や
<ItemLink id="minecraft:apple" />がその例で、搬出ハッチの出力スロットを原木と苗木だけに固定しておけば、
それらのアイテムの保管を気にしなくて済みます。

## 蒸気農業機

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:steam_farmer" />
    <MultiblockShape controller="extended_industrialization:steam_farmer" useBigShape={true} x="-10" z="-10" />
</GameScene>

## 電動農業機

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:electric_farmer" />
    <MultiblockShape controller="extended_industrialization:electric_farmer" useBigShape={true} x="-12" z="-12" />
</GameScene>
