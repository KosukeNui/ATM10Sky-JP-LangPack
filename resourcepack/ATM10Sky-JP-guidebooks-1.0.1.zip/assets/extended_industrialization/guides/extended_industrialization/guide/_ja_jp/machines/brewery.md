---
navigation:
  title: "醸造機"
  icon: "electric_brewery"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:steel_brewery
  - extended_industrialization:electric_brewery
  - extended_industrialization:blazing_essence_bucket
---

# 醸造機

<Row>
	<RecipeFor id="extended_industrialization:steel_brewery" />
	<RecipeFor id="extended_industrialization:electric_brewery" />
</Row>

醸造機は通常の機械として働きますが、醸造台のレシピを処理します。ただし、いくつか違う点があります。

醸造機はブレイズパウダーの代わりに灼熱のエッセンスを使います。醸造機は、ポーションを1回醸造するたびに、
灼熱のエッセンスをちょうど1mB消費します。

醸造機は、1～3個を醸造できる醸造台と違い、一度に_ちょうど4個_のポーションを醸造します。
