---
navigation:
  title: "太陽エネルギー"
  icon: "lv_solar_panel"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:bronze_solar_boiler
  - extended_industrialization:steel_solar_boiler
  - extended_industrialization:lv_solar_panel
  - extended_industrialization:mv_solar_panel
  - extended_industrialization:hv_solar_panel
  - extended_industrialization:lv_photovoltaic_cell
  - extended_industrialization:mv_photovoltaic_cell
  - extended_industrialization:hv_photovoltaic_cell
---

# 太陽エネルギー

## ソーラーボイラー

ソーラーボイラーは通常の青銅・鋼鉄のボイラーと同じように動きますが、燃料を消費しません。その代わり、真上から直接日光が当たる必要があり、
同じ種類の標準のボイラーの半分のエネルギーしか作りません。もちろん、水は必要です。

時間がたつとソーラーボイラーには湯あかがたまり、最大で33%まで効率が落ちます。ソーラーボイラーに斧を使うと、湯あかがなくなります。
通常の水の代わりに蒸留水を供給すれば、これを完全に防げます。

<Row>
	<RecipeFor id="extended_industrialization:bronze_solar_boiler" />
	<RecipeFor id="extended_industrialization:steel_solar_boiler" />
</Row>

## ソーラーパネル

ソーラーパネルは、直射日光の当たる場所に置き、その段階の太陽電池を入れるとエネルギーを作ります。
時間がたつと太陽電池は劣化し、やがて壊れます。つまり、昼のあいだ安定して発電するには、太陽電池を自動で作り続ける必要があります。
ソーラーパネルに蒸留水を供給すると、太陽電池の寿命が2倍になります。

<Row>
	<RecipeFor id="extended_industrialization:lv_solar_panel" />
	<RecipeFor id="extended_industrialization:mv_solar_panel" />
	<RecipeFor id="extended_industrialization:hv_solar_panel" />
</Row>

<Row>
	<Recipe id="extended_industrialization:photovoltaic_cell/lv" />
	<Recipe id="extended_industrialization:photovoltaic_cell/mv" />
	<Recipe id="extended_industrialization:photovoltaic_cell/hv" />
</Row>
