---
navigation:
  title: "Extended Industrialization"
  position: 0
---

# Extended Industrialization

<MarginFloatingImage src="assets/logo.png" left="0" right="10" />

Extended Industrializationは、さまざまな機械と道具を追加するModern Industrializationのアドオンです！

Extended Industrializationの主な目的は、Modern Industrializationの設計と本来の使い方に忠実なまま、その内容をさらに広い範囲へ広げることです。
たとえば、[一括処理マルチブロック](machines/batching_multiblocks.md)を追加したことで、設定する機械を減らし、動作を軽くしながら、
これまで以上に工場の規模を大きくできます。
