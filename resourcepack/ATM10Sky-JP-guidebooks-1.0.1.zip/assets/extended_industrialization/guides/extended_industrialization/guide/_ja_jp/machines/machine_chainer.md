---
navigation:
  title: "機械連結器"
  icon: "machine_chainer"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:machine_chainer
  - extended_industrialization:machine_chainer_relay
---

# 機械連結器

<GameScene zoom="2" interactive={true} fullWidth={true}>
	<ImportStructure src="machine_chainer_example.nbt" />
	<IsometricCamera yaw="180" pitch="30" />
</GameScene>

<RecipeFor id="extended_industrialization:machine_chainer" />

機械連結器は、一直線に最大64ブロックまで、たくさんの機械・樽、または`#extended_industrialization:machine_chainer/linkable`の
タグを持つほかのインベントリのブロックにつながります。つながったインベントリは、連結器と共有する1つのインベントリにまとめられます。
連結器は上下も含め、どの方向にも向けられます。

連結器はアイテム・流体・エネルギーの移動に対応しています！ただし、エネルギーの移動は、その段階のケーブル1本の転送速度の3倍までに
制限され、電圧が合わないつながった機械のエネルギーとはやりとりできません。

## 機械連結リレー

リレーは連結器からつなげるブロックですが、インベントリを持ちません。連結した機械の詰め物として使え、
すき間に機械を置かなくても済みます。

<RecipeFor id="extended_industrialization:machine_chainer_relay" />
