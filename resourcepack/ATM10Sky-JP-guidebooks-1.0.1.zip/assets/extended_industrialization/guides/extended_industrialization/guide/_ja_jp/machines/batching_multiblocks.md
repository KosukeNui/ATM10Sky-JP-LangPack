---
navigation:
  title: "一括処理マルチブロック"
  icon: "processing_array"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:large_steam_furnace
  - extended_industrialization:large_steam_macerator
  - extended_industrialization:large_electric_furnace
  - extended_industrialization:large_electric_macerator
  - extended_industrialization:processing_array
---

# 一括処理マルチブロック

一部のマルチブロックは、その種類の通常の機械として働きますが、一度に処理できる入力の量に倍率がかかります。
つまり、あるレシピの種類をY個ずつまとめて処理できるマルチブロックは、一度に1倍からY倍までの入力を消費し、
まとめた数に応じて結果を作ります。機械が消費するEU/tも、今処理しているまとまりの数だけ倍になります。

一括処理マルチブロックがまとめて処理できる数は機械によって違います。具体的な値は、その機械のアイテムのツールチップを見てください。

ほかの機械とまったく同じく、一度に2つ以上のレシピは処理できません。

## 大型かまど

大型電動かまどがまとめて処理できる数は、電動高炉の作り方と同じように、マルチブロックに使ったコイルで決まります。
コイルがかまどで与えるまとめ数は、そのコイルのツールチップを見てください。

<Row>
	<RecipeFor id="extended_industrialization:large_steam_furnace" />
	<RecipeFor id="extended_industrialization:large_electric_furnace" />
</Row>

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:large_steam_furnace" />
    <MultiblockShape controller="extended_industrialization:large_electric_furnace" x="-6" y="-1" z="-6" />
</GameScene>

## 大型粉砕機

<Row>
	<RecipeFor id="extended_industrialization:large_steam_macerator" />
	<RecipeFor id="extended_industrialization:large_electric_macerator" />
</Row>

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:large_steam_macerator" />
    <MultiblockShape controller="extended_industrialization:large_electric_macerator" x="-6" z="-6" />
</GameScene>

## 並列処理装置

並列処理装置は、画面に入れたマルチブロックでない電動のクラフト機械なら、どれでもまとめて処理できます。
並列処理装置がまとめて処理できる数は、装置の大きさと、中に入れた機械の数で制限されます。

<RecipeFor id="extended_industrialization:processing_array" />

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:processing_array" />
    <MultiblockShape controller="extended_industrialization:processing_array" useBigShape={true} x="-6" z="-8" />
</GameScene>
