---
navigation:
  title: "テスラ"
  icon: "tesla_coil"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:tesla_calibrator
  - extended_industrialization:tesla_handheld_receiver
  - extended_industrialization:tesla_interdimensional_upgrade
  - extended_industrialization:tesla_coil
  - extended_industrialization:tesla_receiver
  - extended_industrialization:lv_tesla_receiver_hatch
  - extended_industrialization:mv_tesla_receiver_hatch
  - extended_industrialization:hv_tesla_receiver_hatch
  - extended_industrialization:ev_tesla_receiver_hatch
  - extended_industrialization:superconductor_tesla_receiver_hatch
  - extended_industrialization:tesla_tower
  - extended_industrialization:aluminum_tesla_winding
  - extended_industrialization:annealed_copper_tesla_winding
  - extended_industrialization:copper_tesla_winding
  - extended_industrialization:electrum_tesla_winding
  - extended_industrialization:superconductor_tesla_winding
---

# テスラ

テスラコイルと受信機を使うと、コストと引き換えにEUを無線で送れます。テスラのネットワークの送信機（テスラコイルかテスラタワー）は
1つだけで、テスラ受信機の数には上限がありません。送信機ごとに、範囲と常時消費のコストが決まっています。

## テスラ較正器

テスラの送信機を受信機とつなぐには、まずテスラ較正器を持って送信機に**<KeyBind id="key.sneak" />** + **<KeyBind id="key.use" />**を押します。
次に、較正器を持ったまま受信機に**<KeyBind id="key.use" />**を押すだけでつながります。

<RecipeFor id="extended_industrialization:tesla_calibrator" />

## テスラの送信機

テスラの送信機は、どのテスラのネットワークでもエネルギーの出どころです。

送信機は、電圧がまったく同じでない受信機にはエネルギーを送れません。たとえば、上級機械外装を入れたテスラコイルは、
外装のないテスラ受信機には送れませんが、同じく上級機械外装を入れた受信機には送れます。

テスラコイルの常時消費のEU/tは、中に入れた外装の電圧（または外装がないこと）で決まります。

<RecipeFor id="extended_industrialization:tesla_coil" />

テスラタワーが送る電圧は、使ったエネルギー搬入ハッチで決まります。

テスラタワーの常時消費のEU/t、転送の上限、範囲は、使った巻線で決まります。巻線ごとの詳細は、それぞれのツールチップに書いてあります。

<Row>
	<GameScene zoom="0.75" interactive={true} fullWidth={false}>
		<MultiblockShape controller="extended_industrialization:tesla_tower" />
	</GameScene>
	<RecipeFor id="extended_industrialization:tesla_tower" />
</Row>

## テスラの受信機

テスラの受信機は、送信機から送ったエネルギーの届け先です。

テスラ受信機は受け取ったエネルギーをためて、出力の面から出します。ほかのエネルギーを出すブロックと同じように、
ケーブルでエネルギーを取り出すこともできます。

<RecipeFor id="extended_industrialization:tesla_receiver" />

テスラ受信ハッチは、通常のテスラ受信機と同じようにエネルギーを受け取りますが、マルチブロックのエネルギー搬入ハッチとして働きます。
受信機と、そこから出力するためのエネルギー搬入ハッチを両方用意する代わりに、この2つをハッチ1つにまとめたものです。

<RecipeFor id="extended_industrialization:lv_tesla_receiver_hatch" />
